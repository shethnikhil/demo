# core/exception_handlers.py
from fastapi import Request
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError
from fastapi.exceptions import RequestValidationError
from starlette.status import HTTP_500_INTERNAL_SERVER_ERROR, HTTP_400_BAD_REQUEST

# General fallback
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=HTTP_500_INTERNAL_SERVER_ERROR,
        content={"status": 500, "message": "Internal server error"},
    )

# SQLAlchemy-specific
async def sqlalchemy_exception_handler(request: Request, exc: SQLAlchemyError):
    return JSONResponse(
        status_code=500,
        content={"status": 500, "message": "Database operation failed"},
    )

# Pydantic validation errors (custom)
async def validation_exception_handler(request: Request, exc: ValidationError):
    return JSONResponse(
        status_code=HTTP_400_BAD_REQUEST,
        content={"status": 400, "message": "Data validation error", "details": exc.errors()},
    )

# Request body/params validation
async def request_validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=HTTP_400_BAD_REQUEST,
        content={"status": 400, "message": "Request validation error", "details": exc.errors()},
    )
