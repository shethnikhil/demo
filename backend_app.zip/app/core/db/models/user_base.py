'''
So in this file we declare declarative base 
'''
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import Table, Column, Integer, String, ForeignKey, DateTime, Boolean, JSON, Text, create_engine
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy.sql import func
# from app.core.db.services.db_common_service import log_entry
# from app.core.db.services.db_user_service import async_create_user
from conf.config import settings

from sqlalchemy.ext.asyncio  import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker


Base = declarative_base()


class Users(Base):
    __tablename__ = "yts_users"
    user_id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, index=True)
    email = Column(String(70), unique=True, nullable=False, index=True)
    password = Column(String(400), nullable=False)
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_by = Column(Integer, ForeignKey('yts_users.user_id'), nullable=True)
    updated_at = Column(DateTime, onupdate=func.now(),nullable=True)
    is_deleted = Column(Boolean, default=False, nullable=False)
    deleted_by = Column(Integer, ForeignKey('yts_users.user_id'), nullable=True)
    deleted_at = Column(DateTime, nullable=True)

    user_role = relationship("UserRoles", back_populates="user")


class Roles(Base):
    __tablename__ = "yts_roles"
    role_id = Column(Integer, primary_key=True, index=True)
    role_name = Column(String(50), unique=True, nullable=False, index=True)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)

    user_role = relationship("UserRoles", back_populates="role")


class UserRoles(Base):
    __tablename__ = "yts_user_roles"
    user_role_id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("yts_users.user_id"), nullable=False)
    role_id = Column(Integer, ForeignKey("yts_roles.role_id"), nullable=False)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)

    user = relationship("Users", back_populates="user_role")
    role = relationship("Roles", back_populates="user_role")


class Company(Base):
    __tablename__ = "yts_company"
    # company_id =Column(Integer, primary_key=True, index=True)
    company_symbol = Column(String(100), primary_key=True, unique=True , autoincrement=False, nullable=False, index=True)
    company_isin_no = Column(String(70), unique=True, nullable=False)
    company_name = Column(String(100), nullable=False, index=True)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_by = Column(Integer, nullable=True)
    updated_at = Column(DateTime, onupdate=func.now())
    is_deleted = Column(Boolean, default=False,nullable=False)
    deleted_by = Column(Integer, nullable=True)
    deleted_at = Column(DateTime, nullable=True)

    # company_keywords = relationship("CompanyKeywords", back_populates="company")
    # keywords = relationship("Keywords", secondary="yts_company_keywords", back_populates="companies")
    # company_sectors = relationship("CompanySectors", back_populates="company")

    company_keywords = relationship("CompanyKeywords", back_populates="company", overlaps="keywords,companies")
    keywords = relationship("Keywords", secondary="yts_company_keywords", back_populates="companies", overlaps="company_keywords,companies")


class Keywords(Base):
    __tablename__ = "yts_keywords"
    keyword_id = Column(Integer, primary_key=True, index=True) 
    keyword_name = Column(String(50), unique=True, nullable=False, index=True) 
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_by = Column(Integer, nullable=True)
    updated_at = Column(DateTime, onupdate=func.now())
    is_deleted = Column(Boolean, default=False)
    deleted_by = Column(Integer, nullable=True)
    deleted_at = Column(DateTime, onupdate=func.now())

    # company_keywords = relationship("CompanyKeywords", back_populates="keyword")
    # companies = relationship("Company", secondary="yts_company_keywords", back_populates="keywords")

    company_keywords = relationship("CompanyKeywords", back_populates="keyword", overlaps="companies,keywords")
    companies = relationship("Company", secondary="yts_company_keywords", back_populates="keywords", overlaps="company_keywords,company")


class CompanyKeywords(Base):
    __tablename__ = "yts_company_keywords"
    company_keyword_id = Column(Integer, primary_key=True, index=True)
    # company_symbol = Column(String(70), nullable=False)  #TODO ForeignKey("yts_company.company_symbol")
    # keyword_id = Column(Integer, nullable=False) #TODO  ForeignKey("yts_keywords.keyword_id")

    company_symbol = Column(String(70), ForeignKey("yts_company.company_symbol"), nullable=False)
    keyword_id = Column(Integer, ForeignKey("yts_keywords.keyword_id"), nullable=False)

    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    is_deleted = Column(Boolean, default=False)
    deleted_by = Column(Integer, nullable=True)
    deleted_at = Column(DateTime, onupdate=func.now())

    # company = relationship("Company", back_populates="company_keywords")
    # keyword = relationship("Keywords", back_populates="company_keywords")
    company = relationship("Company", back_populates="company_keywords", overlaps="keywords,companies")
    keyword = relationship("Keywords", back_populates="company_keywords", overlaps="companies,keywords")


class Sectors(Base):
    __tablename__ = "yts_sectors"
    sector_id = Column(Integer, primary_key=True, index=True)
    sector_name = Column(String(50),unique=True, nullable=False, index= True)
    parent = Column(Integer, default=0)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_by = Column(Integer, nullable=True)
    updated_at = Column(DateTime, onupdate=func.now())
    is_deleted = Column(Boolean, default=False)
    deleted_by = Column(Integer, nullable=True)
    deleted_at = Column(DateTime, onupdate=func.now())


class CompanySectors(Base):
    __tablename__ = "yts_company_sectors"
    company_sector_id = Column(Integer, primary_key=True, index=True)
    company_symbol = Column(String(70), nullable=False) #TODO ForeignKey("yts_company.company_symbol")
    sector_id = Column(Integer, nullable=False)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=func.now(), nullable=False)
    updated_by = Column(Integer, nullable=True)
    updated_at = Column(DateTime, onupdate=func.now())
    is_deleted = Column(Boolean, default=False)
    deleted_by = Column(Integer, nullable=True)
    deleted_at = Column(DateTime, onupdate=func.now())


class Log(Base):
    __tablename__ = "yts_log"
    log_id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    log_name = Column(String(255), nullable=False)
    log_description = Column(Text(1000), nullable=True)
    previous_value = Column(Text(2000), nullable= True)
    updated_value = Column(Text(2000),nullable= True)
    changed_by = Column(Integer, nullable=False)
    changed_at = Column(DateTime(timezone=True), default=func.now())


class YoutubeSearchedVideos(Base):
    __tablename__ = "yts_youtube_searched_videos"
    youtube_videos_id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    job_id = Column(Integer,nullable=False) ## TODO implete foreinged key here
    company_symbol = Column(JSON, nullable=False)
    title = Column(Text(500), nullable=True)
    description = Column(Text(2000), nullable=True)  
    thumbnail = Column(String(255), nullable=True)
    publish_date = Column(String(50), nullable=True)
    language = Column(String(50), nullable=True)
    completion_status = Column(Boolean, default=False, nullable=True)
    video_url = Column(String(255), nullable=True )
    platform = Column(String(50), nullable = True)


class ShortlistedVideos(Base):
    __tablename__ = "yts_shortlisted_videos"
    shortlisted_videos_id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    job_id = Column(Integer,ForeignKey('yts_job.job_id'), nullable=False) 
    company_symbol = Column(JSON, nullable=False)
    platform = Column(String(50), nullable = True)
    title = Column(Text(500), nullable=True)
    description = Column(Text(2000), nullable=True)
    thumbnail = Column(String(255), nullable=True)
    publish_date = Column(String(50), nullable=True)
    language = Column(String(50), nullable=True)
    youtube_video_link = Column(String(2000), nullable=True)
    s3_link = Column(Text(2000), nullable=True)
    s3_url_private = Column(Text(2000), nullable=True)
    s3_link_status = Column(Integer,default=False, nullable=False)
    auto_transcription = Column(Text(4000), nullable=True)
    model_transcription = Column(Text(4000), nullable=True)
    notes = Column(Text(2000), nullable=True)
    completion_status = Column(Integer, default=False, nullable=False)

    job = relationship("Job", back_populates="shortlisted_videos_rel")


class Job(Base):
    __tablename__ = "yts_job"
    job_id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    user_id = Column(Integer,nullable=False)
    job_name = Column(String(255), nullable=False)
    job_desc = Column(Text(1000),nullable=True)
    company_symbol = Column(JSON, nullable=False)
    links = Column(JSON,nullable=True)
    search_start_date = Column(String(50), nullable=True)  # ..... TODO change String to Datetime 
    search_end_date = Column(String(50), nullable=True)# ..... TODO change String to Datetime 
    job_status = Column(Integer, default=None, nullable=True)
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, nullable=False, default=func.now())
    is_archived = Column(Boolean, default=False, nullable=False)
    archived_by = Column(Integer,nullable=True)
    archived_at = Column(DateTime, onupdate=func.now())
       
    shortlisted_videos_rel = relationship("ShortlistedVideos", back_populates="job")


class YoutubeMaster(Base):
    __tablename__ = "yts_youtube_master"
    yt_master_id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    yt_master_name = Column(String(100), nullable=False)
    yt_master_secret_key = Column(String(255), nullable=False)



# db_name = "mysql"
# db_drivername = "asyncmy"
# db_username = "admin"
# db_password = "root"
# db_port = 3306
# db_database_name = "yts"
# db_server = "localhost"
# DB_url = f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"
# async_engine = create_async_engine(DB_url, echo=False) 
# async_session_maker = sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False )

db_name = settings.db_name
db_drivername = settings.db_drivername
db_username = settings.db_username
db_password = settings.db_password
db_port = settings.db_port
db_database_name = settings.db_database_name
db_server = settings.db_server
DB_url = f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"
async_engine = create_async_engine(DB_url, pool_pre_ping=True, pool_recycle=3600, echo=False) 
async_session_maker = sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False )


from app.core.db.db_session import *

async def async_create_tables(async_engine):
    # Base.metadata.create_all(async_engine)
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)



async def async_remove_tables(async_engine):
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

async def main(operation):
    if operation == 1:
        await async_create_tables(async_engine)
        print("Table create successfully")
        
    elif operation == 0:
        await async_remove_tables(async_engine)
        print("all table removed sucessfully")



engine = create_engine(f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}")
if __name__ == "__main__":
    # async_engine = create_async_engine((f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"))
    # create_tables(async_engine=async_engine)  
    asyncio.run(main(1))
