import asyncio
from fastapi import BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
# from app.core.db.models.company_base import CreateCompany, async_session_maker
from app.core.db.models.user_base import Company, CompanyKeywords, Keywords, async_session_maker
from sqlalchemy import select, update
from datetime import datetime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func
from sqlalchemy import outerjoin
from sqlalchemy.orm import joinedload


from app.core.db.services.common_repository import log_entry
from app.utils.logging_utils import log_async

from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError

async def create_keywords_db(
        session: AsyncSession, 
        keyword_name: str, 
        company_symbol: str,
        user_id: int,
        background_tasks : BackgroundTasks,
        ):
    try:
        new_keywords = Keywords(keyword_name=keyword_name, created_by=user_id)
        session.add(new_keywords)
        await session.commit()
        await session.refresh(new_keywords)
        
        if new_keywords.keyword_id:
            company_mapping =  CompanyKeywords(
                company_symbol = company_symbol, 
                keyword_id = new_keywords.keyword_id,
                created_by = user_id,
            )
            session.add(company_mapping)
            await session.commit()
            await session.refresh(company_mapping)
            log_entry_result = await log_entry(
                background_tasks=background_tasks,
                session=session,
                log_name="Keyword created",
                log_description=f"New Keyword created by user_id {user_id} and Mapped to Company:{company_symbol}",
                previous_value=None,
                updated_value=keyword_name,
                changed_by=user_id)
            if log_entry_result:
                return{"id": new_keywords.keyword_id, "keyword_name": new_keywords.keyword_name}
            return{"id": new_keywords.keyword_id, "keyword_name": new_keywords.keyword_name}
        else:
            log_async(
                background_tasks,
                f"[DB][CREATE_KEYWORD] Error: {str(e)}",
                "error"
            )
            return None

    
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][CREATE_KEYWORD] Error: {str(e)}",
            "error"
        )
        return None

async def get_all_keywords_db(
        session: AsyncSession,
        background_tasks: BackgroundTasks,
        ):
    """
    fetch the all keywords available in Database.
    """
    try:
        stmt = (
            select(Keywords, CompanyKeywords.company_symbol, Company.company_name)
            .join(CompanyKeywords, Keywords.keyword_id == CompanyKeywords.keyword_id)
            .join(Company, Company.company_symbol == CompanyKeywords.company_symbol)
            .where(Keywords.is_deleted == False)
        )
        result = await session.execute(stmt)
        rows = result.all()

        keyword_info = []
        # for keyword, company_symbol, company_name in rows:
        #     keyword_info.append({
        #         "id": keyword.keyword_id,
        #         "keyword_name": keyword.keyword_name,
        #         "created_by": keyword.created_by,
        #         "company_symbol": company_symbol,
        #         "company_name": company_name
        #     })
        keyword_info = [
            {
                "id": keyword.keyword_id,
                "keyword_name": keyword.keyword_name,
                "created_by": keyword.created_by,
                "company_symbol": company_symbol,
                "company_name": company_name
            }
            for keyword, company_symbol, company_name in rows
        ]

        return keyword_info
  
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][GET_ALL_KEYWORDS] Unexpected error: {str(e)}",
            "error"
        )
        return []
    
async def update_keywords_db(keyword_name:str, keyword_id:int, updated_by:int, session: AsyncSession):
    try:
        data={}
        if keyword_name is not None:
            data["keyword_name"]=keyword_name
        data["updated_at"]=func.now()
        data["updated_by"]=updated_by

        stmt = update(Keywords).where(Keywords.keyword_id==keyword_id).values(**data)
        result = await session.execute(stmt)
        await session.commit()
        updated_result = result.rowcount
        return updated_result
    
    except Exception as e:
        print(f"error in updating keyword: {e}")
        return False

async def soft_delete_keyword_db(keyword_id:str, deleted_by:int, session:AsyncSession):
    try:
        data = {}
        # value = {"is_deleted":True,"deleted_by":deleted_by}
        data["is_deleted"] = True
        data["deleted_by"] = deleted_by
        data["deleted_at"] = func.now()
        stmt = update(Keywords).where(Keywords.keyword_id==keyword_id).values(**data)
        result = await session.execute(stmt)
        await session.commit()
        delete_result = result.rowcount
        return delete_result

    except Exception as e:
        print(f"error in deleting company: {e}")
        return False




async def company_keyword_db(
        company_symbol,
        background_tasks: BackgroundTasks,
        session:AsyncSession,
        ):

    try:
       
        # stmt = select(CompanyKeywords).where(Keywords.keyword_id==keyword_id).values(**data)
        # stmt = select(CompanyKeywords, Company, Keywords).join(
        #     CompanyKeywords, Company.company_symbol==company_symbol.user_id
        # ).where(CompanyKeywords.company_symbol == company_symbol)

        # stmt = (
        #     select(Company, Keywords)
        #     .join(CompanyKeywords, Keywords.keyword_id == CompanyKeywords.keyword_id)
        #     .join(Company, Company.company_symbol == CompanyKeywords.company_symbol)
        #     .where(Company.company_symbol == company_symbol)
        # )

        # stmt = (
        #     select(Company, Keywords)
        #     .select_from(
        #         outerjoin(
        #             outerjoin(
        #                 Company,
        #                 CompanyKeywords,
        #                 Company.company_symbol == CompanyKeywords.company_symbol
        #             ),
        #             Keywords,
        #             Keywords.keyword_id == CompanyKeywords.keyword_id
        #         )
        #     )
        #     .where(Company.company_symbol == company_symbol)
        # )



        # result = await session.execute(stmt)
        # # search_result = result.scalars().first()
        # # if search_result:
        # #     company_name = search_result.company_name
        # # if search_result:
        # #     return search_result
        # # else:
        # #     return None

        # rows = result.all()
        # if rows:
        #     company, _ = rows[0]
        #     company_name = [company.company_name for _, keyword in rows if keyword is not None]

        #     keywords = [keyword.keyword_name for _, keyword in rows if keyword is not None]
        #     return {
        #         "company_name": company_name,
        #         "keywords": keywords if keywords else None 
        #     }
        # else:
        #     return None

        stmt = (
            select(Company, Keywords)
            .select_from(
                outerjoin(
                    outerjoin(
                        Company,
                        CompanyKeywords,
                        Company.company_symbol == CompanyKeywords.company_symbol
                    ),
                    Keywords,
                    Keywords.keyword_id == CompanyKeywords.keyword_id
                )
            )
            .where(Company.company_symbol == company_symbol)
        )

        result = await session.execute(stmt)
        rows = result.all()

        if rows:
            company_objs = [company for company, _ in rows if company is not None]
            keyword_objs = [keyword for _, keyword in rows if keyword is not None]

            company_name = company_objs[0].company_name if company_objs else None
            keywords = [keyword.keyword_name for keyword in keyword_objs]

            return {
                "company_name": company_name,
                "keywords": keywords if keywords else None
            }
        else:
            return {
                "company_name": None,
                "keywords": None
            }

        
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][COMPANY_KEYWORD_DB] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return False

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][COMPANY_KEYWORD_DB] Validation error: {str(val_err)}",
            "error"
        )
        return False
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][COMPANY_KEYWORD_DB] Unexpected error during company keyword check: {str(e)}",
            "error"
        )

        return False

async def main():
    async with async_session_maker() as session:
        result = await company_keyword_db(session=session, keyword_name="keywordUpdate1")
        print(result)
# async def main():
#     try:
#         async with async_session_maker() as session:
#             new_user = await create_company_db(session,"isis_no_test(1)","@1", "test1",1)
#             print(f"Comapnay Added: {new_user}")
#     except Exception as e:
#         print(f"error: {e}")


# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())
    # asyncio.run(get_all_user_main())

