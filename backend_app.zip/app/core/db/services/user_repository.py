from fastapi import BackgroundTasks, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db.models.user_base import Users, UserRoles , Roles
from sqlalchemy import select, update
from datetime import datetime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func
from app.core.db.services.common_repository import log_entry
from app.utils.logging_utils import log, log_async, log_background

# print("test")

def object_to_dict(obj: DeclarativeBase) -> dict:
    try:
        '''
        TODO
        '''
        data =  {}
        for column in obj.__table__.columns:
            value = getattr(obj, column.name)
            if isinstance(value, datetime):
                data[column.name] = value.isoformat()
            else:
                data[column.name] = value
        return data
    
    except Exception as e:
        # log.error("Unable to conver db object into dictonary")
        return False

async def async_create_user(
        session:AsyncSession, 
        name:str, 
        email:str, 
        password:str, 
        role:int, 
        created_by:int,
        background_tasks: BackgroundTasks):
    try:
        new_user = Users(name=name, email=email, password=password,created_by=created_by)
        session.add(new_user)
        await session.commit()
        result = await session.refresh(new_user)
        if new_user.user_id:
            new_user_id = new_user.user_id
            user_role = await user_role_entry(
                user_id=new_user_id, 
                role_id=role, 
                session=session,
                created_by=created_by,
                background_tasks=background_tasks)
            if user_role == False:
                return False
            if user_role:
                log_entry_result = await log_entry(
                    background_tasks=background_tasks,
                    session=session,
                    log_name="Job created",
                    log_description=f"New user created by user_id {created_by}",
                    previous_value=None,
                    updated_value=email,
                    changed_by=1)
                if log_entry_result:
                    return True
            return True
        # print("new_user created successfully")
    except Exception as e:
        print(f"error in create user: {e}")
        return False


async def user_role_entry(user_id, role_id, created_by, background_tasks: BackgroundTasks, session:AsyncSession):
    try:
        new_user_role = UserRoles(user_id=user_id, role_id=role_id,created_by=created_by)
        session.add(new_user_role)
        await session.commit()
        result = await session.refresh(new_user_role)
        new_user_role_id = new_user_role.user_role_id
        return True
    
    except Exception as e:
        print(f"error in create userrole: {e}")
        return False
    

# async def main():
#     try:
#         async with async_session_maker() as session:
#             new_user = await async_create_user(session,"testUser3","testUser3@gmail.com","Password@123")
#             print(f"User Added: {new_user}")
#     except Exception as e:
#         print("error")

async def get_all_users_from_db(session: AsyncSession):
    stmt = select(Users)
    result = await session.execute(stmt)
    users = result.scalars().all()
    # for user in users:
    #     print(user.name, user.email, user.password, user.created_at)2
    # print(users)
    return users

async def update_user_db(
        background_tasks : BackgroundTasks,
        current_name,
        u_user_id: int,
        session: AsyncSession, 
        user_id : int, 
        name: str = "None Name",
        ):
    """
    Performs the database operation to update user details.
    """
    try: 
        data = {}
        if name is not None:
            data["name"] = name
        data["updated_by"] = user_id
        data["updated_at"] = func.now()

        stmt = update(Users).where(Users.user_id==u_user_id).values(**data)
        result = await session.execute(stmt)  
        await session.commit()    # TODO what about commit
        update_result = result.rowcount
        if update_result == 1:
            log_entry_result = await log_entry(
                background_tasks=background_tasks,
                session=session,
                log_name="User Updated",
                log_description=f"user Updated by user_id {user_id}",
                previous_value=current_name,
                updated_value=name,
                changed_by=user_id)
            if log_entry_result:
                return True
            return True
        else:
            return None
    
    except Exception as e:
        await session.rollback()
        log_async(
            background_tasks,
            f"[DB][UPDATE_USER_DB] Database error during user update for ID {user_id}: {str(e)}",
            "error"
        )
        raise Exception(f"Database error during user update: {e}")

async def delete_user_db(
        deleted_by_user_id: int,
        target_user_id: int,
        session: AsyncSession, 
        background_tasks: BackgroundTasks,
        ):
    """
    Performs the database operation to soft delete a user.
    Sets 'is_deleted' flag to True and records 'deleted_by'.
    """
    try:
        stmt = update(Users).where(Users.user_id == target_user_id).values(
                    is_deleted=True,
                    deleted_by=deleted_by_user_id,
                    deleted_at=func.now() # Assuming you have a deleted_at column
                )   
        result = await session.execute(stmt) 
        await session.commit()
        delete_result = result.rowcount
        if delete_result == 1:
            log_entry_result = await log_entry(
                background_tasks=background_tasks,
                session=session,
                log_name="User Delete",
                log_description=f"User {target_user_id}: Deleted by user_id {deleted_by_user_id}",
                previous_value=None,
                updated_value="Deleted",
                changed_by=deleted_by_user_id)
            if log_entry_result:
                return True
            return True
        else:
            return None

    except Exception as e:
        await session.rollback() # Rollback on error
        log_async(
            background_tasks,
            f"[DB][DELETE_USER_DB] Database error during soft-deletion of user ID {target_user_id}: {str(e)}", # Corrected typo
            "error",
            exc_info=True # Include traceback
        )
        # Re-raise the exception to be handled by the service layer
        raise Exception(f"Database error during soft-deleting user: {e}")

async def check_username(username: str, session: AsyncSession):
    # stmt = select(Users).where(Users.email==username)
    stmt = select(Users, UserRoles, Roles).join(
        UserRoles, Users.user_id==UserRoles.user_id
    ).join(
        Roles, UserRoles.role_id==Roles.role_id
    ).where(Users.email == username)
    resutl = await session.execute(stmt)
    user_result = resutl.all()
    return user_result

async def get_user_by_id_from_db(
        user_id,
        background_tasks: BackgroundTasks,
        session: AsyncSession,
        ):
    """
    Retrieves a user from the database by their user ID.
    """
    try:
        stmt = select(Users).where(Users.user_id==user_id)
        result = await session.execute(stmt)
        search_result = result.scalars().first()
        # return searach_result
        if search_result:
            log_async(
                background_tasks,
                f"[DB][GET_USER] User with ID {user_id} found.",
                "debug"
            )
            return search_result
        else:
            log_async(
                background_tasks,
                f"[DB][GET_USER] User with ID {user_id} not found in DB.",
                "info"
            )
            return None
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][GET_USER] Error fetching user with ID {user_id}: {str(e)}",
            "error"
        )
        raise Exception(f"Database error while fetching user: {e}") 
    

async def check_roles(session: AsyncSession):
    result = await session.execute(select(Roles).where(Roles.role_name == "admin"))
    search_result = result.scalar_one_or_none()
    return search_result


async def check_superadmin(session: AsyncSession):
    result = await session.execute(select(Users).where(Users.email == 'admin@sample.com'))
    search_result = result.scalar_one_or_none()
    return search_result


async def check_email_db(
        email,
        background_tasks: BackgroundTasks,
        session: AsyncSession,
        ):
    """
    Checks if an email already exists in the database.
    """
    try:
        stmt = select(Users).where(Users.email==email)
        result = await session.execute(stmt)
        search_result = result.scalars().all()
        # return searach_result
        if search_result:
            # log_async(
            #     background_tasks,
            #     f"[DB][GET_Email] User with email: {email} found.",
            #     "debug"
            # )
            return search_result
        else:
            log_async(
                background_tasks,
                f"[DB][GET_EMAIL] User with email: {email} not found in DB.",
                "info"
            )
            return None
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][CHECK_EMAIL] Error checking email '{email}': {str(e)}",
            "error"
        )
        raise Exception(f"Database error while checking email: {e}")
    

async def check_roles(session: AsyncSession):
    result = await session.execute(select(Roles).where(Roles.role_name == "admin"))
    search_result = result.scalar_one_or_none()
    return search_result


# async def main():
#     try:
#          async with async_session_maker() as session:
#             user_id_to_update = 4  # Replace with an existing user ID
#             new_name = "testUpdate2.0"
#             rows_updated = await update_user(session, user_id_to_update, name=new_name)
#             print(f"Rows updated: {rows_updated}")
#     except Exception as e:
#         print("error",e)

# async def get_all_user_main():
#     async with async_session_maker() as session:
#         result = await get_all_users(session)
#         print(result)


# if __name__ == "__main__":
# #     import asyncio
#     asyncio.run(main())
#     asyncio.run(get_all_user_main())
