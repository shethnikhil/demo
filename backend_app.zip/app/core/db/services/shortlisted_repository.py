import asyncio
from fastapi import BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
# from app.core.db.models.company_base import CreateCompany, async_session_maker
from app.core.db.models.user_base import YoutubeSearchedVideos, async_session_maker, ShortlistedVideos, Job
from sqlalchemy import select, update
from datetime import datetime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func

from typing import Optional

from app.core.db.services.common_repository import log_entry
from app.utils.logging_utils import log, log_async


async def shortlist(
        job_id,
        company_symbol,
        title,
        youtube_video_url,
        session: AsyncSession,
        background_tasks: BackgroundTasks,
        thumbnail:Optional[str]=None,
        publish_date:Optional[str]=None,
        language:Optional[str]=None,
        platform : str = None,
        notes: str = None,
    ):
    """
    Inserts a video into the shortlisted videos table.
    Returns True if successful, False otherwise.
    """
    try :
        new_shortlist = ShortlistedVideos(
            job_id=job_id,
            company_symbol=company_symbol,
            title=title,
            thumbnail=thumbnail,
            publish_date=publish_date,
            language=language,
            youtube_video_link=youtube_video_url,
            platform = platform,
            notes = notes
        )
        session.add(new_shortlist)
        await session.commit()
        await session.refresh(new_shortlist)
        if new_shortlist.job_id:
            stmt = update(
                Job
                ).where(
                    Job.job_id==job_id
                    ).values(job_status=0)
            result = await session.execute(stmt)
            await session.commit()
            updation_result = result.rowcount
            if updation_result==1:
                return True
            else:
                log.error("unable to update None to new create job")
        return True
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][SHORTLIST_INSERT] Error during insert: {str(e)}",
            "error"
        )
        return False
    
async def s3_link_updation(s3_link:str, s3_url_private: str, shortlisted_videos_id:int, session: AsyncSession):
    try:
        data = {}
        data["s3_link"] = s3_link
        data["s3_url_private"] = s3_url_private
        data["s3_link_status"] = 1
        stmt = update(
            ShortlistedVideos
            ).where(
                ShortlistedVideos.shortlisted_videos_id==shortlisted_videos_id
                ).values(**data)
        result = await session.execute(stmt)
        await session.commit()
        updation_result = result.rowcount
        return updation_result

    except Exception as e:
        log.error("Error in fetching youtube video link")
        return False
    
async def youtube_video_link(shortlisted_videos_id, session: AsyncSession):
    try:
        stmt = select(ShortlistedVideos.youtube_video_link).where(ShortlistedVideos.shortlisted_videos_id==shortlisted_videos_id)
        result = await session.execute(stmt)
        search_result = result.scalars().first()
        if search_result:
            return search_result
        else:
            return False
    except Exception as e:
        log.error("Error in s3 link video data Insertion")
        return False
    
async def update_transcription(job_id, model_transcription, language, shortlisted_video_id, session: AsyncSession):
    try:
        data = {}
        data["model_transcription"] = model_transcription
        data["language"] = language
        data["completion_status"] = True
        
        stmt = update(ShortlistedVideos).where(
            ShortlistedVideos.shortlisted_videos_id==shortlisted_video_id
            ).values(**data)
        result = await session.execute(stmt)
        await session.commit()
        update_result = result.rowcount
        # if update_result == 1:
            # job_status = await job_status_db(job_id=job_id, session=session)
            # if job_status:
            #     return update_result
            # else:
            #     log.error(f"unable yo update status for job{job_id}")
        return update_result
    
    except Exception as e:
        log.error("Error in s3 link video data Insertion")
        return False
    
async def job_status_db(job_id: int, session: AsyncSession):
    try:
        stmt = update(
            Job
            ).where(
                Job.job_id==job_id
                ).values(job_status=1)
        result = await session.execute(stmt)
        await session.commit()
        updation_result = result.rowcount
        return updation_result

    except Exception as e:
        log.error("Error in fetching youtube video link")
        return None
    

async def shortlist_video_details(shortlisted_video_id, session:AsyncSession):
    try:
        stmt = select(ShortlistedVideos).where(ShortlistedVideos.shortlisted_videos_id==shortlisted_video_id)
        result = await session.execute(stmt)
        search_result = result.scalars().first()
        # s3_link = search_result[0]
        # company_symbol = search_result[1]
        # # if search_result:
        # #     return {
        # #         "s3_link" : search_result[0],
        # #         "company_symbol" : search_result[1]
        # #     }
        # if s3_link and company_symbol:
        #     return {
        #         "s3_link" : search_result[0],
        #         "company_symbol" : search_result[1]
        #     }
        if search_result:
            return search_result
        else:
            return None
        
    except Exception as e:
        log.error(f"error in fetch shortlisted_vido details: {e}")
        return None
    
async def video_details(shortlisted_video_id, session: AsyncSession):
    try:
        stmt = select(ShortlistedVideos).where(ShortlistedVideos.shortlisted_videos_id==shortlisted_video_id)
        result = await session.execute(stmt)
        search_result = result.scalars().all()
        return search_result
    except Exception as e:
        log.error(f"error in fetch shortlisted_vido details: {e}")
        return False
    

async def get_all_shortlisted_videos(
        job_id:int,
        background_tasks:BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        stmt = select(ShortlistedVideos).where(ShortlistedVideos.job_id==job_id)
        result = await session.execute(stmt)
        search_result = result.scalars().all()
        return search_result
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][SELECT_ALL_SHORTLISTED_VIDEOS] Unexpected error: {str(e)}",
            "error"
        )
        return None
    
async def failed_status_videos(session: AsyncSession):
    try:
        stmt = select(ShortlistedVideos).join(
            Job, ShortlistedVideos.job_id == Job.job_id
            ).where(
            ShortlistedVideos.completion_status == 0,
            ShortlistedVideos.s3_link_status == 1
            ).order_by(Job.created_at.asc())
        result = await session.execute(stmt)
        search_result = result.scalars().first()
        # print(search_result)
        return search_result
    except Exception as e:
        # print(e)
        log.error(f"error in fetch shortlisted_vido details: {e}")
        return None
    
    
async def failed_video_s3_link(session: AsyncSession):
    try:
        stmt = select(ShortlistedVideos).join(Job, ShortlistedVideos.job_id == Job.job_id).where(
            ShortlistedVideos.s3_link_status == False
            ).order_by(Job.created_at.asc())
        result = await session.execute(stmt)
        search_result = result.scalars().first()
        # print(search_result)
        return search_result
    except Exception as e:
        # print(e)
        log.error(f"error in fetch shortlisted_vido details: {e}")
        return None
    
# async def main():
#     async with async_session_maker() as session:
#         result = await failed_status_videos(
#             session=session 
#         )
#         print(result)

# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())


from sqlalchemy import select, and_, or_, not_, exists
# from models import Job, ShortlistedVideos  # use your actual model names

# async def get_job_status_if_all_videos_valid(job_id: int, session: AsyncSession):
#     try:
#         # # Subquery: find videos with invalid status
#         # subquery = (
#         #     select(ShortlistedVideos.shortlisted_videos_id)
#         #     .where(
#         #         ShortlistedVideos.job_id == job_id,
#         #         or_(
#         #             ShortlistedVideos.s3_link_status == False,
#         #             ShortlistedVideos.completion_status == False
#         #         )
#         #     )
#         # )

#         # # Main query: select job_status only if no invalid videos exist
#         # stmt = (
#         #     select(Job.job_status)
#         #     .where(
#         #         Job.job_id == job_id,
#         #         not_(exists(subquery))
#         #     )
#         # )

#         # from sqlalchemy import select, exists, or_, not_

#         # Subquery: Find any invalid video for the given job
#         invalid_video_subquery = (
#             select(ShortlistedVideos.shortlisted_videos_id)
#             .where(
#                 ShortlistedVideos.job_id == job_id,
#                 or_(
#                     ShortlistedVideos.s3_link_status == False,
#                     ShortlistedVideos.completion_status == False
#                 )
#             )
#         )

#         # Main query: Only return job_status if NO invalid video exists
#         stmt = (
#             select(Job.job_status)
#             .where(
#                 Job.job_id == job_id,
#                 not_(exists(invalid_video_subquery))
#             )
#         )


#         result = await session.execute(stmt)
#         job_status = result.scalar_one_or_none()  # returns None if no result
#         print(job_status)

#         return job_status

#     except Exception as e:
#         log.error(f"Error checking job status for job_id={job_id}: {e}")
#         return None
    

# async def main():
#     async with async_session_maker() as session:
#         result = await get_job_status_if_all_videos_valid(job_id=16, session=session)
#         print(result)

# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())



async def get_job_status_if_all_videos_valid(session: AsyncSession):
    try:
        # Alias to ensure correct correlation (optional but good practice)
        # Subquery: find any invalid video for the given job
        invalid_video_exists = (
            select(ShortlistedVideos.shortlisted_videos_id)
            .where(
                ShortlistedVideos.job_id == Job.job_id,  # correlate with outer job
                or_(
                    ShortlistedVideos.s3_link_status == 0,
                    ShortlistedVideos.completion_status == 0,
                    ShortlistedVideos.s3_link_status == -1,
                    ShortlistedVideos.completion_status == -1
                )
            )
        )

        # Main query: only return job_status if NO invalid video exists
        stmt =(
            select(Job)
            .where(
                Job.job_status == 0,
                not_(exists(invalid_video_exists))
            ).order_by(Job.created_at.asc())
            .limit(1)  # get first match only
        )
            
        result = await session.execute(stmt)
        job_status = result.scalar_one_or_none()
        return job_status

    except Exception as e:
        # print(f"Error: {e}")
        return None
    

async def make_s3_failed(
        shortlisted_videos_id, 
        session: AsyncSession,
):
    try:
        stmt = update(
            ShortlistedVideos
            ).where(
                ShortlistedVideos.shortlisted_videos_id==shortlisted_videos_id
                ).values(s3_link_status=-1)
        result = await session.execute(stmt)
        await session.commit()
        updation_result = result.rowcount
        return updation_result

    except Exception as e:
        log.error(f"error in fetch make_s3_failed details: {e}")
        return None
    

async def make_llm_failed(
        shortlisted_videos_id, 
        session: AsyncSession,
):
    try:
        stmt = update(
            ShortlistedVideos
            ).where(
                ShortlistedVideos.shortlisted_videos_id==shortlisted_videos_id
                ).values(completion_status=-1)
        result = await session.execute(stmt)
        await session.commit()
        updation_result = result.rowcount
        return updation_result

    except Exception as e:
        log.error(f"error in fetch make_s3_failed details: {e}")
        return None



async def retry_failed_s3(
        shortlisted_video_id, 
        session: AsyncSession,
        background_tasks : BackgroundTasks,
):
    try:
        stmt = update(
            ShortlistedVideos
            ).where(
                ShortlistedVideos.shortlisted_videos_id==shortlisted_video_id
                ).values(s3_link_status=0)
        result = await session.execute(stmt)
        await session.commit()
        updation_result = result.rowcount
        return updation_result

    except Exception as e:
        log.error(f"error in fetch retry_failed_s3 details: {e}")
        return None
    

async def retry_failed_llm(
        shortlisted_video_id, 
        session: AsyncSession,
        background_tasks : BackgroundTasks,
):
    try:
        stmt = update(
            ShortlistedVideos
            ).where(
                ShortlistedVideos.shortlisted_videos_id==shortlisted_video_id
                ).values(completion_status=0)
        result = await session.execute(stmt)
        await session.commit()
        updation_result = result.rowcount
        return updation_result

    except Exception as e:
        log.error(f"error in fetch retry_failed_llm details: {e}")
        return None
    


# async def main():
#     async with async_session_maker() as session:
#         result = await get_job_status_if_all_videos_valid(job_id=17, session=session)
#         print(result)
    
# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())