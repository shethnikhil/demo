from fastapi import BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db.models.user_base import Users, UserRoles , Roles
from sqlalchemy import select, update
from datetime import datetime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func
from app.core.db.services.common_repository import log_entry
from app.utils.logging_utils import log, log_background, log_async



async def master_role(session: AsyncSession):
    try:
        new_role = Roles(role_name="admin", created_by=0)
        session.add(new_role)
        await session.commit()
        await session.refresh(new_role)
        result = new_role.role_id
        new_role_user = Roles(role_name="users", created_by=0)
        session.add(new_role_user)
        await session.commit()
        return result
        # print("new_user created successfully")
    except Exception as e:
        print(f"error in create roles: {e}")
        return False
         
    except Exception as e:
        raise


async def check_role_name_db(
        role_name: str,
        session: AsyncSession,
        background_tasks = BackgroundTasks,
        ):
    try:
        stmt = select(Roles).where(Roles.role_name==role_name)
        search_result = await session.execute(stmt)
        result = search_result.scalars().all()
        if result:
            return result
        else:
            return None
    except Exception as e:
        log.error(f"error in fetch Role Name: {e}")
        return None
        

async def create_role_db(
        user_id : int,
        role_name : str, 
        session: AsyncSession,
        background_tasks: BackgroundTasks,
):
    try:
        new_role = Roles(role_name=role_name, created_by = user_id)
        session.add(new_role)
        await session.commit()
        await session.refresh(new_role)
        if new_role.role_id:
            return new_role.role_id
        else:
            return None
    except Exception as e:
        log.error(f"error in create Role: {e}")
        return None
    

async def get_roles_db(
    session: AsyncSession,
    background_tasks : BackgroundTasks,
):
    try:
        stmt = select(Roles)
        result = await session.execute(stmt)
        search_result = result.scalars().all()
        if search_result:
            return search_result
        else:
            return None
        
    except Exception as e:
        # log_async()
        return None