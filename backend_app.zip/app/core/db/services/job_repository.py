from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db.models.user_base import Company, Job, async_session_maker
from sqlalchemy import select, update
from sqlalchemy.sql import func
from typing import List, Optional
from app.core.db.services.common_repository import log_entry
from app.utils.logging_utils import log, log_async
from fastapi import BackgroundTasks, HTTPException

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError


async def insert_job_to_db(
        background_tasks: BackgroundTasks,
        session: AsyncSession, 
        job_name: str, 
        company_symbol : list,
        user_id: int,
        job_desc:str = None, 
        search_start_date : Optional[str] = None,
        search_end_date : Optional[str] = None
        ):
    try:
        new_job = Job(
            job_name=job_name,
            job_desc=job_desc,
            user_id = user_id,
            company_symbol=company_symbol,
            search_start_date=search_start_date,
            search_end_date=search_end_date, 
            created_by=user_id,
            )
        session.add(new_job)
        await session.commit()
        await session.refresh(new_job)
        if new_job.job_id:
            log_entry_result = await log_entry(
                background_tasks=background_tasks,
                session=session,
                log_name="Job created",
                log_description=f"New job created by user_id {user_id}",
                previous_value=None,
                updated_value=job_name,
                changed_by=user_id)
            if log_entry_result:
                return{"status":"success", "job_id":new_job.job_id}
        return{"status":"success", "job_id":new_job.job_id}
    
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][JOB_CREATE] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return {"status": "error", "job_id": None}

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][JOB_CREATE] Validation error: {str(val_err)}",
            "error"
        )
        return {"status": "error", "job_id": None}

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][JOB_CREATE] Unexpected error: {str(e)}",
            "error"
        )
        return {"status": "error", "job_id": None}
    

async def insert_link_job_to_db(
        background_tasks: BackgroundTasks,
        session: AsyncSession, 
        job_name: str, 
        company_symbol : list,
        user_id: int,
        links :List =None,
        job_desc:str = None, 
        search_start_date : Optional[str] = None,
        search_end_date : Optional[str] = None,
        ):
    try:
        new_job = Job(
            job_name=job_name,
            job_desc=job_desc,
            user_id = user_id,
            company_symbol=company_symbol,
            search_start_date=search_start_date,
            search_end_date=search_end_date, 
            created_by=user_id,
            links=links
            )
        session.add(new_job)
        await session.commit()
        await session.refresh(new_job)
        if new_job.job_id:
            log_entry_result = await log_entry(
                background_tasks=background_tasks,
                session=session,
                log_name="Job(Links) created",
                log_description=f"New job(links) created by user_id {user_id}",
                previous_value=None,
                updated_value=job_name,
                changed_by=user_id)
            if log_entry_result:
                return{"status":"success", "job_id":new_job.job_id}
        return{"status":"success", "job_id":new_job.job_id}
    
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][JOB_CREATE] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return {"status": "error", "job_id": None}

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][JOB_CREATE] Validation error: {str(val_err)}",
            "error"
        )
        return {"status": "error", "job_id": None}

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][JOB_CREATE] Unexpected error: {str(e)}",
            "error"
        )
        return {"status": "error", "job_id": None}


    
async def select_all_jobs(
        user_id:int,
        background_tasks:BackgroundTasks,
        session: AsyncSession,
):
    try:
        # stmt = select(Job,Company.company_name).join(
        #     Company,Company.company_symbol==Job.company_symbol
        # ).where(Job.user_id==user_id)
        stmt = select(Job).where((Job.user_id==user_id) & (Job.is_archived==False)).order_by(Job.created_at.desc())
        result = await session.execute(stmt)
        job_result = result.scalars().all()
        return job_result

    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][SELECT_ALL_JOBS] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return False

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][SELECT_ALL_JOBS] Validation error: {str(val_err)}",
            "error"
        )
        return False

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][SELECT_ALL_JOBS] Unexpected error: {str(e)}",
            "error"
        )
        return False

async def select_all_archived_jobs(
        user_id:int,
        background_tasks:BackgroundTasks,
        session: AsyncSession,
):
    try:
        stmt = select(Job).where(Job.user_id==user_id, Job.is_archived==True)
        result = await session.execute(stmt)
        job_result = result.scalars().all()
        return job_result

    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][SELECT_ALL_JOBS] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return False

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][SELECT_ALL_JOBS] Validation error: {str(val_err)}",
            "error"
        )
        return False

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][SELECT_ALL_JOBS] Unexpected error: {str(e)}",
            "error"
        )
        return False
    
async def select_job_by_id(
        job_id : int,
        user_id :int,
        background_tasks: BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        stmt = select(Job).where(Job.job_id==job_id, Job.user_id==user_id)
        result = await session.execute(stmt)
        job_result = result.scalars().all()
        return job_result
    
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][SELECT_JOB_BY_ID] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return False
    
    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][SELECT_JOB_BY_ID] Validation error: {str(val_err)}",
            "error"
        )
        return False
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][SELECT_JOB_BY_ID] Unexpected error for job_id={job_id}: {str(e)}",
            "error"
        )

        return False
    

async def mark_job_as_archived(
        session: AsyncSession, 
        job_id: int,
        background_tasks: BackgroundTasks,
        user_id: int ,
        ):
    try:
        data = {}
        data["is_archived"] = True
        data["archived_by"] = user_id
        data["archived_at"] = func.now()

        stmt = update(Job).where(Job.job_id==job_id).values(**data)
        result = await session.execute(stmt)
        await session.commit()
        job_result = result.rowcount
        if job_result != 1:
            return False
        if job_result == 1:
            log_entry_result = await log_entry(
                session=session,
                background_tasks=background_tasks,
                log_name="Job archived",
                log_description=f"job with job id {job_id} archived by user_id {user_id}",
                previous_value="is_archived=0",
                updated_value="is_archived=1",
                changed_by=user_id)
            if log_entry_result:
                return True
        return True
    
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][MARK_JOB_AS_ARCHIVED] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return False

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][MARK_JOB_AS_ARCHIVED] Validation error: {str(val_err)}",
            "error"
        )
        return False
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][MARK_JOB_AS_ARCHIVED] Unexpected error archiving job_id={job_id}: {str(e)}",
            "error"
        )
        return False


async def search_job(
        job_id: int, 
        user_id:int,
        background_tasks:BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        stmt = select(Job).where(Job.job_id==job_id, Job.user_id==user_id)
        result = await session.execute(stmt)
        search_result = result.scalars().all()
        if not search_result:
            raise HTTPException(status_code=404, detail="Job not found")
        if search_result:
            return search_result
        else:
            return False
        
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][SEARCH_JOB] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        raise db_err  # Let global exception handler take over

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[VALIDATION][SEARCH_JOB] Validation error: {str(val_err)}",
            "error"
        )
        raise val_err  # Let global exception handler take over

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][SEARCH_JOB] Unexpected error for job_id={job_id}, user_id={user_id}: {str(e)}",
            "error"
        )
        raise e  # Let global exception handler take over
    

# async def search_archived_job(
#         job_id: int,
#         background_tasks:BaseException, 
#         session: AsyncSession,
#         ):
#     try:
#         stmt = select(Job).where(Job.job_id==job_id).where(Job.is_archived==True)
#         result = await session.execute(stmt)
#         search_result = result.scalars().first()
#         if search_result:
#             return True
#         else:
#             return False
        
#     except Exception as e:
#         log_async(
#             background_tasks,
#             f"[DB][SEARCH_JOB] Unexpected error during job validation for job_id={job_id}, user_id={user_id}: {str(e)}",
#             "error"
#         )

#         return False
    
async def company_symbol(job_id: int, session: AsyncSession):
    try:
        stmt = select(Job.company_symbol).where(Job.job_id==job_id)
        result = await session.execute(stmt)
        company_symbol_result = result.scalars().first()
        if company_symbol_result:
            return company_symbol_result
        else:
            return False

    except Exception as e:
        log.error(f"error in fetch company symbol: {e}")
        return False

# async def main():
#     async with async_session_maker() as session:
#         result = await search_job(job_id=1, session=session)
#         print(result)

# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())



