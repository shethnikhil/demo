import asyncio
from typing import Optional
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession
# from app.core.db.models.company_base import CreateCompany, async_session_maker
from app.core.db.models.user_base import Company, async_session_maker
from sqlalchemy import or_, select, update
from datetime import datetime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func
from app.core.db.services.common_repository import log_entry
from app.utils.logging_utils import log, log_async
from fastapi import BackgroundTasks
from sqlalchemy.exc import SQLAlchemyError


async def create_company_db(
        session: AsyncSession, 
        company_isin_no: str, 
        company_symbol: str, 
        company_name: str, 
        user_id: int,
        background_tasks: BackgroundTasks,
        ):
    try:
        # new_company = Company(isin_no=isin_no, symbol= symbol,name=name, created_by=user_id)
        new_company = Company(
            company_symbol = company_symbol,
            company_isin_no = company_isin_no,
            created_by = user_id,
            company_name=company_name
        )
        session.add(new_company)
        await session.commit()
        await session.refresh(new_company)
        if new_company.company_symbol:
            log_entry_result = await log_entry(
                background_tasks=background_tasks,
                session=session,
                log_name="Company Created",
                log_description=f"New Comapnay created by user_id {user_id}",
                previous_value=None,
                updated_value=new_company.company_name,
                changed_by=user_id
                )
            if log_entry_result:
                return{"status":"success", "company_name":new_company.company_name}
        return{"status":"success", "company_name":new_company.company_name}
    
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][CREATE_COMPANY_DB] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return None

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][CREATE_COMPANY_DB] Validation error: {str(val_err)}",
            "error"
        )
        return None
    
    except Exception as e:
        log_async(
            background_tasks, 
            f"[DB][CREATE_COMPANY_DB] Error: {str(e)}", 
            "error"
            )
        return None

async def get_all_companies_db(
        user_id:int,
        background_tasks: BackgroundTasks, 
        session: AsyncSession,
        ):
    try:
        stmt = select(Company).where(Company.is_deleted==False)
        result = await session.execute(stmt)
        company_result = result.scalars().all()
        return company_result
    
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][MARK_JOB_AS_ARCHIVED] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return []

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][MARK_JOB_AS_ARCHIVED] Validation error: {str(val_err)}",
            "error"
        )
        return []

    except Exception as e:
        return []
    
async def update_company_db(
        company_name: str,
        company_symbol:str,
        user_id: int,
        session: AsyncSession,
        background_tasks:BackgroundTasks,
        ):
    try:
        data={}
        if company_name is not None:
            data["company_name"]=company_name
        data["updated_at"]=func.now()
        data["updated_by"]=user_id

        stmt = update(Company).where(Company.company_symbol==company_symbol).values(**data)
        result = await session.execute(stmt)
        await session.commit()
        updated_result = result.rowcount
        if updated_result == 1:
            log_entry_result = await log_entry(
                background_tasks=background_tasks,
                session=session,
                log_name="Company Update",
                log_description=f"Company {company_symbol}: Updated by by user_id {user_id}",
                previous_value=None,
                updated_value=f"name:{company_name}",
                changed_by=user_id)
            if log_entry_result:
                return True
            return True
    
    except Exception as e:
        await session.rollback() # Rollback on error
        log_async(
            background_tasks,
            f"[DB][UPDATE_COMPANY_DB] Database error during company update for '{company_symbol}': {str(e)}",
            "error",
            always_sync=True
        )
        raise Exception(f"Database error during company update: {e}")

async def soft_delete_company_db(isin_no:str, deleted_by:int, session:AsyncSession):
    try:
        data = {}
        # value = {"is_deleted":True,"deleted_by":deleted_by}
        data["is_deleted"] = True
        data["deleted_by"] = deleted_by
        data["deleted_at"] = func.now()
        stmt = update(Company).where(Company.isin_no==isin_no).values(**data)
        result = await session.execute(stmt)
        await session.commit()
        delete_result = result.rowcount
        return delete_result

    except Exception as e:
        print(f"error in deleting company: {e}")
        return False
    
async def company_name(company_symbol, session:AsyncSession):
    try:
        stmt = select(Company.company_name).where(Company.company_symbol == company_symbol)
        result = await session.execute(stmt)
        name_result = result.scalars().first()
        return name_result
    except Exception as e:
        log.error(f"Error fetching company name for symbol '{company_symbol}': {e}")
        return False
    
async def check_company_db(
    session: AsyncSession,
    background_tasks:BackgroundTasks,
    company_symbol: Optional[str] = None,
    company_isin_no: Optional[str] = None,
):
    try:
        # stmt = select(Company).where(
        #     Company.company_symbol == company_symbol or 
        #     Company.company_isin_no == company_isin_no
        #     )
        # stmt = select(Company).where(
        #     or_(
        #         Company.company_symbol == company_symbol,
        #         Company.company_isin_no == company_isin_no
        #     )
        # )

        conditions = []

        if company_symbol:
            conditions.append(Company.company_symbol == company_symbol)
        if company_isin_no:
            conditions.append(Company.company_isin_no == company_isin_no)

        if not conditions:
            return []  # Nothing to search by

        stmt = select(Company).where(or_(*conditions))
        result = await session.execute(stmt)
        companies = result.scalars().first()

        return companies


        # result = await session.execute(stmt)
        # name_result = result.scalars().all()
        # return name_result
    
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][CHECK_COMPANY_DB] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        return []

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][CHECK_COMPANY_DB] Validation error: {str(val_err)}",
            "error"
        )
        return []
  
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][CHECK_COMPANY_DB] Error fetching company name for symbol '{company_symbol}': {str(e)}",
            "error"
        )
        return []



async def get_companies_detail_db(
    company_symbol, 
    session:AsyncSession,
    background_tasks: BackgroundTasks,
):
    """
    Retrieves a user from the database by their user ID.
    """
    try:
        stmt = select(Company).where(Company.company_symbol==company_symbol)
        result = await session.execute(stmt)
        search_result = result.scalars().first()
        # return searach_result
        if search_result:
            
            return search_result
        else:
            log_async(
                background_tasks,
                f"[DB][GET_COMPANY] Company with ID {company_symbol} not found in DB.",
                "info"
            )
            return None
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][GET_USER] Error fetching Company with ID {company_symbol}: {str(e)}",
            "error"
        )
        raise Exception(f"Database error while fetching Company: {e}") 
    



async def main():
    async with async_session_maker() as session:
        result = await company_name(session=session, company_symbol="ABC")
        print(result)

# async def main():
#     try:
#         async with async_session_maker() as session:
#             new_user = await create_company_db(session,"isis_no_test(1)","@1", "test1",1)
#             print(f"Comapnay Added: {new_user}")
#     except Exception as e:
#         print(f"error: {e}")


# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())
    # asyncio.run(get_all_user_main())

