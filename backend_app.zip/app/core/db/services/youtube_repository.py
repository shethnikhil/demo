import asyncio
from fastapi import BackgroundTasks, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
# from app.core.db.models.company_base import CreateCompany, async_session_maker
from app.core.db.models.user_base import YoutubeSearchedVideos, async_session_maker, ShortlistedVideos
from sqlalchemy import select, update
from datetime import datetime
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import func

from typing import Optional
from sqlalchemy import and_

from app.core.db.services.common_repository import log_entry
from app.utils.logging_utils import log, log_async
from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError

async def youtube_serached(
        job_id,
        company_symbol,
        video_url,
        session: AsyncSession,
        background_tasks: BackgroundTasks,
        title :str = None,
        thumbnail: str = None,
        publish_date: str = None, 
        completion_status= None, 
):
    
    try:
    # ########## change below variable vith db column name  
        new_searched = YoutubeSearchedVideos(
            job_id=job_id,
            company_symbol=company_symbol,
            title=title,
            thumbnail=thumbnail,
            publish_date=publish_date,
            video_url=video_url, 
            completion_status=completion_status
        )
    
        session.add(new_searched)
        await session.commit()
        await session.refresh(new_searched)
        return {"status":True, "new_id":new_searched.youtube_videos_id}
    

    except SQLAlchemyError as db_err:               # TODO remove this exception handler it block logs
        log_async(
            background_tasks,
            f"[DB][youtube_serached] SQLAlchemy error: {str(db_err)}",
            "error"
        )                                                  
        raise HTTPException(
            status_code=500,
            detail="Database error while marking job as archived"
        )

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][youtube_serached] Validation error: {str(val_err)}",
            "error"
        )
        raise HTTPException(
            status_code=400,
            detail="Data validation error while archiving job"
        )

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][youtube_serached] Unexpected error during  youtube searched database insertion: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail="Unexpected server error during  youtube searched database insertion"
        )

    
async def yt_completed_status_db(
        id: int, 
        session: AsyncSession,
        background_tasks: BackgroundTasks,
        ):
    try:
        stmt = update(YoutubeSearchedVideos).where(YoutubeSearchedVideos.youtube_videos_id==id).values(completion_status=1)
        result = await session.execute(stmt)
        await session.commit()
        status_result = result.rowcount
        return status_result

    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][COMPLETED_STATUS] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        raise db_err  # Global handler will handle this

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[VALIDATION][COMPLETED_STATUS] Validation error: {str(val_err)}",
            "error"
        )
        raise val_err  # Global handler will handle this

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][COMPLETED_STATUS] Unexpected error: {str(e)}",
            "error"
        )
        raise e
    


async def fetch_youtube_details(
        job_id:int, 
        user_id:int,
        background_tasks:BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        stmt = select(YoutubeSearchedVideos).where(
            YoutubeSearchedVideos.job_id==job_id)
        data = await session.execute(stmt)
        result = data.scalars().all()
        if result:
            return result
        else :
            return False
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][fetch_youtube_details] Unexpected error: {str(e)}",
            "error"
        )
        # log.error(f"Error in fetch youtube searched video: {e}")
        return False

    
async def fetch_yt_video_details(
        job_id:int,
        yt_video_id:int, 
        user_id:int,
        background_tasks:BackgroundTasks,
        session: AsyncSession,
        ):
    """
    Fetch YouTube video details from DB. Returns list or False on error.
    """
    try:
        # stmt = select(YoutubeSearchedVideos).where(
        #     YoutubeSearchedVideos.youtube_videos_id==yt_video_id and 
        #     YoutubeSearchedVideos.job_id==job_id)

        
        stmt = select(YoutubeSearchedVideos).where(
            (YoutubeSearchedVideos.youtube_videos_id == yt_video_id) &
            (YoutubeSearchedVideos.job_id == job_id)
        )
        data = await session.execute(stmt)
        result = data.scalars().all()
        if result:
            return result
        else :
            return False
    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][fetch_youtube_details] Unexpected error: {str(e)}",
            "error"
        )
        # log.error(f"Error in fetch youtube searched video: {e}")
        return False
    
# async def main():
#     async with async_session_maker() as session:
#         result = await youtube_serached(
#             job_id=1,
#             company_symbol="abc",
#             title="ABC_title",
#             thumbnail="ABC_Thumbnail",
#             publish_date="2025-05-21T06:57:48Z",
#             video_url="ABC_URL",
#             session=session 
#         )
#         print(result)

# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())