import asyncio
from fastapi import BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
# from app.core.db.models.company_base import CreateCompany, async_session_maker
from app.core.db.models.user_base import Log, Users

from sqlalchemy import select, update


async def log_entry(
        session: AsyncSession, 
        background_tasks:BackgroundTasks,
        log_name: str, 
        changed_by: int,
        log_description: str=None, 
        previous_value: str=None, 
        updated_value: str=None
        ):
    try:
    # log_name =  
    # log_description = 
    # previous_value =  
    # updated_value =  
    # changed_by =  
    # changed_at =  

        new_log = Log(
            log_name=log_name,
            log_description=log_description,
            previous_value=previous_value,
            updated_value=updated_value,
            changed_by=changed_by,
        )

        session.add(new_log)
        await session.commit()
        await session.refresh(new_log)

        if new_log.log_id:
            return True
        else:
            False

    except Exception as e:
        print(f"error in log entry of create job: {e}")
        return False
    
async def main():
    async with async_session_maker() as session:
        result = await log_entry(
            session=session, 
            log_name="Job created",
            log_description=f"New job created by user_id 1",
            previous_value=None,
            updated_value="job_name",
            changed_by=1)
        print(result)

async def get_user_from_db(username, session:AsyncSession):
    try:
        stmt = select(Users).where(Users.email==username)
        result = await session.execute(stmt)
        search_result = result.scalar_one_or_none() 
        if search_result:
            return search_result
        else:
            return False
    except Exception as e:
        print(f"error in get_user_from_db: {e}")
        return False
    

# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(main())