# # # from sqlalchemy import create_engine
# # from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
# # import os
# # import asyncmy



# # '''
# # TODO :- below variable should take from config
# # '''
# # db_name = "mysql"
# # db_drivername = "asyncmy"
# # db_username = "admin"
# # db_password = "root"
# # db_port = "3306"
# # db_database_name = "yts"
# # db_server = "localhost"

# # async_engine = create_async_engine(f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}")

# # # connection = engine.connect()
# # print(async_engine)

# # print(connection)
# # connection.close()
# # with engine.connect() as connection:
#     # connection.begi


# # print(engine)


# # from dotenv import load_dotenv
# # load_dotenv()


# # import asyncio
# # import asyncmy 
# # from sqlalchemy.ext.asyncio  import create_async_engine, AsyncSession
# # from sqlalchemy.orm import sessionmaker
# # from app.core.db.models.user_base import Base

# # db_name = "mysql"
# # db_drivername = "asyncmy"
# # db_username = "admin"
# # db_password = "root"
# # db_port = 3306
# # db_database_name = "yts"
# # db_server = "localhost"
# # DB_url = f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"
# # async_engine = create_async_engine(DB_url, echo=True)
# # async_session_maker = sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False )

# # async def async_create_tables(async_engine):
# #     # Base.metadata.create_all(async_engine)
# #     async with async_engine.begin() as conn:
# #         await conn.run_sync(Base.metadata.create_all)



# # async def async_remove_tables(async_engine):
# #     async with async_engine.begin() as conn:
# #         await conn.run_sync(Base.metadata.drop_all)

# # from models import Users
# from passlib.hash import bcrypt  # Example if you're hashing passwords
# # from app.core.db.models.user_base import Base, Users
# from sqlalchemy.future import select

# async def seed_admin(session: AsyncSession):
#     # Check if user already exists
#     from app.core.db.models.user_base import Base, Users
#     result = await session.execute(select(Users).where(Users.name == 'admin'))
#     admin_user = result.scalar_one_or_none()
    
#     if not admin_user:
#         admin = Users(
#             name='master user',
#             email='admin@example.com',
#             password=bcrypt.hash('Password@123master'),
#             created_by=None,
#             is_deleted=False
#         )
#         session.add(admin)
#         await session.commit()
#         print("Admin user created.")
#     else:
#         print("Admin user already exists.")

# # from app.core.db.services.db_session import get_async_session
# # from fastapi import Depends 


# async def main(operation):
#     if operation == 1:
#         await async_create_tables(async_engine)
#         print("Table create successfully")
#         from app.core.db.services.db_user_service import async_create_user
#         async with async_session_maker() as session:
#             # await seed_admin(session=session)

#             await async_create_user(
#                 session=session,
#                 name='master user',
#                 email='admin@example.com',
#                 password=bcrypt.hash('Password@123master'),
#                 role=1,
#                 created_by=None
#                 )
#         # await seed_admin(session=session)
#     elif operation == 0:
#         await async_remove_tables(async_engine)
#         print("all table removed sucessfully")



# # engine = create_engine(f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}")
# if __name__ == "__main__":
#     # async_engine = create_async_engine((f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"))
#     # create_tables(async_engine=async_engine)  
#     asyncio.run(main(0))
#     # remove_tables(engine=engine)
