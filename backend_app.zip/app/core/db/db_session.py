import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from app.core.db.models.user_base import Base
from conf.config import settings  # Assuming you have a settings module

# Create the asynchronous engine
# async_engine = create_async_engine(settings.ASYNC_DATABASE_URL, echo=False)

# Create an asynchronous session factory
# async_session_maker = sessionmaker(async_engine, expire_on_commit=False, class_=AsyncSession)

# db_name = "mysql"
# db_drivername = "asyncmy"
# db_username = "admin"
# db_password = "root"
# db_port = 3306
# db_database_name = "yts"
# db_server = "localhost"
# DB_url = f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"
# async_engine = create_async_engine(DB_url, echo=True)
# async_session_maker = sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False )

db_name = settings.db_name
db_drivername = settings.db_drivername
db_username = settings.db_username
db_password = settings.db_password
db_port = settings.db_port
db_database_name = settings.db_database_name
db_server = settings.db_server
DB_url = f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"
async_engine = create_async_engine(DB_url, echo=False) 
async_session_maker = sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False )

async def get_async_session() -> AsyncSession:
    """
    Dependency to get an asynchronous database session.
    It creates a new session for each request and closes it after t he request.
    """
    async with async_session_maker() as session:
        yield session

from contextlib import asynccontextmanager

@asynccontextmanager
async def get_async_session_context():
    async with async_session_maker() as session:
        yield session


# async def async_create_tables(async_engine):
#     # Base.metadata.create_all(async_engine)
#     async with async_engine.begin() as conn:
#         await conn.run_sync(Base.metadata.create_all)



# async def async_remove_tables(async_engine):
#     async with async_engine.begin() as conn:
#         await conn.run_sync(Base.metadata.drop_all)

# async def main(operation):
#     if operation == 1:
#         await async_create_tables(async_engine)
#         print("Table create successfully")
        
#     elif operation == 0:
#         await async_remove_tables(async_engine)
#         print("all table removed sucessfully")



# # engine = create_engine(f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}")
# if __name__ == "__main__":
#     # async_engine = create_async_engine((f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"))
#     # create_tables(async_engine=async_engine)  
#     asyncio.run(main(1))
