import graypy
import logging
from fastapi import BackgroundTasks
from conf.config import settings

# config = {
#   "LOG_MODE": "graylog",  # or "file" or "console" or graylog
#   "GRAYLOG_HOST": "127.0.0.1",
#   "GRAYLOG_PORT": 12202
# }

log = logging.getLogger('my_logger')
log.setLevel(logging.DEBUG)

log_mode = settings.log_mode

if log_mode == 'graylog':
    graylog_host = settings.graylog_host
    graylog_port = settings.graylog_port
    gelf_handler = graypy.GELFUDPHandler(graylog_host,graylog_port)
    # gelf_handler = graypy.GELFHTTPHandler(config['GRAYLOG_HOST'], config['GRAYLOG_PORT'])
    log.addHandler(gelf_handler)

elif log_mode == 'file':
    file_handler = logging.FileHandler('app.log')
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    log.addHandler(file_handler)

elif log_mode == 'console':
    stream_handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    stream_handler.setFormatter(formatter)
    log.addHandler(stream_handler)


def log_background(message: str, level: str = "info"):
    if level == "info":
        log.info(message)
    elif level == "error":
        log.error(message)
    elif level == "warning":
        log.warning(message)
    # Add more levels as needed


# def log_async(background_tasks: BackgroundTasks, message: str, level: str = "info/error"):
#     if background_tasks:
#         background_tasks.add_task(log_background, message, level)
#     else:
#         # Fallback to direct sync log (useful outside of API context)
#         log_background(message, level)



def log_async(background_tasks: BackgroundTasks, message: str, level: str = "error",always_sync=True):
    """
    Asynchronously logs a message to Graylog via background tasks.

    Args:
        background_tasks: FastAPI's BackgroundTasks dependency.
        message: The log message string.
        level: The log level (e.g., "info", "error"). Defaults to "info".
    """
    # if background_tasks:
    #     background_tasks.add_task(log_background, message, level)
    # else:
    #     # Fallback to direct sync log (useful outside of API context)
    #     log_background(message, level)



def log_async(background_tasks: BackgroundTasks, message: str, level: str = "info", always_sync=False):
    if always_sync or not background_tasks:
        log_background(message, level)  # sync logging immediately
    else:
        background_tasks.add_task(log_background, message, level)  # async, runs after response



# log.debug("This is a debug message")
# log.info("Info log sent")
# log.warning("Warning log sent")
# log.error("Error log sent")
# log.critical("Critical log sent")