# import pandas as pd

# # Load the CSV files
# df_sme = pd.read_csv('SME_EQUITY_L (1).csv')
# df_equity = pd.read_csv('EQUITY_L (1).csv')

# # Strip whitespace from column names for both DataFrames
# df_sme.columns = df_sme.columns.str.strip()
# df_equity.columns = df_equity.columns.str.strip()

# # Rename columns in df_equity to match df_sme
# df_equity = df_equity.rename(columns={
#     'NAME OF COMPANY': 'NAME_OF_COMPANY',
#     'ISIN NUMBER': 'ISIN_NUMBER'
# })

# # Select relevant columns from both DataFrames
# df_sme_selected = df_sme[['SYMBOL', 'NAME_OF_COMPANY', 'ISIN_NUMBER']]
# df_equity_selected = df_equity[['SYMBOL', 'NAME_OF_COMPANY', 'ISIN_NUMBER']]

# # Concatenate the two DataFrames
# combined_df = pd.concat([df_sme_selected, df_equity_selected], ignore_index=True)

# # Generate SQL insert queries
# sql_queries = []
# for index, row in combined_df.iterrows():
#     company_symbol = str(row['SYMBOL'])
#     company_isin_no = str(row['ISIN_NUMBER'])
#     # Corrected: Escape single quotes in company_name for SQL compatibility
#     company_name = str(row['NAME_OF_COMPANY']).replace("'", "''")
#     created_by = 1
#     created_at = 'NOW()' # Using SQL function NOW() for current timestamp
#     is_deleted = 0 # Assuming 0 for not deleted

#     query = (
#         f"INSERT INTO yts_company "
#         f"(company_symbol, company_isin_no, company_name, created_by, created_at, is_deleted) "
#         f"VALUES ('{company_symbol}', '{company_isin_no}', '{company_name}', {created_by}, {created_at}, {is_deleted});"
#     )
#     sql_queries.append(query)

# # Write queries to a .sql file for phpMyAdmin import
# output_file_name = 'yts_company_dump.sql'
# with open(output_file_name, 'w', encoding='utf-8') as f:
#     # SQL header for phpMyAdmin compatibility
#     f.write("SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n")
#     f.write("START TRANSACTION;\n")
#     f.write("SET time_zone = \"+00:00\";\n\n")
#     f.write("/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;\n")
#     f.write("/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;\n")
#     f.write("/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;\n")
#     f.write("/*!40101 SET NAMES utf8mb4 */;\n\n")

#     f.write("--\n-- Table structure for table `yts_company`\n--\n\n")
#     f.write("DROP TABLE IF EXISTS `yts_company`;\n")
#     f.write("CREATE TABLE `yts_company` (\n")
#     f.write("  `company_symbol` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,\n")
#     f.write("  `company_isin_no` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,\n")
#     f.write("  `company_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,\n")
#     f.write("  `created_by` int NOT NULL,\n")
#     f.write("  `created_at` datetime NOT NULL,\n")
#     f.write("  `updated_by` int DEFAULT NULL,\n")
#     f.write("  `updated_at` datetime DEFAULT NULL,\n")
#     f.write("  `is_deleted` tinyint(1) NOT NULL,\n")
#     f.write("  `deleted_by` int DEFAULT NULL,\n")
#     f.write("  `deleted_at` datetime DEFAULT NULL\n")
#     f.write(") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;\n\n")

#     f.write("--\n-- Dumping data for table `yts_company`\n--\n\n")
#     f.write("LOCK TABLES `yts_company` WRITE;\n")
#     f.write("/*!40000 ALTER TABLE `yts_company` DISABLE KEYS */;\n")
#     for query in sql_queries:
#         f.write(query + '\n')
#     f.write("/*!40000 ALTER TABLE `yts_company` ENABLE KEYS */;\n")
#     f.write("UNLOCK TABLES;\n")

#     # SQL footer for phpMyAdmin compatibility
#     f.write("\n/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;\n")
#     f.write("/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;\n")
#     f.write("/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;\n")
#     f.write("COMMIT;\n")

# print(f"Generated {len(sql_queries)} SQL insert queries and saved to {output_file_name}")