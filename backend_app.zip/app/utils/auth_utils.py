from passlib.context import CryptContext
from datetime import datetime, timedelta, timezone
from jose import jwt
from fastapi import HTTPException
from conf.config import settings

pwd_context = CryptContext(schemes = ["bcrypt"], deprecated = "auto")


SECRET_KEY = settings.secret_key
ALGORITHM = settings.algorithm
ACCESS_TOKEN_EXPIRE_MINUTES = settings.access_token_expire_minutes


async def create_access_token(
        data : dict,
        user_id: int,
        username: str,
        role_id: int,
        role_name: str,
        expires_delta : timedelta = None
        ):
    try:
        # to_encode = data.copy()
        to_encode = data
        expire = None
        if expires_delta:
            expire = datetime.now(timezone.utc) + expires_delta
        else:
            expire = datetime.now(timezone.utc) + timedelta(minutes = ACCESS_TOKEN_EXPIRE_MINUTES)
        to_encode.update({"exp": expire})
        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    
        response = {
            "token": encoded_jwt,
            "token_type": "Bearer",
            "expires_in": expire,
            "user": {
                "id": user_id,
                "username": username,
                "role": role_id,
                "role name": role_name
            }
        }
        return response
    
    except Exception as e:
        raise HTTPException(status_code = 401, detail = f"Error in creating access token.")
    

async def hashed_password(password:str):
    '''
    This function convert normal password into hashed password and return it.
    '''
    try:
        hashed = pwd_context.hash(password)
        return hashed
         
    except Exception as e:
        # raise HTTPException(status_code = 401, detail = "Error in Hashed passwoed")
        return None
    

async def verify_passwords(plain_password: str, hashed_password: str) -> bool:
    '''
    Verifies the entered password against the hashed password.
    Returns True if they match, otherwise False.
    '''
    try:
        return pwd_context.verify(plain_password, hashed_password)
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Error verifying password: {e}")

# def check_user_credentioals(username, password):
#     pass
#     '''
#     fuction that call user check, verify password
    # try:

# def create_refresh_token():
#     pass

