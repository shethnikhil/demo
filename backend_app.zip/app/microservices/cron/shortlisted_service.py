# from sqlalchemy.ext.asyncio import AsyncSession
# from fastapi.responses import JSONResponse
# from fastapi import BackgroundTasks, Depends, HTTPException
# # import yt_dlp
# from app.common_functions import identify_platform
# from app.core.db.services.db_session import get_async_session
# from app.core.db.services.shortlisted_repository import(
#     # shortlist,
#     s3_link_updation, 
#     youtube_video_link,
#     update_transcription,
#     shortlist_video_details,
#     video_details,
#     get_all_shortlisted_videos,
#     # failed_status_videos,
# )
# # from app.microservices.company.company_service import company_name

# from app.core.db.services.user_repository import object_to_dict
# from app.microservices.job.job_service import fetch_company_symbol

# from googleapiclient.discovery import build
# from googleapiclient.errors import HttpError

# # from app.microservices.youtube.youtube_service import yt_video_by_id
# # from app.microservices.youtube.youtube_service import yt_video_by_id
# from app.utils.logging_utils import log, log_async

# from fastapi import Query
# import httpx

# # from app.config import YOUTUBE_API_KEY # Assuming you have this file and key
# YOUTUBE_API_KEY = "AIzaSyAZPutKSww2eH4-wzjYrTkwLIEAa5XgBFs"   #TODO add in config

# # Initialize the YouTube API client
# # This 'youtube' variable is the 'Resource' object returned by build()
# youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)


# # async def shortlist_videos_service(
# #         job_id,
# #         video_id, 
# #         user_id,
# #         session: AsyncSession,
# #         background_tasks: BackgroundTasks,
# #         ):
# #     """
# #     Service to process shortlisted videos by validating and inserting into DB.
# #     Returns summary with counts and failure details.
# #     """
# #     success_count = 0
# #     failed_items = []
# #     video_id = video_id
# #     total_select_videos = len(video_id)
# #     try:
# #         for vt_video_id in video_id:
# #             try:
# #                 yt_video_data = await yt_video_by_id(
# #                     job_id=job_id,
# #                     yt_video_id=vt_video_id,
# #                     user_id=user_id,
# #                     background_tasks=background_tasks,
# #                     session=session,
# #                     )
# #                 if yt_video_data is None:
# #                     log_async(
# #                         background_tasks,
# #                         f"[SERVICE][YT_VIDEO_BY_ID] Video ID {vt_video_id} not found.",
# #                         "warning"
# #                     )
# #                     failed_items.append({
# #                         "video_id": vt_video_id,
# #                         "error": "Video not found"
# #                     })
# #                     continue
# #                 if yt_video_data:
# #                     video = yt_video_data
# #                     required_fields = ["youtube_videos_id", "job_id", "company_symbol", "video_url"]
                    
# #                     for idx, video_item in enumerate(video):
# #                         missing_fields = [field for field in required_fields if field not in video_item or video_item[field] is None]
# #                         if missing_fields:
# #                             log_async(
# #                                 background_tasks,
# #                                 f"[SERVICE][YT_VIDEO_VALIDATION] Missing fields {missing_fields} in video at index {idx}: {video_item}",
# #                                 "error"
# #                             )
# #                             failed_items.append({
# #                                 "video": video_item,
# #                                 "error": f"Missing required fields: {missing_fields}"
# #                             })
# #                             continue

# #                     # get hostname 
# #                     # hostname_result = await identify_platform(url=video_item["video_url"])
# #                     # if hostname:
# #                     #     hostname = hostname_result
# #                     # else:
# #                     #     hostname = None 

                
# #                     # if not all(k in video for k in required_fields):
# #                     #         log.error("Missing required fields.")
# #                     #         raise ValueError("Missing required fields.")
# #                     for video_item in video:
# #                         video_url = video_item["video_url"]
# #                         platform_result = await identify_platform(url=video_url)
# #                         if platform_result:
# #                             platform = platform_result
# #                         else:
# #                             platform = None

# #                         result = await shortlist(
# #                             job_id=video_item["job_id"],
# #                             company_symbol=video_item["company_symbol"],
# #                             title=video_item["title"],
# #                             thumbnail=video_item["thumbnail"],
# #                             publish_date=video_item["publish_date"],
# #                             language=video_item["language"],
# #                             youtube_video_url=video_url,
# #                             platform = platform,
# #                             session=session,
# #                             background_tasks=background_tasks,
# #                         )
# #                         if result == True:
# #                             success_count +=1
# #                         if not result:
# #                             failed_items.append({"video":video, "error":"Error in DB while data Insertion"})

# #             except Exception as ve:
# #                 failed_items.append({
# #                     "video": video,
# #                     "error": str(ve)
# #                 })


#     # success_count = 0
#     # failed_items = []
#     # video_data = data.video_data
#     # total_select_videos = len(video_data)
#     # try:
#     #     for video in video_data:
#     #         try:
#     #             required_fields = ["youtube_videos_id", "job_id", "company_symbol", "title", "video_url"]
#     #             if not all(k in video for k in required_fields):
#     #                     log.error("Missing required fields.")
#     #                     raise ValueError("Missing required fields.")
#     #             result = await shortlist(
#     #                 job_id=video["job_id"],
#     #                 company_symbol=video["company_symbol"],
#     #                 title=video["title"],
#     #                 thumbnail=video["thumbnail"],
#     #                 publish_date=video["publish_date"],
#     #                 language=video["language"],
#     #                 youtube_video_url=video["video_url"],
#     #                 session= session
#     #                 )
#     #             if result == True:
#     #                 success_count +=1
#     #             if result == False:
#     #                 failed_items.append({"video":video, "error":"Error in DB while data Insertion"})

#     #         except Exception as ve:
#     #             failed_items.append({
#     #                 "video": video,
#     #                 "error": str(ve)
#     #             })

    
        
#     # except Exception as e:
#     #     # Log unexpected exceptions with traceback
#     #     log.error(f"An unexpected error occurred during shortlist video logic for ': {e}")
#     #     # Re-raise the exception
#     #     raise

#     # finally:
#     #     return{
#     #         "total_select_videos":total_select_videos,
#     #         "success_count" : success_count,
#     #         "failed_items" : failed_items
#     #         }
    
# # USE_AWS_API = False
# async def get_download_link_service(shortlisted_videos_id, url, session: AsyncSession= Depends(get_async_session)):
#     try:
# # =================================================

#         # async with httpx.AsyncClient() as client:
#         #     aws_response = await client.post(
#         #         "https://nfesbsjsj0.execute-api.ap-south-1.amazonaws.com/api/download",
#         #         json={"url": url},
#         #         timeout=30.0
#         #     )
#         #     aws_response.raise_for_status()
#         #     data = aws_response.json()
#         #     s3_link = data.get("s3_url")
#         # async with httpx.AsyncClient(timeout=30.0) as client:
#         #     aws_response = await client.post(
#         #         "https://nfesbsjsj0.execute-api.ap-south-1.amazonaws.com/api/download",
#         #         json={"url": url},
#         #     )
#         #     aws_response.raise_for_status()
#         #     data = aws_response.json()
#         #     s3_link = data.get("s3_url")

#             s3_link = "s3://yt-surv-poc/videos/tmpBakerhouseONGCyardvideo.mkv"
#             if s3_link:
#                 result = await s3_link_updation(
#                     s3_link=s3_link, 
#                     shortlisted_videos_id=shortlisted_videos_id, 
#                     session=session
#                     )
#                 if result == 1:    
#                     return {"status":"success","download_link": s3_link}
                
#                 else:
#                     return {"status":"error","download_link": s3_link}
#             # Assume AWS returns {"s3_link": "..."}
#             # return {"download_link": s3_link}
# # =================================================


#         # use_aws_api = use_aws or USE_AWS_API
#         # if use_aws_api:
#             # Call AWS API endpoint
#             # try:
#             #     async with httpx.AsyncClient() as client:
#             #         aws_response = await client.post(
#             #             "https://your-aws-api-endpoint/api/download",
#             #             json={"url": data.video_url},
#             #             timeout=30.0
#             #         )
#             #         aws_response.raise_for_status()
#             #         data = aws_response.json()
#             #         s3_link = data.get("s3_link")
#             #         if s3_link:
#             #             result = await s3_link_updation(
#             #                 s3_link=s3_link, 
#             #                 shortlisted_videos_id=data.shortlisted_videos_id, 
#             #                 session=session
#             #                 )
#             #             if result == 1:    
#             #                 return {"status":"success","download_link": s3_link}
                        
#             #             else:
#             #                 return {"status":"error","download_link": s3_link}
#             #         # Assume AWS returns {"s3_link": "..."}
#             #         # return {"download_link": s3_link}
#             # except Exception as e:
#             #     raise HTTPException(status_code=500, detail=f"AWS API error: {str(e)}")

#         # else:
#         #     # Use yt-dlp locally
#         #     ydl_opts = ydl_opts = {
#         #         'quiet': True,
#         #         'no_warnings': True,
#         #         'skip_download': True
#         #         }
#         #     try:
#         #         with yt_dlp.YoutubeDL(ydl_opts) as ydl:
#         #             info = ydl.extract_info(data.video_url, download=True)
#         #             s3_link = info.get("url")
#         #             if s3_link:
#         #                 result = await s3_link_updation(
#         #                     s3_link=s3_link, 
#         #                     shortlisted_videos_id=data.shortlisted_videos_id, 
#         #                     session=session
#         #                     )
#         #                 if result == 1:    
#         #                     return {"status":"success","download_link": s3_link}
                        
#         #                 else:
#         #                     return {"status":"error","download_link": s3_link}
                        
#         #     except Exception as e:
#         #         raise HTTPException(status_code=400, detail=f"yt-dlp error: {str(e)}")
#     except Exception as e:
#         log.error(f"Error in S3 download link: {e}")
#         raise
    
# async def fetch_youtube_video_link(shortlisted_videos_id:int , session: AsyncSession= Depends(get_async_session)):
#     try:
#         result = await youtube_video_link(shortlisted_videos_id=shortlisted_videos_id, session=session)
#         if result:
#             return{"status":1, "data":result}
#         elif result == False:
#             return{"status":0, "data":"Video Link Not Found"}
#         else:
#             return{"status":"need extra validation","data":result}
#     except Exception as e:
#         log.error("Error in fetch youtube video link logig.")
#         raise



# data = {
#     "detected_language": "unknown",
#     "s3_url": "s3://yt-surv-poc/videos/tmpBakerhouseONGCyardvideo.mkv",
#     "symbol": "ONGC",
#     "transcription": " Guys, the car is empty now. And it's very hot. Look at this. The weather is bad. It's so hot in the garden. The weather is bad. What can we do? I'm worried about the heat. Okay. Look at this. Let's see if we can find a shop. I'm going to the call ring shop. I'm going to the call ring shop. It's very hot here. Like Pakistan. Look at this. It's like Pakistan. But it's India. Guys, I got a call ring. I'm worried about the call ring. What can we do? Let's go. I'll have a cold drink. The car is very hot. My car is parked there. This is the company. The weather is bad. Let's go. We'll go after receiving. Guys, we have a loading today. Let's see where it is. Let's see where the loading is going to be. Guys, I'm going to the call ring shop. I'll go to get a cold drink. I went to the shop but I didn't find it. I'll go to get a cold drink. I'll go to get a cold drink. I'll go to get a cold drink. It's very hot here. Let's go. Let's go. I'll go to get a cold drink. It's very hot here. Let's go."
# }

# async def llm_call_service(s3_url, symbol, shortlisted_video_id, session: AsyncSession= Depends(get_async_session)):
#     try:
#         # async with httpx.AsyncClient(timeout=30.0) as client:
#         #     aws_response = await client.post(
#         #         "https://nfesbsjsj0.execute-api.ap-south-1.amazonaws.com/api/download",
#         #         json={"url": url},
#         #     )
#         #     aws_response.raise_for_status()
#         #     data = aws_response.json()
#         #     s3_link = data.get("s3_url")

#         # async with httpx.AsyncClient(timeout=30) as client:
#         #     llm_response = await client.post(
#         #         "https://nfesbsjsj0.execute-api.ap-south-1.amazonaws.com/api/transcribe",
#                 # json={
#                 #     "s3_url":s3_url,
#                 #     "symbol":symbol
#                 # }
#         #     )
#         #     llm_response.raise_for_status()
#         #     data = llm_response.json()
#         language = data["detected_language"]
#         model_transcription = data["transcription"]

#         if model_transcription:
#             db_result = await update_transcription(
#                 model_transcription=model_transcription, 
#                 language=language, 
#                 shortlisted_video_id= shortlisted_video_id,
#                 session=session
#                 )
#             if db_result == 1:
#                 return {
#                     "status":"success",
#                     "data":data
#                     }
#             else:
#                 return { "status": "failed", "data":data}
#     except Exception as e:
#         log.exception(f"An unexpected error occurred during LLM call: {e}")
#         # Re-raise the exception
#         raise

# async def fetch_shortlisted_videos(shortlisted_videos_id,session: AsyncSession= Depends(get_async_session)):
#     try:
#         result = await shortlist_video_details(shortlisted_video_id=shortlisted_videos_id, session=session)
#         if result:
#             if result.s3_link:
#                 return result
#             else:
#                 raise HTTPException(detail="s3 link not found", status_code=404)
#         elif not result:
#             raise HTTPException(detail="s3 link not found", status_code=404)
#         else:
#             return{"status":"need extra validation","data":result}
#     except Exception as e:
#         log.exception(f"An unexpected error occurred in fetch_shortlisted_videos : {e}")
#         # Re-raise the exception
#         raise


# # async def s3_download_link(url):
# #     pass
# #     try:
# #         async with httpx.AsyncClient() as client:
# #             response = await client.post(
# #                 "https://your-aws-api-url/api/download",
# #                 json={"url": url},
# #                 timeout=30.0
# #             )
                


# ### logic for search one by one iterate over through list.

# # from sqlalchemy.ext
# # .asyncio import AsyncSession
# # from fastapi.responses import JSONResponse
# # from fastapi import Depends
# # from app.core.db.services.db_session import get_async_session
# # from app.core.db.services.db_user_service import async_create_user, update_user, delete_user

# # # from app.core.db.services.db_service import object_to_dict

# # from googleapiclient.discovery import build
# # from googleapiclient.errors import HttpError

# # # from youtube_module import Youtube
# # from app.utils.logging_utils import log
# # from typing import List

# # # from app.config import YOUTUBE_API_KEY # Assuming you have this file and key
# # YOUTUBE_API_KEY = "AIzaSyAZPutKSww2eH4-wzjYrTkwLIEAa5XgBFs"

# # # Initialize the YouTube API client
# # # This 'youtube' variable is the 'Resource' object returned by build()
# # youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)


# # async def search_youtube_videos(company_name):
# #     """
# #     Searches YouTube for videos related to the given company name.
# #     Returns the first matching video's details or None if no video is found.
# #     """
# #     try:
# #         # CORRECT CALL: Youtube().list()
# #         # 'youtube' is the service object.
# #         # '.search()' gets the search collection.
# #         # '.list()' is the method on the search collection.
# #         result = []
# #         for name in company_name:
# #             search_response = (
# #                 youtube.search() # Correct: Call the search() collection method
# #                 .list(
# #                     q=name,
# #                     part="id,snippet",
# #                     maxResults=10,
# #                     type="video",
# #                     order="date", # Most recent
# #                     videoDuration="short", # Short videos (<4 minutes)
# #                     relevanceLanguage="en", # English language
# #                 )
# #                 .execute()
# #             )
# #             log.debug("YouTube API Raw Response: %s", search_response)

# #             videos = search_response.get("items", [])
# #             if not videos:
# #                 log.info(f"No videos found for company: '{name}'")
# #                 return None # No videos found

# #             video = videos[0]
# #             video_id = video["id"]["videoId"]

# #             # IMPORTANT: Use the standard YouTube embed/watch URL format.
# #             # The URL 'https://www.youtube.com/watch?v={video_id}' is incorrect.
# #             # For a standard YouTube video, it should be:
# #             video_url = f"https://www.youtube.com/watch?v={video_id}"
# #             # Or for embedding: f"https://www.youtube.com/embed/{video_id}"

# #             video_title = video["snippet"]["title"]
# #             video_date = video["snippet"]["publishedAt"]
# #             video_thumbnail = video["snippet"]["thumbnails"]["default"]["url"]

# #             log.info(f"Found video for '{name}': Title='{video_title}', URL='{video_url}'")
# #             log.debug(f"Video Details: {{'video_url': '{video_url}', 'video_title': '{video_title}', 'company_name': '{company_name}', 'video_date': '{video_date}', 'video_thumbnail': '{video_thumbnail}'}}")

# #             result.append({
# #                 "video_url": video_url,
# #                 "video_title": video_title,
# #                 "company_name": name,
# #                 "video_date": video_date,
# #                 "video_thumbnail": video_thumbnail,
# #             })

# #         return result

# #     except HttpError as e:
# #         # Log the full exception traceback for debugging
# #         log.exception(f"YouTube API error during search for '{name}': HTTP Status: {e.resp.status}, Content: {e.content.decode()}")
# #         # Re-raise the exception so the FastAPI router can catch it and return an HTTPException
# #         raise
# #     except Exception as e:
# #         # Log unexpected exceptions with traceback
# #         log.exception(f"An unexpected error occurred during Youtube for '{name}': {e}")
# #         # Re-raise the exception
# #         raise



# async def video_status_service(shortlisted_video_id: int , session: AsyncSession= Depends(get_async_session)):
#     try:
#         result = await video_details(shortlisted_video_id=shortlisted_video_id, session=session)
#         if result:
#             data = [object_to_dict(result_data) for result_data in result]
#             return {"status":"success" , "data":data}
#         if result == False:
#             return{"status":"error","data":0}
#         else:
#             return JSONResponse(content="Extra validations",status_code=404)

#     except Exception as e:
#         # Log unexpected exceptions with traceback
#         log.exception(f"An unexpected error occurred during Shortlisted video status logic: {e}")
#         # Re-raise the exception
#         raise

# async def fetch_shortlisted_videos_service(
#         job_id:int,
#         background_tasks: BackgroundTasks,
#         session: AsyncSession,
#         ):
#     try:
#         result = await get_all_shortlisted_videos(
#             job_id=job_id,
#             background_tasks=background_tasks,
#             session=session,
#             )
#         if result:
#             data = [object_to_dict(result_data) for result_data in result]
#             return {"status": "success", "data": data}

#         else:
#             log_async(
#                 background_tasks,
#                 f"[SERVICE][FETCH_SHORTLISTED_VIDEOS] No records found for job_id={job_id}",
#                 "info"
#             )
#             return {"status": "error", "data": 0}

    
#     except Exception as e:
#         log_async(
#             background_tasks,
#             f"[SERVICE][FETCH_SHORTLISTED_VIDEOS] Unexpected error: {str(e)}",
#             "error"
#         )
#         raise


# # import time
# # import datetime

# # async def job_listner(session:AsyncSession= Depends(get_async_session)):
# #     while True:
# #         result = await failed_status_videos(session=session)
# #         if result:
# #             data = [object_to_dict(result_data) for result_data in result]
# #         if result == False:
# #             data = []
# #         else:
# #             return JSONResponse(content="Extra validations",status_code=404)
# #         now = datetime.utcnow()
        
# # job_listner()





# # so there is job associate with video so i create api that send req to llm model and get details(data) from that api and after receiving response it update status in db from false to true so i want to implement after hit the that async api it should check if status is 0 of any specific job then it should pick that id and retry after 3 tries it should retry after 1 2 hr like that.

# # so there is two fields in table s3_link_status  and completion status so now i create llm model details retry mechanism. so now senario is if s3_link is not in table if its none then llm cant processd so there is already api that fetch s3_link and insert in db so what i think we can create two retry mechanism we creaeted already for llm call so just change and in where condition we can add if s3_link_status is true and onather retry mechinizm for s3 link what you think is this one is best way and follow standard practice ?