from typing import List, Optional
from pydantic import BaseModel


# # class CompanySearchRequest(BaseModel):
# #     job_id : int
# #     # company_symbol: List[str]
# #     maxResults : int = 1
    
# # class ShortlistVideos(BaseModel):
# #     # job_id : int             
# #     # company_symbol : List[str]   
# #     # title : str
# #     # description : Optional[str] = None       
# #     # thumbnail : Optional[str] = None
# #     # publish_date : Optional[str] = None
# #     # language : Optional[str] = None           
# #     # s3_link : Optional[str] = None        
# #     # auto_transcription  : Optional[str] = None
# #     # model_transcription : Optional[str] = None
# #     # notes : Optional[str] = None
# #     # completion_status : Optional[bool] = 0

# #     video_data : List[dict]

# class ShortlistVideos(BaseModel):
#     yt_videos_id : List[int]

# class S3VideoRequest(BaseModel):
#     shortlisted_videos_id: int


# class LLMRequest(BaseModel):
#     shortlisted_videos_id: int
#     # s3_url: str
#     # symbol: List[str]       #TODO change this to str once keyword, symbol logic re riting
