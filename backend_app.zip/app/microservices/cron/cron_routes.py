# # import yt_dlp
# from app.common_functions import get_current_user, shortlist_videos_service
# from app.core.db.models.user_base import Users
# from app.utils.logging_utils import log, log_async

# from sqlalchemy.ext.asyncio import AsyncSession 
# from app.core.db.services.db_session import get_async_session
# import httpx

# from fastapi import APIRouter, BackgroundTasks, HTTPException, status, FastAPI, Depends, Query, Form
# from fastapi.responses import JSONResponse
# from app.microservices.shortlisted.shortlisted_service import (
#     get_download_link_service,
#     fetch_youtube_video_link,
#     llm_call_service,
#     fetch_shortlisted_videos,
#     video_status_service,
#     fetch_shortlisted_videos_service,
# )
# from googleapiclient.errors import HttpError
# from typing import List

# from app.microservices.shortlisted.shortlisted_schema import (
#     ShortlistVideos, 
#     S3VideoRequest,
#     LLMRequest
# )
# from app.microservices.job.job_service import get_job_by_id

# app = FastAPI()
# router_v1 = APIRouter(prefix="/v1")

# from fastapi.middleware.cors import CORSMiddleware

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # Or restrict to specific domains allow_origins=["https://your-frontend.com"]

#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# from fastapi import FastAPI
# from contextlib import asynccontextmanager
# from app.microservices.cron.retry import job_listener, s3_listener
# import asyncio

# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     print("App is starting up...")
#     asyncio.create_task(job_listener())   # LLM retry task
#     asyncio.create_task(s3_listener())    # S3 link retry task
#     yield
#     print("App is shutting down...")


# app = FastAPI(lifespan=lifespan)

# # ===============================================================================

# app.include_router(router_v1)

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run("app.microservices.cron.cron_routes:app", host="0.0.0.0", port=50028, reload=True)





from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio

# Import your retry listeners
# from app.microservices.cron.retry import job_listener, job_status_check, s3_listener
from app.microservices.cron.retry import job_listener, job_status_check, s3_listener

# Import your router
from fastapi import APIRouter
router_v1 = APIRouter(prefix="/v1")
# Make sure you add your routes to router_v1 somewhere else

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("App(CRON) is starting up...")
    # Start retry background tasks
    asyncio.create_task(s3_listener())    # S3 retry task
    asyncio.create_task(job_listener())   # LLM retry task
    asyncio.create_task(job_status_check())  #make job status 1 after all video status true
    yield
    print("App is shutting down...")

# Create app with lifesapan
app = FastAPI(lifespan=lifespan)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with your domains in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include your API router
app.include_router(router_v1)

# Run the app with uvicorn when executed directly
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.microservices.cron.cron_routes:app", host="0.0.0.0", port=50028, reload=True)


