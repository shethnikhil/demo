# # from fastapi import FastAPI
# # from sqlalchemy.ext.asyncio import AsyncSession
# # from datetime import datetime, timedelta, timezone
# # import asyncio

# # app = FastAPI()

# # # Constants
# # MAX_RETRIES = 3
# # SHORT_DELAY = 10
# # LONG_DELAY = 3600  # 1 hour
# # RETRY_TRACKER = {}

# # # --- You must implement these ---
# # from app.core.db.services.db_session import get_async_session
# # from app.core.db.services.db_user_service import object_to_dict
# # from app.core.db.services.db_shortlisted_service import failed_status_videos
# # from app.microservices.shortlisted.shortlisted_main import llm_call

# # # Run this only once
# # # SessionLocal = get_async_session()

# # RETRY_TRACKER = {
# #     "job_id": {
# #         "retries": 2,
# #         "next_try": datetime
# #     }
# # }

# # async def job_listener():
# #     while True:
# #         async with get_async_session() as session:
# #             result = await failed_status_videos(session=session)
# #             # result = RETRY_TRACKER
# #             now = datetime.now(timezone.utc) 
# #             if result:
# #                 for job in result:
# #                     job_dict = object_to_dict(job)
# #                     job_id = job_dict["shortlisted_video_id"]

# #                     retry_info = RETRY_TRACKER.get(job_id, {"retries": 0, "next_try": now})

# #                     if retry_info["next_try"] <= now:
# #                         print(f"Processing job {job_id}")
# #                         success = await llm_call(job_dict, session)
# #                         if success:
# #                             RETRY_TRACKER.pop(job_id, None)
# #                         else:
# #                             retry_info["retries"] += 1
# #                             if retry_info["retries"] > MAX_RETRIES:
# #                                 retry_info["next_try"] = now + timedelta(seconds=LONG_DELAY)
# #                             else:
# #                                 retry_info["next_try"] = now + timedelta(seconds=SHORT_DELAY)

# #                             RETRY_TRACKER[job_id] = retry_info
# #             await asyncio.sleep(5)


# import asyncio
# from datetime import datetime, timedelta, timezoane
# from app.core.db.services.db_session import get_async_session_context
# from app.core.db.services.user_repository import object_to_dict
# from app.core.db.services.shortlisted_repository import failed_status_videos, failed_video_s3_link
# from app.microservices.shortlisted.shortlisted_routes import llm_call, get_download_link

# from sqlalchemy.ext.asyncio import AsyncSession
# from fastapi.responses import JSONResponse
# from fastapi import Depends, HTTPException
# from app.utils.logging_utils import log


# MAX_RETRIES = 3
# SHORT_DELAY = 10  # TODO make 600 = 10 minutes
# LONG_DELAY = 20  # 1 hour
# RETRY_TRACKER = {}


# async def job_listener():
#     while True:
#         async with get_async_session_context() as session:
#             result = await failed_status_videos(session=session)
#             now = datetime.now(timezone.utc)

#             if result:
#                 shortlisted_videos_id = result.shortlisted_videos_id
#                 print(shortlisted_videos_id)
#                 log.info(shortlisted_videos_id)
#                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

#                 if retry_info["next_try"] <= now:
#                     print(f"Processing video for LLM:  {shortlisted_videos_id} at {now}")
#                     success = await llm_call(
#                         shortlisted_videos_id=shortlisted_videos_id, 
#                         session=session
#                         )

#                     if success:
#                         log.info(f"Processing completed successfully of shortlisted_video_id: {shortlisted_videos_id} at {now}")
#                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                     else:
#                         retry_info["retries"] += 1
#                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                         retry_info["next_try"] = now + timedelta(seconds=delay)
#                         RETRY_TRACKER[shortlisted_videos_id] = retry_info

#                 # for job in result:
#                 #     job_dict = object_to_dict(job)
#                 #     shortlisted_videos_id = job_dict["shortlisted_videos_id"]

#                 #     retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

#                 #     if retry_info["next_try"] <= now:
#                 #         print(f"Processing video for LLM:  {shortlisted_videos_id} at {now}")
#                 #         success = await llm_call(shortlisted_videos_id=shortlisted_videos_id, session=session)

#                 #         if success:
#                 #             log.info(f"Processing completed successfully of shortlisted_video_id: {shortlisted_videos_id} at {now}")
#                 #             RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                 #         else:
#                 #             retry_info["retries"] += 1
#                 #             delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                 #             retry_info["next_try"] = now + timedelta(seconds=delay)
#                 #             RETRY_TRACKER[shortlisted_videos_id] = retry_info
#             else:
#                 print("No eligible jobs found")
#                 log.info("No eligible jobs found")

#         await asyncio.sleep(60)  # ✅ Always sleep before retrying




# async def s3_listener():
#     while True:
#         async with get_async_session_context() as session:
#             result = await failed_video_s3_link(session=session)
#             now = datetime.now(timezone.utc)

#             if result:
#                 shortlisted_videos_id = result.shortlisted_videos_id
#                 print(shortlisted_videos_id)
#                 log.info(shortlisted_videos_id)
#                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})
#                 if retry_info["next_try"] <= now:
#                     # print(f"Processing job {shortlisted_videos_id} at {now}")
#                     success = await get_download_link(
#                         shortlisted_videos_id=shortlisted_videos_id,
#                         session=session
#                         )

#                     if success:
#                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                     else:
#                         retry_info["retries"] += 1
#                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                         retry_info["next_try"] = now + timedelta(seconds=delay)
#                         RETRY_TRACKER[shortlisted_videos_id] = retry_info


#                 # for job in result:
#                 #     job_dict = object_to_dict(job)
#                 #     shortlisted_videos_id = job_dict["shortlisted_videos_id"]

#                 #     retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

#                 #     if retry_info["next_try"] <= now:
#                 #         print(f"Processing job {shortlisted_videos_id} at {now}")
#                 #         success = await get_download_link(shortlisted_videos_id=shortlisted_videos_id, session=session)

#                 #         if success:
#                 #             RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                 #         else:
#                 #             retry_info["retries"] += 1
#                 #             delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                 #             retry_info["next_try"] = now + timedelta(seconds=delay)
#                 #             RETRY_TRACKER[shortlisted_videos_id] = retry_info

#         await asyncio.sleep(60)  

# ===================================================    new 1

# import asyncio
# from datetime import datetime, timedelta, timezone
# from app.core.db.services.db_session import get_async_session_context
# from app.core.db.services.user_repository import object_to_dict # Assuming this is for general object conversion
# from app.core.db.services.shortlisted_repository import failed_status_videos, failed_video_s3_link
# from app.microservices.shortlisted.shortlisted_routes import llm_call, get_download_link

# from sqlalchemy.ext.asyncio import AsyncSession
# from fastapi.responses import JSONResponse
# from fastapi import Depends, HTTPException
# from app.utils.logging_utils import log

# MAX_RETRIES = 3
# SHORT_DELAY = 10  # TODO make 600 = 10 minutes (This is for retry delay, not the immediate pause)
# LONG_DELAY = 20   # 1 hour (This is for retry delay)

# # Global tracker for retries (consider a persistent storage for production)
# RETRY_TRACKER = {} 


# async def job_listener():
#     while True:
#         async with get_async_session_context() as session:
#             # This line fetches only one record based on previous discussions.
#             # If you want to iterate over multiple failed jobs, failed_status_videos should return a list.
#             result = await failed_status_videos(session=session) 
#             now = datetime.now(timezone.utc)

#             if result: # If a job (single record) was found
#                 # Directly access the attribute since 'result' is an object here
#                 shortlisted_videos_id = result.shortlisted_videos_id 
#                 print(f"Checking shortlisted_video_id: {shortlisted_videos_id}")
#                 log.info(f"LLM call Checking shortlisted_video_id: {shortlisted_videos_id}")

#                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

#                 if retry_info["next_try"] <= now:
#                     print(f"Processing video for LLM: {shortlisted_videos_id} at {now}")
#                     success = await llm_call(
#                         shortlisted_videos_id=shortlisted_videos_id, 
#                         session=session
#                     )

#                     if success:
#                         log.info(f"Processing completed successfully of shortlisted_video_id: {shortlisted_videos_id} at {now}")
#                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                     else:
#                         retry_info["retries"] += 1
#                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                         retry_info["next_try"] = now + timedelta(seconds=delay)
#                         log.warning(f"Processing failed for {shortlisted_videos_id}. Retries: {retry_info['retries']}. Next try: {retry_info['next_try']}")

#                     RETRY_TRACKER[shortlisted_videos_id] = retry_info
                    
#                     # --- ADD THIS LINE HERE ---
#                     await asyncio.sleep(10) # Pause for 10 seconds after processing a job
#                     # --- END ADDITION ---

#             else: # No eligible jobs found
#                 print("No eligible jobs found for LLM processing.")
#                 log.info("No eligible jobs found for LLM processing.")

#         await asyncio.sleep(10) # ✅ Always sleep before retrying the next full check


# async def s3_listener():
#     while True:
#         async with get_async_session_context() as session:
#             # Assuming failed_video_s3_link also returns a single record
#             result = await failed_video_s3_link(session=session)
#             now = datetime.now(timezone.utc)

#             if result: # If a job (single record) was found
#                 # Directly access the attribute since 'result' is an object here
#                 shortlisted_videos_id = result.shortlisted_videos_id 
#                 print(f"Checking S3 download for video: {shortlisted_videos_id}")
#                 log.info(f"S3 Checking shortlisted_videos_id: {shortlisted_videos_id}")

#                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})
#                 if retry_info["next_try"] <= now:
#                     print(f"Attempting S3 download for {shortlisted_videos_id} at {now}")
#                     success = await get_download_link(
#                         shortlisted_videos_id=shortlisted_videos_id,
#                         session=session
#                     )

#                     if success:
#                         log.info(f"S3 download completed successfully for {shortlisted_videos_id} at {now}")
#                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                     else:
#                         retry_info["retries"] += 1
#                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                         retry_info["next_try"] = now + timedelta(seconds=delay)
#                         log.warning(f"S3 download failed for {shortlisted_videos_id}. Retries: {retry_info['retries']}. Next try: {retry_info['next_try']}")
                        
#                     RETRY_TRACKER[shortlisted_videos_id] = retry_info

#                     # --- ADD THIS LINE HERE ---
#                     await asyncio.sleep(10) # Pause for 10 seconds after processing a job
#                     # --- END ADDITION ---

#             else: # No eligible jobs found
#                 print("No eligible jobs found for S3 download.")
#                 log.info("No eligible jobs found for S3 download.")

#         await asyncio.sleep(10) # ✅ Always sleep before retrying the next full check




#         # ========================================================= new 2

import asyncio
from datetime import datetime, timedelta, timezone
from app.core.db.db_session import get_async_session_context
from app.core.db.services.shortlisted_repository import failed_status_videos, failed_video_s3_link, get_job_status_if_all_videos_valid, job_status_db, make_llm_failed, make_s3_failed
from app.microservices.shortlisted.shortlisted_routes import llm_call, get_download_link
from app.utils.logging_utils import log
from conf.config import settings

# MAX_RETRIES = settings.MAX_RETRIES
S3_INTERVAL = settings.S3_INTERVAL
JOB_STATUS_INTERVAL = settings.JOB_STATUS_INTERVAL
LLM_INTERVAL = settings.LLM_INTERVAL

# S3_INTERVAL=40
# LLM_INTERVAL=30
# JOB_STATUS_INTERVAL=20





# Define delays (seconds)
# RETRY_DELAYS = {
#     1: settings.first_delay,        # After 1st fail, wait 15 sec before next retry
#     2: settings.second_delay,        # After 2nd fail, wait 60 sec before next retry
#     3: settings.third_delay   # After 3rd fail, wait 120 minutes before next retry
# }

# Keep track of retry status per job_id
# RETRY_TRACKER = {}

# Helper function to get the delay for retry number
# def get_retry_delay(retry_count):
#     return RETRY_DELAYS.get(retry_count, RETRY_DELAYS[MAX_RETRIES])

# S3 retry loop
async def s3_listener():
    while True:
        # async with get_async_session_context() as session:
        #     # Get one failed S3 job (where s3_link_status == False)
        #     job = await failed_video_s3_link(session=session)
        #     now = datetime.now(timezone.utc)

        #     if job:
        #         job_id = job.shortlisted_videos_id

        #         # Get retry info for this job or initialize if not present
        #         retry_info = RETRY_TRACKER.get(job_id, {"retries": 0, "next_try": now})

        #         # Check if it's time to try this job again
        #         if retry_info["next_try"] <= now:
        #             log.info(f"[S3] Attempting job {job_id} retry #{retry_info['retries']+1} at {now}")
        #             success = await get_download_link(shortlisted_videos_id=job_id, session=session)

        #             if success:
        #                 # Success - remove from retry tracker
        #                 log.info(f"[S3] Job {job_id} succeeded at {now}")
        #                 RETRY_TRACKER.pop(job_id, None)
        #             else:
        #                 # Failure - update retry count and next try time
        #                 retry_info["retries"] += 1
        #                 delay_seconds = get_retry_delay(retry_info["retries"])
        #                 retry_info["next_try"] = now + timedelta(seconds=delay_seconds)
        #                 RETRY_TRACKER[job_id] = retry_info
        #                 log.warning(f"[S3] Job {job_id} failed retry #{retry_info['retries']}. Next try at {retry_info['next_try']}")

        #             # Wait 20 sec after each job processing attempt (success or fail)
        #             # await asyncio.sleep(20)

        #     else:
        #         # No jobs found, wait before checking again
        #         log.info("[S3] No jobs found, sleeping 20 seconds")

            # Always wait before next iteration (avoid hammering DB)
            # await asyncio.sleep(20)

        loop_start = datetime.now(timezone.utc)

        async with get_async_session_context() as session:
            job = await failed_video_s3_link(session=session)
            now = datetime.now(timezone.utc)

            if job:
                shortlisted_videos_id = job.shortlisted_videos_id
                job_id = job.job_id

                try:
                    success = await get_download_link(
                        job_id = job_id,
                        shortlisted_videos_id=shortlisted_videos_id, 
                        session=session)

                    if success:
                        log.info(f"[S3] Video {shortlisted_videos_id} succeeded at {now}")
                    else:
                        log.warning(f"[S3] Video {shortlisted_videos_id} failed")
                        make_fail = await make_s3_failed(
                            shortlisted_videos_id=shortlisted_videos_id,
                            session=session,
                        )
                        if not make_fail:
                            log.error(f"Unable to make s3_status =-1 to shortlisted_id{shortlisted_videos_id}")
                except Exception as e:
                    make_fail_call = await make_s3_failed(
                        shortlisted_videos_id=shortlisted_videos_id,
                        session=session,
                    )
                    if not make_fail_call:
                            log.error(f"Unable to make s3_status =-1 to shortlisted_id{shortlisted_videos_id}")

                    log.info("s3_status =-1 to shortlisted_id{shortlisted_videos_id}")

            else:
                log.info("[S3] No jobs found")

        # 🕒 Enforce fixed 15s interval from start of this iteration
        elapsed = (datetime.now(timezone.utc) - loop_start).total_seconds()
        sleep_time = max(0, S3_INTERVAL - elapsed)
        await asyncio.sleep(sleep_time)


# LLM retry loop
async def job_listener():
    while True:
        loop_start = datetime.now(timezone.utc)
        async with get_async_session_context() as session:
            job = await failed_status_videos(session=session)
            now = datetime.now(timezone.utc)
            if job:
                shortlisted_videos_id = job.shortlisted_videos_id
                # job_id = job.job_id

                # Check if it's time to try this job again
                try:

                    success = await llm_call(
                        shortlisted_videos_id=shortlisted_videos_id,
                        session=session
                        )

                    if success:
                        # Success - remove from retry tracker
                        log.info(f"[LLM] Job {shortlisted_videos_id} succeeded at {now}")
                    else:    
                        log.warning(f"[LLM] Job {shortlisted_videos_id} failed")
                        make_fail = await make_llm_failed(
                            shortlisted_videos_id=shortlisted_videos_id,
                            session=session,
                        )
                except Exception as e:
                    make_fail_call = await make_llm_failed(
                            shortlisted_videos_id=shortlisted_videos_id,
                            session=session,
                        )
                    if not make_fail_call:
                            log.error(f"Unable to make llm_status =-1 to shortlisted_id{shortlisted_videos_id}")

                    log.info("llm_status =-1 to shortlisted_id{shortlisted_videos_id}")

            else:
                # No jobs found, wait before checking again
                log.info("[LLM] No jobs found, sleeping 20 seconds")

        # 🕒 Enforce fixed 15s interval from start of this iteration
        elapsed = (datetime.now(timezone.utc) - loop_start).total_seconds()
        sleep_time = max(0, LLM_INTERVAL - elapsed)
        await asyncio.sleep(sleep_time)




# job_status_check
async def job_status_check():
    while True:
        loop_start = datetime.now(timezone.utc)
        async with get_async_session_context() as session:
            job = await get_job_status_if_all_videos_valid(session=session) 
            # print(job.job_id)
            # job_id = job.job_id
            # now = datetime.now(timezone.utc)
            if job:
                job_id = job.job_id

                # job_id = job.job_id

                # Get retry info or initialize
                # retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

                result = await job_status_db(job_id=job_id, session=session)
                if result:
                    log.info(f"job_status of job id {job_id} make true")
                    # print(f"job_status of job id {job_id} make true")
                else:
                    continue
                    
                    # Wait 20 sec after each job processing attempt (success or fail)

            else:
                # No jobs found, wait before checking again
                log.info("[Job] No jobs found, with incompletion status")

            # Always wait before next iteration (avoid hammering DB)


        elapsed = (datetime.now(timezone.utc) - loop_start).total_seconds()
        sleep_time = max(0, JOB_STATUS_INTERVAL - elapsed)
        await asyncio.sleep(sleep_time)



# To run these concurrently, add these in your app startup:
# asyncio.create_task(s3_listener())
# asyncio.create_task(job_listener())

