from pydantic import BaseModel    
from fastapi import Form, Query
from typing import Optional

class UserDetails(BaseModel):
    name : str 
    email : str 
    password : str 
    role : int


class UpdateUserDetails(BaseModel):
    name : str
    # update_by =  TODO add update_by  
    
# class DeleteUserDetails(BaseModel):
    # user_id : int = Form(...) 
    # update_by =  TODO add delete_by  

class LoginCreadentials(BaseModel):
    username : str
    password : str
