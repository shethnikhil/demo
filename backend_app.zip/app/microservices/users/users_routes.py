# '''
# All user related CRUD operations
# '''

from types import SimpleNamespace
from fastapi import FastAPI, Depends, BackgroundTasks, status
from fastapi import HTTPException, APIRouter
from fastapi.responses import JSONResponse
from datetime import datetime, timedelta, timezone
from app.core.db.models.user_base import Users
import sys
from app.microservices.users.users_service import (
    fetch_all_users,
    create_user_logic, 
    update_user_service,
    delete_user_service,
    fetch_user_by_id,
)
from app.microservices.users.users_schema import(
    UserDetails, 
    UpdateUserDetails, 
    # DeleteUserDetails, 
    LoginCreadentials,
)

from app.utils.logging_utils import log , log_background, log_async
from app.common_functions import check_username_service, get_current_user

import sys
from sqlalchemy.ext.asyncio import AsyncSession 
from app.core.db.db_session import get_async_session
from app.utils.auth_utils import verify_passwords, create_access_token
from app.core.db.services.user_repository import (
    check_email_db,
    get_all_users_from_db , 
    object_to_dict, 
    get_user_by_id_from_db
)

app = FastAPI()
router_v1 = APIRouter(prefix="/yt-api/v1/users")

from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For testing only; replace with your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (critical for domain access!)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["reg.nseindia.com", "ec2-3-111-213-245.ap-south-1.compute.amazonaws.com", "*"]  # Replace with your actual domain
)


@app.get("/health")
async def health():
    return JSONResponse(content="ok",status_code=200)

@router_v1.get("/get-users")
async def get_all_users(
    background_tasks: BackgroundTasks, 
    session: AsyncSession = Depends(get_async_session),
    user : Users = Depends(get_current_user)
    ):
    try:
        log.info(f"username is {user.email}, and user_id is {user.user_id}")

        result = await fetch_all_users(session=session)
        if result["status"] == 1:
            background_tasks.add_task(log_background,"User data Found","info")
            return result
        elif result["status"] == 0:
            background_tasks.add_task(log_background,"There is no data","info")
            return JSONResponse(content="There is no data", status_code= 200)
    except Exception as e:
        background_tasks.add_task(log_background,"error in get user","error")
        # log.error("error in get user")
        return HTTPException(status_code=404, detail="Error in get all users")


@app.post("/yt-api/v1/users/auth/login")
async def login(data: LoginCreadentials, session: AsyncSession= Depends(get_async_session)):
    try:
        check_u = await check_username_service(username= data.username, session=session)
        if not check_u:
            raise HTTPException(status_code=404, detail="User not found")
        
        username = check_u[0]["user"].get("email")
        hash_pass = check_u[0]["user"].get("password")
        user_id = check_u[0]["user"].get("user_id")
        role_name = check_u[0]["role"].get("role_name")
        # user_role_id = check_u[0]["role_id"]
        user_role = check_u[0]["user_role"].get("role_id")

        result = await verify_passwords(data.password, hashed_password=hash_pass)
        if not result:
            return HTTPException(detail="Invalid password", status_code=401)
        
        # now = datetime.now(timezone.utc) 
        data = {
            "sub" : username,
            "user_id": user_id,
            "role":user_role
        }
        token_result = await create_access_token(
            data=data, 
            user_id=user_id,
            username=username,
            role_id=user_role,
            role_name=role_name,
            expires_delta=timedelta(hours=12)
            )

        return token_result
        
    except Exception as e:
        log.error(f"error in login: {e}")
        return HTTPException(status_code=404, detail="Error in login")
    
from app.core.db.services.user_repository import check_roles, check_superadmin
from app.core.db.services.role_repository import master_role

@router_v1.post("/master-users")
async def create_master_user(
    background_tasks :BackgroundTasks,
    session: AsyncSession = Depends(get_async_session)
    # user: Users = Depends(get_current_user)
):
    try:
        role_result = await check_roles(session=session)
        if role_result:
            current_role = role_result.role_id
        if not role_result or role_result == None:
            role_insertion_result = await master_role(session=session)
            if not role_insertion_result:
                raise HTTPException(detail="Unable to insert master_role")
            current_role = role_insertion_result

        user_result = await check_superadmin(session=session)
        if user_result is None or user_result == False:
            master_data = {
                "name" :  "master admin",
                "email" :  "admin@sample.com",
                "password" :  "Password@123",
                "role" : current_role 
            }

            data = SimpleNamespace(**master_data)

            # log.info(f"username is {user.email}, and user_id is {user.user_id}")
            result = await create_user_logic(
                session=session, 
                data=data,
                background_tasks=background_tasks,
                user_id=0)
            if result["status"] == "success":
                log.info(f"User: {data.name}, username: {data.email} created successfully ")
                return JSONResponse(content="User created successfully", status_code=201)
            else:
                return JSONResponse(content="User creation failed", status_code=404)
    
        if user_result:
            return JSONResponse(content="Master data already inserted", status_code=201)
        
    except Exception as e:
        log.info(f"Master user and role already in db.")
        return JSONResponse(content="Master data already inserted", status_code=201)

@router_v1.post("/users")
async def create_user(
    data: UserDetails, 
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
):
    try:
        # log.info(f"username is {user.email}, and user_id is {user.user_id}")
        check_email_exists = await check_email_db(
            email=data.email,
            session=session,
            background_tasks=background_tasks,
        )
        if check_email_exists:
            log_async(
                background_tasks,
                f"[API][CREATE_USER][EMAIL_CHECK] Attempted to create user with existing email: {data.email}.",
                "info"
            )
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email is already registered. Please use a different email."
            )

        result = await create_user_logic(background_tasks=background_tasks,session=session, data=data, user_id=user.user_id)
        if result["status"] == "success":
            log.info(f"User: {data.name}, username: {data.email} created successfully ")
            return{"status": 1 , "message":"User created successfully"}
        else:
            raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="User creation failed"
        )
    
    except Exception as e:
        log.error(f"[API][CREATE_USER] Unexpected error during user creation for email {data.email}: {e}", exc_info=True) # exc_info=True for traceback
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected internal server error occurred during user creation."
        )
    
@router_v1.get("/users/{user_id}")
async def get_user_by_id(
    user_id:int,
    background_tasks : BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user : Users = Depends(get_current_user)):
    try:
        check_user_id = await get_user_by_id_from_db(
            user_id=user_id, 
            background_tasks=background_tasks,
            session=session,
            )
        if check_user_id is None or check_user_id==False:
            return HTTPException(detail="Invalide user_id", status_code=404)
        # curret_username = check_user_id.name

        result = await fetch_user_by_id(
            user_id=user_id, 
            background_tasks=background_tasks,
            session=session,
            )
        if result:
            log_async(
                background_tasks,
                f"[USER_FETCH] Info: No user found with {result}",
                "info"
            )
            return result
        
        else:
            log_async(
                background_tasks,
                f"[USER_FETCH] Info: No user found with user_id={user_id}",
                "info"
            )
            return JSONResponse(content="There is no data", status_code= 200)
            # return JSONResponse{"message": "There is no data", s : 200}

    except Exception as e:
        log_async(
            background_tasks,
            f"[USER_FETCH] Error: Failed to get user with user_id={user_id}. Exception: {e}",
            "error"
        )
        raise HTTPException(status_code=404, detail="Error in get all users")
    
@router_v1.patch("/update_user/{u_user_id}",status_code=status.HTTP_200_OK)
async def update_user_handler(
    data: UpdateUserDetails,
    u_user_id : int,
    background_tasks : BackgroundTasks,
    user : Users = Depends(get_current_user),
    session: AsyncSession = Depends(get_async_session),
    ):
    try:
        user_id = user.user_id
        check_user_id = await get_user_by_id_from_db(
            user_id=u_user_id, 
            background_tasks=background_tasks,
            session=session,
            )
        if not check_user_id: 
            log_async(
                background_tasks,
                f"[API][UPDATE_USER] User with ID {u_user_id} not found.",
                "warning"
            )
            
            raise HTTPException(
                detail="User not found.",
                status_code=status.HTTP_404_NOT_FOUND
            )

        current_name = check_user_id.name
        result = await update_user_service(
            user_id = user_id,
            current_name = current_name,
            background_tasks = background_tasks,
            session=session, 
            data=data,
            u_user_id=u_user_id,
            )
        if result:
            log_async(
                background_tasks,
                f"[API][UPDATE_USER] User with ID {user_id} updated successfully.",
                "info"
            )
            return {"message": "User updated successfully."}
        else:
            log_async(
                background_tasks,
                f"[API][UPDATE_USER] Failed to update user with ID {user_id} after service call.",
                "error" 
            )
            raise HTTPException(
                detail="Failed to update user details.",
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR # Or 400 if it's a client data issue
            )



    except HTTPException as http_exc:
        # Re-raise FastAPI's HTTPException to be handled by FastAPI's error handling
        raise http_exc
    except Exception as e:
        log_async(
            background_tasks,
            f"[API][UPDATE_USER] Unexpected error while updating user {user_id}: {str(e)}",
            "error"
        )
        raise HTTPException(
            detail="An unexpected error occurred.",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
    

@router_v1.put("/delete_user/{target_user_id}")
async def soft_delete_user_handler(
    target_user_id : int,
    background_tasks: BackgroundTasks,
    session: AsyncSession= Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id = user.user_id
        deleted_result = await get_user_by_id_from_db(
            user_id = target_user_id,
            session=session,
            background_tasks=background_tasks,
        )
        if not deleted_result:
            log_async(
                background_tasks,
                f"[API][DELETE_USER] Attempted soft-delete for non-existent user ID: {target_user_id}.",
                "info",
                always_sync=True
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with ID {target_user_id} not found."
            )
        if deleted_result.is_deleted:
            log_async(
                background_tasks,
                f"[API][DELETE_USER] User {target_user_id} is already marked as deleted.",
                "info",
                always_sync=True
            )
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"User with ID {target_user_id} is already deleted."
            )
        if target_user_id == user_id:
            log_async(
                background_tasks,
                f"[API][DELETE_USER] Self Deletion Not Allow",
                "info" ,
                always_sync=True
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
                detail=f"Self Deletion Not Allow"
            )
        result = await delete_user_service(
            target_user_id,
            user_id,
            background_tasks=background_tasks, 
            session=session)
        if result and result.get("status") == "success":
            log_async(
                background_tasks,
                f"[API][DELETE_USER] User {target_user_id} soft-deleted successfully by user {user_id}.",
                "info"
            )
            return JSONResponse(
                content={"message": result.get("message")},
                status_code=status.HTTP_200_OK # Or HTTP_204_NO_CONTENT if no content
            )
        elif result and result.get("status") == "not_found":
            log_async(
                background_tasks,
                f"[API][DELETE_USER] Soft-delete failed for user {target_user_id}: User not found by service.",
                "info",
                always_sync=True
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=result.get("message")
            )
        else: # Catches "error" or unexpected results from service
            log_async(
                background_tasks,
                f"[API][DELETE_USER] Soft-delete failed for user {target_user_id} due to service error. Result: {result}",
                "error"
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.get("message", "An internal server error occurred during soft-deletion.")
            )

    except HTTPException as http_exc:
    # Re-raise explicit HTTPExceptions to be caught by FastAPI
        raise http_exc
    
    except Exception as e:
        log_async( # Use log_async here
            background_tasks,
            f"[API][DELETE_USER] Unexpected error during soft-deletion of user {target_user_id}: {str(e)}",
            "error",
            exc_info=True # Crucial for debugging unexpected errors
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected internal server error occurred."
        )
    
app.include_router(router_v1)

import uvicorn
if __name__ == "__main__":
    uvicorn.run("app.microservices.users.users_routes:app", host="0.0.0.0", port=50000, reload=True)
