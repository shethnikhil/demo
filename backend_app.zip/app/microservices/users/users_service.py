'''
User related function logic
'''

from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import JSONResponse
from fastapi import Depends, BackgroundTasks
from app.core.db.db_session import get_async_session
from app.core.db.services.user_repository import(
    async_create_user, 
    update_user_db, 
    delete_user_db,
)

# from app.core.db.services.db_service import object_to_dict
from app.core.db.services.user_repository import (
    get_all_users_from_db, 
    object_to_dict, 
    get_user_by_id_from_db
)
from app.utils.auth_utils import hashed_password
from app.utils.logging_utils import log, log_background, log_async

async def fetch_all_users(session: AsyncSession = Depends(get_async_session)):
    try:
        users_result = await get_all_users_from_db(session=session)
        if users_result is not None:
            result = [object_to_dict(users_result_obj) for users_result_obj in users_result]
            return {"status": 1, "message": result}
        else:
            return {"status": 0, "message": "No user found."}
    except Exception as e:
        return JSONResponse(content="Failed to retrieve users.", status_code=404)
    
async def create_user_logic(
        data,  
        user_id, 
        background_tasks: BackgroundTasks, 
        session: AsyncSession = Depends(get_async_session)):
    try:
        # password hashing
        password = str(data.password)
        hash_result = await hashed_password(password = password)
        if hash_result:
            password = hash_result
        if not hash_result:
            password = password
        create_user = await async_create_user(
            background_tasks=background_tasks,
            session=session, 
            name=data.name, 
            email=data.email, 
            password=password, 
            role=data.role, 
            created_by=user_id
            )
        if create_user:
            # result = [object_to_dict(create_user_obj) for create_user_obj in create_user]
            return {"status":"success"}
        else:
            return{"status":"error", "message":f"Unable to create user:"}
    except Exception as e:
        print(f"Error in Create User {e}")
        return JSONResponse(content="Failed to create user", status_code=404)
    
async def update_user_service(
        user_id,
        current_name,
        u_user_id,
        data, 
        background_tasks : BackgroundTasks,
        session: AsyncSession,
        ):
    """
    Handles the business logic for updating user details.
    """
    try:
        log_async(
            background_tasks,
            f"[SERVICE][UPDATE_USER] Attempting to update user {user_id} with new data.",
            "info"
        )
        name=data.name
        result = await update_user_db(
            background_tasks=background_tasks,
            name=name,
            session=session, 
            current_name = current_name,
            user_id=user_id,
            u_user_id=u_user_id,
            )
        if result:
            log_async(
                background_tasks,
                f"[SERVICE][UPDATE_USER] User {user_id} successfully updated by DB operation.",
                "info"
            )
            return True    
        else: 
            log_async(
                background_tasks,
                f"[SERVICE][UPDATE_USER] DB operation failed to update user {user_id}.",
                "warning"
            )
            return False
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][UPDATE_USER] Error in update_user_service for user {user_id}: {str(e)}",
            "error"
        )
        # Re-raise the exception to be caught by the API handler, or raise a custom service error.
        raise Exception(f"Service error while updating user: {e}")

    
async def delete_user_service(
        target_user_id: int,
        user_id: int,
        background_tasks: BackgroundTasks,
        session: AsyncSession,
        ):
    """
    Handles the business logic for soft deleting a user.
    """
    try:
        result = await delete_user_db(
            target_user_id=target_user_id,
            deleted_by_user_id=user_id,
            session=session,
            background_tasks=background_tasks
        )
        if result is True: # `True` indicates successful deletion from DB layer
            log_async(
                background_tasks,
                f"[SERVICE][DELETE_USER] User ID {target_user_id} successfully soft-deleted by DB operation.",
                "info"
            )
            return {"status": "success", "message": f"User with ID {target_user_id} soft-deleted successfully."}
        elif result is False: # `False` indicates user not found/no rows affected from DB layer
            log_async(
                background_tasks,
                f"[SERVICE][DELETE_USER] Soft-delete failed for user ID {target_user_id}: User not found in DB or no change.",
                "error"
            )
            return {"status": "not_found", "message": f"User with ID {target_user_id} not found or already deleted."}
        else: # Catch any other unexpected return from DB layer
            log_async(
                background_tasks,
                f"[SERVICE][DELETE_USER] Unexpected result from DB operation for user ID {target_user_id}. Result: {result}",
                "error"
            )
            return {"status": "error", "message": f"Unexpected error during soft-deletion process."}

    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][DELETE_USER] Error in soft-delete service for user ID {target_user_id}: {str(e)}",
            "error",
            exc_info=True # Include traceback
        )
        # Re-raise the exception to be handled by the API layer
        raise Exception(f"Service error while soft-deleting user: {e}")
    
# async def fetch_details(user):


async def fetch_user_by_id(
        user_id:int, 
        background_tasks :BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        users_result = await get_user_by_id_from_db(
            user_id=user_id,
            background_tasks=background_tasks,
            session=session)
        if users_result is not None:
            # result = [object_to_dict(users_result_obj) for users_result_obj in users_result]
            return {"status": 1, "message": users_result}
        else:
            return {"status": 0, "message": "No user found."}
            
    except Exception as e:
        log_async(
            log_background,
            f"[LOGIC] Error in fetch user details: {e}",
            "error"
        )
        return JSONResponse(content="Failed to retrieve users.", status_code=404)
    