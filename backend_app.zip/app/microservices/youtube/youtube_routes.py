# import yt_dlp
from app.common_functions import get_current_user
from app.core.db.models.user_base import Users
# from app.microservices.youtube.youtube_schema import YoutubeVideoLinks
from app.utils.logging_utils import log, log_async

from sqlalchemy.ext.asyncio import AsyncSession 
from app.core.db.db_session import get_async_session
import httpx

from fastapi import APIRouter, BackgroundTasks, HTTPException, status, FastAPI, Depends, Query, Form
from fastapi.responses import JSONResponse
from app.microservices.youtube.youtube_service import (
    process_youtube_search_for_company,
    youtube_details_by_id,
    youtube_link_service,
)
from googleapiclient.errors import HttpError
from typing import List, Optional

# from app.microservices.youtube.youtube_schema import (
#     CompanySearchRequest, 
# )
from app.microservices.job.job_service import get_job_by_id
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError

# from app.core.exception_handlers import (
#     global_exception_handler,
#     sqlalchemy_exception_handler,
#     validation_exception_handler,
#     request_validation_exception_handler
# )

app = FastAPI()
router_v1 = APIRouter(prefix="/yt-api/v1/yt-search")

from fastapi.middleware.cors import CORSMiddleware

from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For testing only; replace with your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (critical for domain access!)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["reg.nseindia.com", "ec2-3-111-213-245.ap-south-1.compute.amazonaws.com", "*"]  # Replace with your actual domain
)


@app.get("/health")
async def health():
    return JSONResponse(content="ok",status_code=200)
# Register global handlers
# app.add_exception_handler(Exception, global_exception_handler)
# app.add_exception_handler(SQLAlchemyError, sqlalchemy_exception_handler)
# app.add_exception_handler(ValidationError, validation_exception_handler)
# app.add_exception_handler(RequestValidationError, request_validation_exception_handler)


@router_v1.post(
    "/Youtube/{job_id}",
    summary="Search YouTube for company-related videos",
    description="Searches YouTube for the most recent short video related to a given company name."
)
async def youtube_company_video_search(
    job_id : int,
    # data: CompanySearchRequest,
    background_tasks: BackgroundTasks,
    user: Users = Depends(get_current_user),
    session: AsyncSession = Depends(get_async_session),
    maxResults : Optional[int] = 100,
):
    """
    Endpoint to search for a company's video on YouTube.

    - **company_name**: The name of the company to search for.
    """
    try:
        user_id = user.user_id
        result = await get_job_by_id(
            job_id=job_id,
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
        )
        if result == False or result is None:
            raise HTTPException(status_code=404, detail="Invalid Job") 
        
        video_details =  await process_youtube_search_for_company(
            maxResults=maxResults, 
            job_id=job_id,
            user_id=user_id,
            session=session,
            background_tasks=background_tasks,
            result=result,
            )


        if video_details:
            return video_details
        
        if video_details["status"] == 0:
            raise HTTPException(status_code=500, detail=video_details["message"])
        
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No video found."
            )

    except HttpError as e:
        log.error(f"YouTube API error: {e.resp.status} - {e.content.decode()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while communicating with the YouTube API: {e.content.decode()}"
        )
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[ROUTE][YOUTUBE_COMPANY_VIDEO_SEARCH] Unexpected error for job_id={job_id}: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred. Please try again later."
        )
    

@router_v1.post(
    "/Youtube/links/{job_id}",
)
async def youtube_video_links_search(
    job_id : int,
    background_tasks: BackgroundTasks,
    user: Users = Depends(get_current_user),
    session: AsyncSession = Depends(get_async_session),
    # maxResults : Optional[int] = 100,
):

    try:
        user_id = user.user_id
        result = await get_job_by_id(
            job_id=job_id,
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
        )
        if result == False or result is None:
            raise HTTPException(status_code=404, detail="Invalid Job") 
        
        links = result[0].links
        # if links is None:
        #     raise HTTPException(status_code=404, detail="Invalid Job")
        
        video_details =  await youtube_link_service(
            # maxResults=maxResults, 
            job_id=job_id,
            user_id=user_id,
            links=links,
            session=session,
            background_tasks=background_tasks,
            result=result,
            )


        if video_details:
            return video_details
        
        if video_details["status"] == 0:
            raise HTTPException(status_code=500, detail=video_details["message"])
        
        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No video found."
            )

    except HttpError as e:
        log.error(f"YouTube API error: {e.resp.status} - {e.content.decode()}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while communicating with the YouTube API: {e.content.decode()}"
        )
    
    except Exception as e:
        log_async(
            background_tasks,
            f"[ROUTE][YOUTUBE_COMPANY_VIDEO_SEARCH] Unexpected error for job_id={job_id}: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred. Please try again later."
        )
    

@router_v1.get("/Youtube/{job_id}")
async def get_yt_search_handler(
    job_id:int,
    background_tasks: BackgroundTasks,
    session: AsyncSession= Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id = user.user_id
        job_id_check = await get_job_by_id(
            job_id,
            user_id=user_id,
            session=session,
            background_tasks=background_tasks,
            )
        if job_id_check == False or job_id_check is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Invalid Job")   
             
        result = await youtube_details_by_id(
            job_id=job_id, 
            user_id=user_id,
            session=session,
            background_tasks=background_tasks,
            )

        if result["status"] == 1:
            return JSONResponse(content=result["data"], status_code=200)
        elif result["status"] == 0:
            return JSONResponse(content=result["data"], status_code=200)
        else:
            log_async(
                background_tasks,
                f"[ROUTE][GET_YT_SEARCH_HANDLER] Need Extra Validations job_id={job_id}: {str(e)}",
                "error"
            )
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Need extra validation")

    except Exception as e:
        log_async(
            background_tasks,
            f"[ROUTE][GET_YT_SEARCH_HANDLER] Unexpected error for job_id={job_id}: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred. Please try again later."
        )


app.include_router(router_v1)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.microservices.youtube.youtube_routes:app", host="0.0.0.0", port=50016, reload=True)
