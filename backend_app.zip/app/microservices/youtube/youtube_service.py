from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import JSONResponse
from fastapi import BackgroundTasks, Depends, HTTPException
# import yt_dlp
from app.common_functions import get_current_user, identify_platform, shortlist_videos_service
from app.core.db.models.user_base import Users
from app.core.db.services.company_repository import check_company_db
from app.core.db.db_session import get_async_session
from app.core.db.services.youtube_repository import(
    youtube_serached, 
    yt_completed_status_db, 
    fetch_youtube_details,
)
# from app.microservices.company.company_service import company_name

from app.core.db.services.user_repository import object_to_dict
from app.microservices.job.job_service import fetch_company_symbol

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from app.microservices.keywords.keywords_service import company_keyword
from app.microservices.shortlisted.shortlisted_schema import ShortlistVideos
from app.utils.logging_utils import log, log_async

from fastapi import Query
import httpx

from pytube import YouTube
from pytube.exceptions import VideoUnavailable

# from app.config import YOUTUBE_API_KEY # Assuming you have this file and key
YOUTUBE_API_KEY = "AIzaSyAZPutKSww2eH4-wzjYrTkwLIEAa5XgBFs"   #TODO add in config

# Initialize the YouTube API client
# This 'youtube' variable is the 'Resource' object returned by build()
youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)



async def process_youtube_search_for_company(
        maxResults,
        result,
        job_id: int,
        user_id:int,
        session:AsyncSession,
        background_tasks: BackgroundTasks,
):
    """
    Searches YouTube for videos related to the given company name.
    Returns the first matching video's details or None if no video is found.
    """
    try:
        if result[0].company_symbol:
            company_symbol_list = result[0].company_symbol
        else: 
            log_async(
                background_tasks,
                f"[SERVICE][YOUTUBE_PROCESS] Company Details Not Found for Job id: {job_id}",
                "error"
            )
            raise HTTPException(
            status_code=404,
            detail=f"No company details found:"
            )

        all_data = {}

        for symbol in company_symbol_list:
            keyword_result = await company_keyword(
                company_symbol=symbol,
                session=session,
                background_tasks=background_tasks,
                )
            if keyword_result["company_name"] is None:
                log_async(
                    background_tasks,
                    f"[SERVICE][YOUTUBE_PROCESS] Company Details Not Found for Job id: {job_id}",
                    "error"
                )
                return JSONResponse(
                    content=f"No company details found:",
                    status_code=404,
                )
            if keyword_result["company_name"]:
                c_name = keyword_result["company_name"]
            else:
                log_async(
                    background_tasks,
                    f"[SERVICE][YOUTUBE_PROCESS] Company Details Not Found for Job id: {job_id}",
                    "error"
                )
                raise HTTPException(
                status_code=404,
                detail=f"No company details found:"
                )
            if keyword_result["keywords"]:
                all_keyword = keyword_result["keywords"]
            if not keyword_result["keywords"] or keyword_result["keywords"] is None:
                all_keyword = [c_name]
                # company_name_search = await check_company_db(
                #     company_symbol=symbol,
                #     background_tasks=background_tasks,
                #     session=session)
                # # keyword_result=list(company_name.company_name)
                # if isinstance(company_name_search.company_name, str):
                #     all_keyword = [company_name.company_name]
                # else:
                #     all_keyword = list(company_name.company_name)
                # if company_name.company_name:
            query = " | ".join(all_keyword)
            search_response = (
                youtube.search() # Correct: Call the search() collection method
                .list(
                    q=query,
                    part="id,snippet",
                    maxResults=maxResults,
                    type="video",
                    order="date", 
                    videoDuration="short", # Short videos (<4 minutes)
                    relevanceLanguage="en", # English language
                )
                .execute()
            )
            # items = search_response.get("items", [])
            # result = []
            # if len(items) == 0:
            #     all_data[f"{c_name}"] = []

            items = search_response.get("items", [])
            video_dict = {}

            if not items:
                all_data[c_name] = {}
                continue

            else:
                for video in items:
                    video_id = video["id"]["videoId"]
                    video_url = f"https://www.youtube.com/watch?v={video_id}"
                    video_title = video["snippet"]["title"]
                    video_date = video["snippet"]["publishedAt"]
                    video_thumbnail = video["snippet"]["thumbnails"]["default"]["url"]
                    
                    # result.append({
                    #     "video_title": video_title,
                    #     "video_url": video_url,
                    #     "video_date": video_date,
                    #     "video_thumbnail": video_thumbnail
                    # })

                    db_result = await youtube_serached(
                        job_id=job_id,
                        company_symbol=symbol,  #TODO what should be company_symbol in bd?
                        title=video_title,
                        thumbnail=video_thumbnail,
                        publish_date=video_date,
                        video_url=video_url,
                        session= session, 
                        background_tasks=background_tasks,
                    )

                    if not db_result["status"]:
                        log_async(
                            background_tasks,
                            f"[DB][YOUTUBE_INSERTION] Failed to insert video '{video_title}' for symbol={symbol}, job_id={job_id}",
                            "error"
                        )
                        continue  # Instead of returning, skip and keep processing

                    new_id = db_result["new_id"]

                    completion_result = await yt_completed_status_db(
                        id=new_id,
                        session=session,
                        background_tasks=background_tasks
                    )
                    if completion_result != 1:
                        log_async(
                            background_tasks,
                            f"[SERVICE][YOUTUBE_SEARCH] Unable to update completion status for YouTube search video ID: {new_id}",
                            "error"
                        )

                    video_dict[str(new_id)] = {
                        "video_title": video_title,
                        "video_url": video_url,
                        "video_date": video_date,
                        "video_thumbnail": video_thumbnail
                        # "youtube_video_id": new_id
                    }

                all_data[c_name] = video_dict
        
        return all_data


    except HttpError as e:
        log_async(
            background_tasks,
            f"[SERVICE][YOUTUBE_SEARCH] YouTube API error: HTTP Status: {e.resp.status}, Content: {e.content.decode()}",
            "error"
        )
        return {"status": 0, "message": "YouTube API communication error"}

    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][YOUTUBE_SEARCH] Unexpected error: {str(e)}",
            "error"
        )
        return {"status": 0, "message": "Unexpected error during YouTube search"}




async def youtube_details_by_id(
        job_id, 
        user_id,
        session: AsyncSession,
        background_tasks: BackgroundTasks,
        ):
    try:
        result = await fetch_youtube_details(
            job_id=job_id,
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
            )
        if result:
            data = [object_to_dict(search_data) for search_data in result]
            return{"status":1, "data":data}
        elif result == False:
            return{"status":0, "data":"No Search Data Found"}
        else:
            return{"status":"need extra validation","data":result}
        
    except Exception as e:
        # Log unexpected exceptions with traceback
        log.error(f"An unexpected error occurred during Youtube for ': {e}")
        # Re-raise the exception
        raise

# async def yt_video_by_id(
#         job_id:int, 
#         yt_video_id:int, 
#         user_id:int,
#         session: AsyncSession,
#         background_tasks: BackgroundTasks,
#         ):
#     """
#     Fetch YouTube video data by ID and convert to dict.
#     Returns list of dicts or None.
#     """
#     try:
#         result = await fetch_yt_video_details(
#             job_id=job_id,
#             yt_video_id=yt_video_id,
#             user_id=user_id,
#             background_tasks=background_tasks,
#             session=session,
#             )
#         if result:
#             data = [object_to_dict(search_data) for search_data in result]
#             # return{"status":1, "data":data}
#             return data
#         elif result == False:
#             # return{"status":0, "data":"No Search Data Found"}
#             log_async(
#                 background_tasks,
#                 f"[SERVICE][YT_VIDEO_BY_ID] No data found for yt_video_id={yt_video_id}",
#                 "warning"
#             )
#             return None
#         else:
#             # return{"status":"need extra validation","data":result}.
#             log_async(
#                 background_tasks,
#                 f"[SERVICE][YT_VIDEO_BY_ID] No data found for yt_video_id={yt_video_id}",
#                 "warning"
#             )
#             return None
        
#     except Exception as e:
#         # Log unexpected exceptions with traceback
#         log.error(f"An unexpected error occurred during Youtube for ': {e}")
#         # Re-raise the exception
#         raise


async def youtube_link_service(
        job_id,
        user_id,
        links,
        result,
        session: AsyncSession,
        background_tasks: BackgroundTasks,
):
    try:
        if len(links) == 0 or len(links) > 10:
            raise HTTPException(
                detail="Invalid number of links",
                status_code=400,
            )

        all_yt_id = []

        for video in links:
            video_dict = {}
            video_url = video
            video_title = None                          # TODO chech it is affect condition 1 youtube title available 2. not available
            video_date = None
            video_thumbnail = None

            platform_result = await identify_platform(url= video)
            if platform_result == "YouTube":
                video_data = await is_youtube_link_valid(video_url=video)
                if not video_data:
                    log.info(f"invalid url {video}")
                    # all_yt_id[video] = {"Invalide Link"}
                    # video_url = video
                    # video_title = "Invalide URL"                          # TODO check if it fails so what?
                    # video_date = "Invalide URL"
                    # video_thumbnail = "Invalide URL"
                    continue

                item = video_data["items"][0]
                snippet = item["snippet"]
                video_url = video
                video_title = snippet["title"]
                video_date = snippet["publishedAt"]
                video_thumbnail = snippet["thumbnails"]["default"]["url"]
            

                

            db_result = await youtube_serached(
                job_id=job_id,
                company_symbol="Generic",
                title=video_title,
                thumbnail=video_thumbnail,
                publish_date=video_date,
                video_url=video_url,
                session=session,
                background_tasks=background_tasks,
                completion_status = None
            )

            if not db_result["status"]:
                log_async(
                    background_tasks,
                    f"[DB][YOUTUBE_INSERTION] Failed to insert video '{video_title}' for symbol=Generic, job_id={job_id}",
                    "error"
                )
                continue

            new_id = db_result["new_id"]
            all_yt_id.append(new_id)
            completion_result = await yt_completed_status_db(
                id=new_id,
                session=session,
                background_tasks=background_tasks
            )

            if completion_result != 1:
                log_async(
                    background_tasks,
                    f"[SERVICE][YOUTUBE_SEARCH] Unable to update completion status for YouTube video ID: {new_id}",
                    "error"
                )
            

            # video_dict[str(new_id)] = {
            #     "video_id": new_id,
            #     "video_title": video_title,
            #     "video_url": video_url,
            #     "video_date": video_date,
            #     "video_thumbnail": video_thumbnail
            # }
            # all_data[video_url] = video_dict

        data = [ShortlistVideos(yt_videos_id=yt_id) for yt_id in all_yt_id]

        
        shortlisted_video_result = await shortlist_videos_service(
                job_id=job_id,
                data=data, 
                user_id=user_id,
                background_tasks=background_tasks,
                session=session,
            )

        return shortlisted_video_result



        # return all_data

    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][YOUTUBE_SEARCH] Unexpected error: {str(e)}",
            "error"
        )
        return HTTPException(
            detail=f"[SERVICE][YOUTUBE_SEARCH] Unexpected error: {str(e)}",
            status_code=500
        )




async def is_youtube_link_valid(video_url):
    try:
        video_id = extract_video_id(video_url)
        if not video_id:
            return None

        api_url = (
            f"https://www.googleapis.com/youtube/v3/videos"
            f"?part=snippet,contentDetails,statistics"
            f"&id={video_id}&key={YOUTUBE_API_KEY}"
        )

        async with httpx.AsyncClient() as client:
            response = await client.get(api_url)
            response.raise_for_status()
            data = response.json()

        if not data["items"]:
            return None

        return data

    except Exception as e:
        print("Error:", e)
        return None
    
from urllib.parse import urlparse, parse_qs

# def extract_video_id(url):
#     parsed_url = urlparse(url)
#     if parsed_url.hostname == "youtu.be":
#         return parsed_url.path[1:]
#     elif "youtube.com" in parsed_url.hostname:
#         return parse_qs(parsed_url.query).get("v", [None])[0]
#     return None

# from urllib.parse import urlparse, parse_qs  

def extract_video_id(url):
    try:
        parsed_url = urlparse(url)
        hostname = parsed_url.hostname

        if hostname == "youtu.be":
            return parsed_url.path.lstrip("/")

        elif "youtube.com" in hostname:
            if parsed_url.path == "/watch":
                return parse_qs(parsed_url.query).get("v", [None])[0]

            if parsed_url.path.startswith("/shorts/"):
                return parsed_url.path.split("/")[2]

            if parsed_url.path.startswith("/embed/"):
                return parsed_url.path.split("/")[2]

        return None

    except Exception as e:
        print("Error parsing URL:", e)
        return None


# Example usage
# video_url = "https://www.youtube.com/watch?v=NhsmHC83z6g"
# info = get_youtube_video_info(video_url)

# if info:
#     print("✅ Valid YouTube video")
#     for k, v in info.items():
#         print(f"{k}: {v}")
# else:
#     print("❌ Invalid or unavailable video")

   


# async def s3_download_link(url):
#     pass
#     try:
#         async with httpx.AsyncClient() as client:
#             response = await client.post(
#                 "https://your-aws-api-url/api/download",
#                 json={"url": url},
#                 timeout=30.0
#             )
                


### logic for search one by one iterate over through list.

# from sqlalchemy.ext
# .asyncio import AsyncSession
# from fastapi.responses import JSONResponse
# from fastapi import Depends
# from app.core.db.services.db_session import get_async_session
# from app.core.db.services.db_user_service import async_create_user, update_user, delete_user

# # from app.core.db.services.db_service import object_to_dict

# from googleapiclient.discovery import build
# from googleapiclient.errors import HttpError

# # from youtube_module import Youtube
# from app.utils.logging_utils import log
# from typing import List

# # from app.config import YOUTUBE_API_KEY # Assuming you have this file and key
# YOUTUBE_API_KEY = "AIzaSyAZPutKSww2eH4-wzjYrTkwLIEAa5XgBFs"

# # Initialize the YouTube API client
# # This 'youtube' variable is the 'Resource' object returned by build()
# youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)


# async def search_youtube_videos(company_name):
#     """
#     Searches YouTube for videos related to the given company name.
#     Returns the first matching video's details or None if no video is found.
#     """
#     try:
#         # CORRECT CALL: Youtube().list()
#         # 'youtube' is the service object.
#         # '.search()' gets the search collection.
#         # '.list()' is the method on the search collection.
#         result = []
#         for name in company_name:
#             search_response = (
#                 youtube.search() # Correct: Call the search() collection method
#                 .list(
#                     q=name,
#                     part="id,snippet",
#                     maxResults=10,
#                     type="video",
#                     order="date", # Most recent
#                     videoDuration="short", # Short videos (<4 minutes)
#                     relevanceLanguage="en", # English language
#                 )
#                 .execute()
#             )
#             log.debug("YouTube API Raw Response: %s", search_response)

#             videos = search_response.get("items", [])
#             if not videos:
#                 log.info(f"No videos found for company: '{name}'")
#                 return None # No videos found

#             video = videos[0]
#             video_id = video["id"]["videoId"]

#             # IMPORTANT: Use the standard YouTube embed/watch URL format.
#             # The URL 'https://www.youtube.com/watch?v={video_id}' is incorrect.
#             # For a standard YouTube video, it should be:
#             video_url = f"https://www.youtube.com/watch?v={video_id}"
#             # Or for embedding: f"https://www.youtube.com/embed/{video_id}"

#             video_title = video["snippet"]["title"]
#             video_date = video["snippet"]["publishedAt"]
#             video_thumbnail = video["snippet"]["thumbnails"]["default"]["url"]

#             log.info(f"Found video for '{name}': Title='{video_title}', URL='{video_url}'")
#             log.debug(f"Video Details: {{'video_url': '{video_url}', 'video_title': '{video_title}', 'company_name': '{company_name}', 'video_date': '{video_date}', 'video_thumbnail': '{video_thumbnail}'}}")

#             result.append({
#                 "video_url": video_url,
#                 "video_title": video_title,
#                 "company_name": name,
#                 "video_date": video_date,
#                 "video_thumbnail": video_thumbnail,
#             })

#         return result

#     except HttpError as e:
#         # Log the full exception traceback for debugging
#         log.exception(f"YouTube API error during search for '{name}': HTTP Status: {e.resp.status}, Content: {e.content.decode()}")
#         # Re-raise the exception so the FastAPI router can catch it and return an HTTPException
#         raise
#     except Exception as e:
#         # Log unexpected exceptions with traceback
#         log.exception(f"An unexpected error occurred during Youtube for '{name}': {e}")
#         # Re-raise the exception
#         raise


