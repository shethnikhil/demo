from pydantic import BaseModel
from fastapi import Form
from typing import Optional

class CreateCompanyDetails(BaseModel):
    company_symbol: str
    isin_no: str
    company_name: str

class UpdateCompanyDetails(BaseModel):
    company_symbol : str
    company_name : str

class DeleteCompany(BaseModel):
    isin_no : str
    deleted_by: int

class CompanyCreateResponse(BaseModel):
    message: str
    company_id: Optional[str] = None
