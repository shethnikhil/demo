from fastapi import FastAPI, Depends, BackgroundTasks, status
from fastapi.security import OAuth2PasswordRequestForm
from typing import Annotated
from fastapi import HTTPException, APIRouter, Response
from fastapi.responses import JSONResponse
from datetime import timedelta
import sys

from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db.db_session import get_async_session
from app.microservices.company.company_service import (
    create_company_service,
    get_companies_service,
    soft_delete_compnay_logic,
    check_company,
    get_companies_details_service,
    update_company_service,
)
from app.microservices.company.company_schema import CompanyCreateResponse, CreateCompanyDetails, UpdateCompanyDetails, DeleteCompany
from app.core.db.models.user_base import Users

from app.utils.logging_utils import log, log_async
from app.common_functions import get_current_user


# import logging
# log = logging
# log.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# log.info("info")
# log.error("error")

app = FastAPI()
router_v1 = APIRouter(prefix="/yt-api/v1/companies")


from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For testing only; replace with your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (critical for domain access!)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["reg.nseindia.com", "ec2-3-111-213-245.ap-south-1.compute.amazonaws.com", "*"]  # Replace with your actual domain
)


@app.get("/health")
async def health():
    return JSONResponse(content="ok",status_code=200)

@router_v1.post("/companies")
async def create_company_handler(
    data: CreateCompanyDetails, 
    background_tasks:BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id= user.user_id
        check = await check_company(
            company_isin_no = data.isin_no,
            session=session, 
            company_symbol=data.company_symbol,
            background_tasks=background_tasks,
            )
        if check:
            # return JSONResponse(content="Company already created", status_code=201)
            # raise ValueError("Company already created")
            raise HTTPException(status_code=409, detail="Company already exists")
        
        result = await create_company_service(
            user_id=user_id,
            session=session, 
            data=data,
            background_tasks=background_tasks,
            ) 
        if result["status"] == "success":
            log_async(background_tasks, "[ROUTE][CREATE_COMPANY_HANDLER] Company successfully created", "info")
            # return JSONResponse(content="Company created successfully", status_code=201)
            return {
                "message": "Company created successfully",
                "company_name": result["company_name"]
            }
        
        if result["status"] == "error":
            # return JSONResponse(content="Company creation failed", status_code=404)
            raise HTTPException(status_code=400, detail="Company creation failed")
        
        else:
            raise HTTPException(status_code=400, detail="Company creation failed")

    except Exception as e:
        log_async(
        background_tasks,
        f"[ROUTE][CREATE_COMPANY] Unexpected error: {str(e)}",
        "error"
        )
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

    
@router_v1.get("/companies")
async def get_all_companies_handler(
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id = user.user_id
        result = await get_companies_service(
            background_tasks=background_tasks,
            user_id=user_id,
            session=session,
            )
        if result["status"] == "success":
            return JSONResponse(content=result["data"], status_code=200)
        if result["status"] == "error":
            raise HTTPException(status_code=404, detail="Something went wrong while fetching companies")
        else:
            raise HTTPException(status_code=400, detail="Unexpected response from service")
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[Routes][GET_COMPANIES] Unexpected error: {str(e)}",
            "error"
        )
        # return JSONResponse(content=f"fetch Company details failed: {e}", status_code=404)
        raise HTTPException(status_code=500, detail="Failed to fetch companies")    

# ===========================

    
@router_v1.get("/companies/{company_symbol}")
async def get_all_companies_handler(
    company_symbol:str,
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id = user.user_id
        result = await get_companies_details_service(
            company_symbol=company_symbol,
            background_tasks=background_tasks,
            user_id=user_id,
            session=session,
            )
        if result["status"] == "success":
            return JSONResponse(content=result["data"], status_code=200)
        if result["status"] == "error":
            log_async(
                background_tasks,
                f"[Routes][GET_COMPANIES] Error in service: {result.get('error_detail', 'Unknown error')}",
                "error"
            )
            raise HTTPException(status_code=404, detail="Something went wrong while fetching companies")
        else:
            raise HTTPException(status_code=400, detail="Unexpected response from service")
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[Routes][GET_COMPANIES] Unexpected error: {str(e)}",
            "error"
        )
        # return JSONResponse(content=f"fetch Company details failed: {e}", status_code=404)
        raise HTTPException(status_code=500, detail="Failed to fetch companies")    





# ===============================





@router_v1.patch("/companies")
async def update_company_handler(
    data: UpdateCompanyDetails,
    background_tasks : BackgroundTasks,
    user: Users = Depends(get_current_user), 
    session :AsyncSession = Depends(get_async_session)
    ):
    """
    Updates details of a company by its symbol.
    """
    try:
        company_symbol = data.company_symbol
        user_id = user.user_id
        result = await update_company_service(
            company_symbol=company_symbol,
            user_id= user_id,
            data=data, 
            background_tasks=background_tasks,
            session=session,
            )
        
        if result:
            log_async(
                background_tasks,
                f"[API][UPDATE_COMPANY] Company '{company_symbol}' successfully updated.",
                "info"
            )
            return {"message": f"Company '{company_symbol}' updated successfully."}
        
        elif not result:
            log_async(
                background_tasks,
                f"[API][UPDATE_COMPANY] Company '{company_symbol}' not found for update.",
                "warning",
                always_sync=True
            )
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Company with symbol '{company_symbol}' not found."
            )
        else:
            log_async(
                background_tasks,
                f"[API][UPDATE_COMPANY] Company '{company_symbol}' update request resulted in no changes.",
                "info"
            )
            return {"message": f"Company '{company_symbol}' exists, but no changes were applied."}
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[API][UPDATE_COMPANY] Unexpected error during update for company '{company_symbol}': {str(e)}",
            "error",
            always_sync=True 
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected internal server error occurred."
        )
    

@router_v1.put("/delete_company", status_code=200)
async def soft_delete_compnay(data: DeleteCompany, session: AsyncSession = Depends(get_async_session)):
    try:
        result = await soft_delete_compnay_logic(data=data, session=session)
        if result["status"] == "success":
            return JSONResponse(content=f"isin_no: {data.isin_no} company is deleted successfully by user {data.deleted_by}", status_code=200)
        else:
            return JSONResponse(content=f"unable to dele isin_no: {data.isin_no} company",status_code=404)

    except Exception as e:
        return JSONResponse(content=f"failed in soft delete Company: {e}", status_code=404)
    
app.include_router(router_v1)

import uvicorn
if __name__ == "__main__":
    uvicorn.run("app.microservices.company.company_routes:app", host="0.0.0.0", port=50004, reload=True)
