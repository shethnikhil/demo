'''
User related function logic
'''

from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import JSONResponse
from fastapi import Depends, BackgroundTasks
from app.core.db.db_session import get_async_session
from app.core.db.services.company_repository import (
    company_name,
    create_company_db,
    get_all_companies_db,
    get_companies_detail_db,
    update_company_db,
    soft_delete_company_db,
    check_company_db,
    
)    
from app.core.db.services.user_repository import object_to_dict
from app.utils.logging_utils import log_async

# from app.core.db.services.db_service import object_to_dict
# from app.core.db.services.db_company_service import get_all_users 


# validations
async def check_company(
        company_symbol,
        company_isin_no,
        session: AsyncSession,
        background_tasks:BackgroundTasks,

):
    try:
        result = await check_company_db(
            company_symbol = company_symbol, 
            company_isin_no = company_isin_no,
            session=session,
            background_tasks = background_tasks,
            )
        if result:
                return True
        else:
            return False  
             
    except Exception as e:
        # raise ValueError("Company already created")
        return JSONResponse(content=f"get Company symbol by company Symbol failed: {e}", status_code=404)

# get company symbol by company name
async def get_company_name(company_symbol:str ,session: AsyncSession = Depends(get_async_session)):
    try:
        result = await company_name(company_symbol=company_symbol, session=session)
        if result:
                company_name_result = [object_to_dict(result_data) for result_data in result]
                return {"status":"success" , "data":company_name_result}
        if result is None:
            return{"status":"error","data":0}
        else:
            return JSONResponse(content="Extra validations",status_code=404)        
    except Exception as e:
        return JSONResponse(content=f"get Company Name by company Symbol failed: {e}", status_code=404)
    
async def update_company_logic(data, session : AsyncSession = Depends(get_async_session)):
    try:
        result = await update_company_db(name=data.name, isin_no=data.isin_no, updated_by=data.updated_by, session=session)
        return {"status":result}
    
    except Exception as e:
        return JSONResponse(content=f"update Company data failed: {e}", status_code=404)

async def create_company_service(
        data, 
        user_id,
        session: AsyncSession,
        background_tasks:BackgroundTasks,
        ):
    try:
        result = await create_company_db(
            session=session, 
            company_isin_no=data.isin_no, 
            company_symbol=data.company_symbol,
            company_name=data.company_name, 
            user_id=user_id,
            background_tasks=background_tasks,
            )
        
        if result:
            # result = [object_to_dict(create_user_obj) for create_user_obj in result]
            return {"status":"success", "company_name":result["company_name"]}
        else:
            return {"status":"error", "company_name":None}
        
    except Exception as e:
        log_async(
        background_tasks,
        f"[SERVICE][CREATE_COMPANY_SERVICE] Unexpected error: {str(e)}",
        "error"
        )
        raise ValueError("Company creation failed")


async def get_companies_service(
        user_id:int,
        background_tasks: BackgroundTasks,
        session : AsyncSession,
        ):
    try:
        result = await get_all_companies_db(
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
            )
        if result:
            company_result = [object_to_dict(result_data) for result_data in result]
            return {"status":"success" , "data":company_result}
        # if result == False:
        if len(result)==0:
            return {"status":"success" , "data":None}
        if not result:
            return{"status":"error","data":0}
        else:
            raise ValueError("Extra validations needed")
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][GET_COMPANIES] Unexpected error: {str(e)}",
            "error"
        )
        # return JSONResponse(content=f"get Company data failed: {e}", status_code=404)
        raise e





async def get_companies_details_service(
        company_symbol:str,
        user_id:int,
        background_tasks: BackgroundTasks,
        session : AsyncSession,
        ):
    try:
        result = await get_companies_detail_db(
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
            )
        if result:
            company_result = [object_to_dict(result_data) for result_data in result]
            return {"status":"success" , "data":company_result}
        # if result == False:
        if not result:
            return{"status":"error","data":0}
        else:
            raise ValueError("Extra validations needed")
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][GET_COMPANIES] Unexpected error: {str(e)}",
            "error"
        )
        # return JSONResponse(content=f"get Company data failed: {e}", status_code=404)
        raise e


async def update_company_service(
        data,
        company_symbol: str,
        user_id: int, 
        background_tasks: BackgroundTasks,
        session : AsyncSession,
        ):
    """
    Handles the business logic for updating company details.

    Returns:
        str: "success" if updated, "not_found" if company not found, "error" for other issues.
    """
    try:
        result = await update_company_db(
            user_id=user_id,
            company_symbol = company_symbol,
            company_name = data.company_name,
            background_tasks = background_tasks,
            session=session,
            )
        if result:
            return True
        else:
            return False
            
    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][UPDATE_COMPANY] Error in update_company_service for '{company_symbol}': {str(e)}",
            "error",
            always_sync=True 
        )
        raise Exception(f"Service error during company update: {e}")
    
async def soft_delete_compnay_logic(data, session:AsyncSession = Depends(get_async_session)):
    try:
        result = await soft_delete_company_db(isin_no=data.isin_no, deleted_by=data.deleted_by, session=session)
        if result == 1:
            return{"status":"success","data":result}
        else:
            return{"status":"error","data":0}
        
    except Exception as e:
        return JSONResponse(content=f"soft-company-deletion failed: {e}", status_code=404)
    

