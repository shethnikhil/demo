'''
Data validation.
'''

from pydantic import BaseModel
from typing import Optional

class CreateJob(BaseModel):
    job_name : str 
    job_desc : Optional[str] = None
    company_symbol : list
    search_start_date : Optional[str] = None
    search_end_date : Optional[str] = None
    links : Optional[list] = None

class ArchivedJob(BaseModel):
    archived_by : int

class VideoLinkCreateJob(BaseModel):
    job_name : str 
    job_desc : Optional[str] = None
    links = list[str] 
    company_symbol : list = ["Generic"]
    search_start_date : Optional[str] = None
    search_end_date : Optional[str] = None
    links : Optional[list] = None