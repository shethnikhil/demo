'''
In this file, folder all action related endpoint should take place
like Job, Keywords, Sectors CRUD operations,  
'''

from typing import Optional
from fastapi import FastAPI, Depends
from fastapi.security import OAuth2PasswordRequestForm
from fastapi import HTTPException, APIRouter, Response, Query
from fastapi.responses import JSONResponse


from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db.db_session import get_async_session
from app.microservices.job.job_service import (
    archive_job_by_id,
    process_create_job,
    fetch_all_jobs,
    fetch_job_by_id,
    get_job_by_id,
    fetch_all_archived_jobs,
    process_create_links_job,
)
from app.microservices.job.job_schema import CreateJob, ArchivedJob, VideoLinkCreateJob

from app.utils.logging_utils import log, log_async
from fastapi import BackgroundTasks
from app.core.db.models.user_base import Users
from app.common_functions import get_current_user

app = FastAPI()
router_v1 = APIRouter(prefix="/yt-api/v1/jobs")


from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For testing only; replace with your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (critical for domain access!)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["reg.nseindia.com", "ec2-3-111-213-245.ap-south-1.compute.amazonaws.com", "*"]  # Replace with your actual domain
)


@app.get("/health")
async def health():
    return JSONResponse(content="ok",status_code=200)

@router_v1.post("/jobs")
async def create_job(
    data: CreateJob, 
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user)
):
    try:
        result = await process_create_job(
            session=session, 
            data=data,
            user=user,
            background_tasks=background_tasks)
        
        if result["status"] == "success":
            log_async(
                background_tasks,
                f"[JOB_CREATE] Info: Job Name:'{data.job_name}' created successfully by {user.user_id}.",
                "info"
            )

            return JSONResponse(
                content={
                    "status": 1,
                    "message": result.get("message", f"Job Name:'{data.job_name}' created successfully."),
                    "job_id":result["details"]
                },
                status_code=201 
            )
        if result["status"] == "error":
            log_async(
                background_tasks,
                f"[JOB] Error: Failed to create job '{data.job_name}' due to validation error.",
                "error"
            )
            return JSONResponse(
                content={
                    "status": 0, 
                    "message": result.get("message", f"Job Name:'{data.job_name}' creation failed due to validation.")
                },
                status_code=400 
            )
        else:
            log_async(
                background_tasks,
                "[JOB][CREATE] Unexpected error occurred during job creation. Possible unhandled logic or service failure.",
                "error"
            )
            return JSONResponse(
                content={
                    "status": 0,
                    "message": "An unexpected error occurred during job creation."
                },
                status_code=500 
            )

    except Exception as e:
        log_async(
            background_tasks,
            f"[JOB][CREATE] Internal server error while creating job '{data.job_name}'.",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail=f"An internal server error occurred: {str(e)}"
)
    






@router_v1.post("/jobs/links")
async def video_link_job_handler(
    data: VideoLinkCreateJob, 
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
):
    try:
        # user_id = user.user_id
        result = await process_create_links_job(
            session=session, 
            data=data,
            user=user,
            background_tasks=background_tasks)
        
        if result["status"] == "success":
            log_async(
                background_tasks,
                f"[JOB_CREATE] Info: Job Name:'{data.job_name}' created successfully by {user.user_id}.",
                "info"
            )

            return JSONResponse(
                content={
                    "status": 1,
                    "message": result.get("message", f"Job Name:'{data.job_name}' created successfully."),
                    "job_id":result["details"]
                },
                status_code=201 
            )
        if result["status"] == "error":
            log_async(
                background_tasks,
                f"[JOB] Error: Failed to create job '{data.job_name}' due to validation error.",
                "error"
            )
            return JSONResponse(
                content={
                    "status": 0, 
                    "message": result.get("message", f"Job Name:'{data.job_name}' creation failed due to validation.")
                },
                status_code=400 
            )
        else:
            log_async(
                background_tasks,
                "[JOB][CREATE] Unexpected error occurred during job creation. Possible unhandled logic or service failure.",
                "error"
            )
            return JSONResponse(
                content={
                    "status": 0,
                    "message": "An unexpected error occurred during job creation."
                },
                status_code=500 
            )

    except Exception as e:
        log_async(
            background_tasks,
            f"[JOB][CREATE] Internal server error while creating job '{data.job_name}'.",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail=f"An internal server error occurred: {str(e)}"
)



    
# @router_v1.get("/jobs")
# async def get_all_jobs(
#     background_tasks= BackgroundTasks,
#     session: AsyncSession = Depends(get_async_session),
#     user: Users = Depends(get_current_user),
#     status: Optional[str]= Query(None),
#     ):
#     try:
#         user_id = user.user_id
#         if status == "archived":
#             result = await fetch_all_archived_jobs()
#         result = await fetch_all_jobs(user_id=user_id, session=session, background_tasks=background_tasks)
#         if result["status"] == "success":
#             return JSONResponse(content=result["data"], status_code=200)
#         if result["status"] == "error":
#             return JSONResponse(content=" something wrong in fetch all job", status_code=404)
#         else:
#             return JSONResponse(content="Need to add extra validations", status_code=404)
        
#     except Exception as e:
#         log_async(
#             background_tasks,
#             "[FETCH_ALL_JOBS] Failed to process job data",
#             "error"
#         )
#         return JSONResponse(content=f"fetch all Job details failed: {e}", status_code=404)

@router_v1.get("/jobs")
async def get_all_jobs(
    background_tasks= BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
    status: Optional[str]= Query(None),
    ):
    try:
        user_id = user.user_id
        if status == "archived":
            result = await fetch_all_archived_jobs()
        result = await fetch_all_jobs(user_id=user_id, session=session, background_tasks=background_tasks)
        if result["status"] == "success":
            return JSONResponse(content=result["data"], status_code=200)
        if result["status"] == "error":
            return JSONResponse(content=" something wrong in fetch all job", status_code=404)
        else:
            return JSONResponse(content="Need to add extra validations", status_code=404)
        
    except Exception as e:
        log_async(
            background_tasks,
            "[FETCH_ALL_JOBS] Failed to process job data",
            "error"
        )
        return JSONResponse(content=f"fetch all Job details failed: {e}", status_code=404)
    
@router_v1.get("/jobs/{job_id}")
async def get_job_by_id(
    job_id: int, 
    background_tasks: BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try: 

        result = await fetch_job_by_id(
            job_id=job_id, 
            user_id=user.user_id, 
            session=session, 
            background_tasks=background_tasks
            )
        if result["status"] == "success":
            return JSONResponse(content=result["data"], status_code=200)
        if result["status"] == "Not Found":
            return JSONResponse(content=result["data"], status_code=200)
        if result["status"] == "error":
            log_async(
            background_tasks,
            f"""[LOGIC][SEARCH_JOB_BY_ID] Unexpected error: {result["data"]}""",
            "error"
            )
            return {"status": "error", "message": {result["data"]}}
        else:
            log_async(
            background_tasks,
            f"""[API][GET_JOB_BY_ID] Unexpected error: {result['data']}""",
            "error"
            )
            return {"status": "Extra validation error", "message":{result["message"]}}
        
    except Exception as e:
        log_async(
        background_tasks,
        f"[API][GET_JOB_BY_ID] Failed to fetch job_id={job_id}: {str(e)}",
        "error"
    )

        return JSONResponse(content=f"Fetch job details of job id: {job_id} is failed: {e}",status_code=404)
    

@router_v1.put("/jobs/{job_id}/archive")
async def archive_job(
    job_id:int, 
    background_tasks=BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id = user.user_id
        id_result = await get_job_by_id(
            job_id=job_id, 
            user_id=user_id, 
            background_tasks=background_tasks,
            session=session,
            )
        if not id_result:
            return JSONResponse(content=f"Job not found", status_code=404)
        if id_result.is_archived:
            return JSONResponse(content=f"Job already archived", status_code=400)


        result = await archive_job_by_id(
            job_id=job_id, 
            session=session,
            user_id=user_id,
            background_tasks=background_tasks,
            )
        if result["status"] == "success":
            return JSONResponse(content=f"job_id: {job_id} Job is archived successfully by user {user_id}", status_code=200)
        else:
            return JSONResponse(content=f"unable to archived job: {job_id} Job",status_code=404)

    except Exception as e:
        # log.error(f"Failed in archive Job Id- {job_id}")
        log_async(
            background_tasks,
            f"[API][ARCHIVE_JOB] Failed to archive job_id={job_id}: {str(e)}",
            "error"
        )

        return JSONResponse(content=f"Failed in archive Job Id- {job_id}: {e}", status_code=404)
    
app.include_router(router_v1)

import uvicorn
if __name__ == "__main__":
    uvicorn.run("app.microservices.job.job_routes:app", host="0.0.0.0", port=50012, reload=True)
