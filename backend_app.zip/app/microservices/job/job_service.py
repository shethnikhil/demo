
'''
Function logic.
'''
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import JSONResponse
from fastapi import Depends, BackgroundTasks, HTTPException, status
from app.core.db.models.user_base import Company
from app.core.db.services.company_repository import get_companies_detail_db
from app.core.db.db_session import get_async_session
from app.core.db.services.job_repository import (
    insert_job_to_db,
    insert_link_job_to_db,
    select_all_jobs,  
    select_job_by_id,  
    mark_job_as_archived,
    search_job,
    company_symbol,
    select_all_archived_jobs,
    )
from app.core.db.services.user_repository import object_to_dict
from app.utils.logging_utils import log, log_async

from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError


#Validation job with id is present or not.
async def get_job_by_id(
        job_id:int,
        user_id:int,
        background_tasks:BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        result = await search_job(
            job_id=job_id,
            user_id=user_id,
            session=session,
            background_tasks=background_tasks,
            )
        if result:
            return result
        else:
            return None
        
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][get_job_by_id] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail="Database error while Failed to fetch job"
        )
    
    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[DB][get_job_by_id] Validation error: {str(val_err)}",
            "error"
        )
        raise HTTPException(
            status_code=400,
            detail="Data validation error while Failed to fetch job"
        )

    except Exception as e:
        log_async(
            background_tasks,
            f"[DB][get_job_by_id] Unexpected error during Failed to fetch job: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail="Error in youtube searched update completion status: {e}"
        )


    
# async def is_job_archived(
#         job_id: int,
#         user_id: int,
#         session: AsyncSession= Depends(get_async_session),
#         ):
#     try:
#         result = await search_archived_job(job_id=job_id, session=session)
#         if result == True:
#             return True
#         else:
#             return False
#     except Exception as e:
#         log.error("Error in search archived job logic")
#         return JSONResponse(content=f"Error in search archived job: {e}", status_code=404)

# fetch company symbols by job_id
async def fetch_company_symbol(job_id: int, session: AsyncSession= Depends(get_async_session)):
    try:
        result = await company_symbol(job_id=job_id, session=session)
        if result:
            return result
        if result == False:
            return False
            # return{"status":"error","data":[]}
        else:
            return JSONResponse(content="Extra validations",status_code=404)
        
    except Exception as e:
        log.error("Error in fetch company symbol logic")
        return JSONResponse(content=f"Error in fetch company symbol logic: {e}", status_code=404)


# CRUD Operations
async def process_create_job(
        data, 
        user, 
        background_tasks: BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        result = await insert_job_to_db(
            session=session, 
            job_name=data.job_name, 
            job_desc=data.job_desc,
            company_symbol=data.company_symbol,
            search_start_date=data.search_start_date,
            search_end_date=data.search_end_date,
            user_id=user.user_id,
            background_tasks=background_tasks
            )
        
        if result["status"] == "success":
            return {"status":"success", "details":result["job_id"]}
        else:
            return {"status":"error", "details":result["job_id"]}
    except Exception as e:
        # log.error("Error in job creation logic")
        log_async(
            background_tasks,
            f"[SERVICE][JOB_CREATE] Error while processing job creation for user {user.user_id}.",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error in job creation logic: {str(e)}"
        )

from sqlalchemy import select

async def fetch_all_jobs(
        user_id,
        background_tasks: BackgroundTasks,
        session : AsyncSession = Depends(get_async_session),
):
    try:
        result = await select_all_jobs(user_id=user_id, session=session, background_tasks=background_tasks)
        
        if result is False:
            return {"status": "error", "data": 0}
        
        jobs = result

        # if not jobs:
        #     return JSONResponse(content={"status": "success", "data": []}, status_code=status.HTTP_200_OK)
        
        if not jobs:
            return {"status": "success", "data": []}

        # Step 1: Prepare a set of all unique company symbols needed across all jobs
        all_unique_symbols = set()
        for job_obj in jobs:
            if job_obj.company_symbol: # company_symbol is a JSON list
                for symbol in job_obj.company_symbol:
                    all_unique_symbols.add(symbol)
        
        # Step 2: Fetch all required company details in one go
        company_details_map = {}
        if all_unique_symbols:
            company_results = await session.execute(
                select(Company.company_symbol, Company.company_name)    # TODO add this in db and also in that function there is other db also that need to add in db file
                .where(Company.company_symbol.in_(list(all_unique_symbols)))
            )
            for symbol, name in company_results:
                company_details_map[symbol] = name

        # Step 3: Iterate through each job, convert to dict, and enrich with company names
        enriched_jobs_list = []
        for job_obj in jobs:
            job_dict = object_to_dict(job_obj)
            
            # This is the key change: create a list of *just* the names
            job_company_names = []
            if job_dict.get("company_symbol"): # Check if company_symbol list exists for this job
                for symbol in job_dict["company_symbol"]:
                    # Get the actual company name. If not found, use the symbol as a fallback.
                    company_name_from_db = company_details_map.get(symbol, symbol) # Using symbol as fallback if not found
                    job_company_names.append(company_name_from_db)
            
            # Assign to the new key 'company_name'
            job_dict["company_name"] = job_company_names 
            
            # Optionally, you might want to remove the 'company_details' if it's there from previous attempts
            # if "company_details" in job_dict:
            #     del job_dict["company_details"]

            enriched_jobs_list.append(job_dict)

        return {"status": "success", "data": enriched_jobs_list}

    except Exception as e:
        log_async(
            background_tasks,
            f"[FETCH_ALL_JOBS] Exception occurred: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred: {str(e)}"
        )
    
async def fetch_all_archived_jobs(
        user_id,
        background_tasks: BackgroundTasks,
        session : AsyncSession = Depends(get_async_session),
):
    try:
        result = await select_all_archived_jobs(user_id=user_id, session=session, background_tasks=background_tasks)
        if result:
            job_result = [object_to_dict(result_data) for result_data in result]
            return {"status":"success" , "data":job_result}
            
        if result is False:
            return{"status":"error","data":0}
        else:
            return JSONResponse(content="Extra validations",status_code=404)
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[FETCH_ALL_JOBS] Exception occurred",
            "error"
        )
        return {"status": "error", "message": f"Exception: {str(e)}"}

async def fetch_job_by_id(
        job_id:int,
        user_id:int, 
        background_tasks: BackgroundTasks,
        session: AsyncSession= Depends(get_async_session),
        ):
    try:
        result = await select_job_by_id(
            job_id=job_id, 
            user_id=user_id, 
            session=session,
            background_tasks=background_tasks,
            )
        # if result:
        #     job_result = [object_to_dict(result_data) for result_data in result]
            # return {"status":"success" , "data":job_result}
        jobs = result

        all_unique_symbols = set()
        for job_obj in jobs:
            if job_obj.company_symbol: # company_symbol is a JSON list
                for symbol in job_obj.company_symbol:
                    all_unique_symbols.add(symbol)
        
        # Step 2: Fetch all required company details in one go
        company_details_map = {}
        if all_unique_symbols:
            company_results = await session.execute(
                select(Company.company_symbol, Company.company_name)    # TODO add this in db and also in that function there is other db also that need to add in db file
                .where(Company.company_symbol.in_(list(all_unique_symbols)))
            )
            for symbol, name in company_results:
                company_details_map[symbol] = name

        # Step 3: Iterate through each job, convert to dict, and enrich with company names
        enriched_jobs_list = []
        for job_obj in jobs:
            job_dict = object_to_dict(job_obj)
            
            # This is the key change: create a list of *just* the names
            job_company_names = []
            if job_dict.get("company_symbol"): # Check if company_symbol list exists for this job
                for symbol in job_dict["company_symbol"]:
                    # Get the actual company name. If not found, use the symbol as a fallback.
                    company_name_from_db = company_details_map.get(symbol, symbol) # Using symbol as fallback if not found
                    job_company_names.append(company_name_from_db)
            
            # Assign to the new key 'company_name'
            job_dict["company_name"] = job_company_names 
            
            # Optionally, you might want to remove the 'company_details' if it's there from previous attempts
            # if "company_details" in job_dict:
            #     del job_dict["company_details"]

            enriched_jobs_list.append(job_dict)

        return {"status": "success", "data": enriched_jobs_list}


        if result == False:
            return{"status":"error","data":0}
        if not result:
            return{"status":"Not Found","data":"Job Not Found"}
        else:
            return {"status": "Extra validation error", "data": "Extra validation required"}
   
    except Exception as e:
        log_async(
            background_tasks,
            f"[LOGIC][FETCH_JOB_BY_ID] Failed to fetch job_id={job_id}: {str(e)}",
            "error"
        )

        return {"status": "error", "message": str(e)}
    

async def archive_job_by_id(
        job_id, 
        user_id,
        background_tasks: BackgroundTasks,
        session:AsyncSession = Depends(get_async_session)):
    try:
        result = await mark_job_as_archived(
            session=session, 
            job_id=job_id,
            user_id=user_id,
            background_tasks=background_tasks,
            )
        if result:
            return{"status":"success","data":result}
        else:
            return{"status":"error","data":0}
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[LOGIC][ARCHIVE_JOB_BY_ID] Failed to archive job_id={job_id}: {str(e)}",
            "error"
        )
        return {"status": "error", "message": str(e)}


async def process_create_links_job(
        data, 
        user, 
        background_tasks: BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        result = await insert_link_job_to_db(
            session=session, 
            job_name=data.job_name, 
            job_desc=data.job_desc,
            company_symbol=data.company_symbol,
            search_start_date=data.search_start_date,
            search_end_date=data.search_end_date,
            user_id=user.user_id,
            links=data.links,
            background_tasks=background_tasks,
            )
        
        if result["status"] == "success":
            return {"status":"success", "details":result["job_id"]}
        else:
            return {"status":"error", "details":result["job_id"]}
    except Exception as e:
        # log.error("Error in job creation logic")
        log_async(
            background_tasks,
            f"[SERVICE][JOB_LINKS_CREATE] Error while processing job creation for user {user.user_id}.",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error in job(Links) creation logic: {str(e)}"
        )