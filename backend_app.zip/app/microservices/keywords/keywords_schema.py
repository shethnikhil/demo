from pydantic import BaseModel
from typing import Optional

class CreateKeywords(BaseModel):
    keyword_name : str
    company_symbol : str

class UpdateKeywords(BaseModel):
    keyword_name: str
    keyword_id : int
    updated_by : int

class DeleteKeywords(BaseModel):
    keyword_id: int
    deleted_by: int