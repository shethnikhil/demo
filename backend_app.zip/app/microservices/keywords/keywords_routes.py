from fastapi import BackgroundTasks, FastAPI, Depends
from fastapi.security import OAuth2PasswordRequestForm
from typing import Annotated
from fastapi import HTTPException, APIRouter, Response
from fastapi.responses import JSONResponse
from datetime import timedelta
import sys
from app.common_functions import get_current_user
from app.core.db.models.user_base import Users
from app.microservices.keywords.keywords_service import (
    create_keywords_service,
    get_all_keywords_service,
    update_keywords_logic,
    soft_delete_keyword_logic,
)
from app.microservices.keywords.keywords_schema import CreateKeywords, UpdateKeywords, DeleteKeywords

from app.utils.logging_utils import log, log_async

app = FastAPI()
router_v1 = APIRouter(prefix="/yt-api/v1/keywords")

from fastapi.middleware.cors import CORSMiddleware

from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For testing only; replace with your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (critical for domain access!)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["reg.nseindia.com", "ec2-3-111-213-245.ap-south-1.compute.amazonaws.com", "*"]  # Replace with your actual domain
)


@app.get("/health")
async def health():
    return JSONResponse(content="ok",status_code=200)

from sqlalchemy.ext.asyncio import AsyncSession 
from app.core.db.db_session import get_async_session


@router_v1.post("/keywords", status_code=201)
async def create_keyword_handler(
    data: CreateKeywords, 
    background_tasks : BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user)
    ):
    try:
        user_id = user.user_id
        result = await create_keywords_service(
            data=data,
            user_id=user_id,
            session=session,
            background_tasks=background_tasks,
            ) 
        if result["status"] == "success":
            return {"message": "keyword created successfully"}
        if result["status"] == "error":
            return JSONResponse(content="keyword creation failed", status_code=404)
        else:
            return JSONResponse(content="Other Validation", status_code=404)

    except Exception as e:
        log_async(
            background_tasks,
            f"[API][CREATE_KEYWORD] Unexpected error: {str(e)}",
            "error"
        )

        raise HTTPException(status_code=500, detail=f"Error in keyword Creation: {str(e)}")
    
@router_v1.get("/keywords", status_code=200)
async def get_all_keywords_handler(
    background_tasks = BackgroundTasks,
    session: AsyncSession = Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id = user.user_id
        result = await get_all_keywords_service(
            session=session,
            background_tasks=background_tasks,
            )
        if result["status"] == "success":
            return result["data"]
        if result["status"] == "error":
            log_async(
                background_tasks,
                "[API][GET_ALL_KEYWORDS] No keywords found.",
                "warning"
            )
            raise HTTPException(status_code=404, detail="No keywords found.")
        else:
            log_async(
                background_tasks,
                f"[API][GET_ALL_KEYWORDS] Unexpected status returned: {result['status']}",
                "error"
            )
            raise HTTPException(status_code=422, detail="Unexpected condition occurred.")
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[API][GET_ALL_KEYWORDS] Unexpected error: {str(e)}",
            "error"
        )
        raise HTTPException(status_code=500, detail="Failed to fetch keyword data.")
    

@router_v1.patch("/update_keywords", status_code=200)
async def update_company(data: UpdateKeywords, session :AsyncSession = Depends(get_async_session)):
    try:
        result = await update_keywords_logic(data=data, session=session)
        if result["status"]==1:
            return JSONResponse(content=f"keyword with keyword_id: {data.keyword_id} is successfully update",status_code=200)
        else:
            return JSONResponse(content=f"Not able to update keyword_id: {data.keyword_id}", status_code=404)
    
    except Exception as e:
        return JSONResponse(content=f"update keyword data failed: {e}", status_code=404)
    

@router_v1.put("/delete_keywords", status_code=200)
async def soft_delete_keyword(data: DeleteKeywords, session: AsyncSession = Depends(get_async_session)):
    try:
        result = await soft_delete_keyword_logic(data=data, session=session)
        if result["status"] == "success":
            return JSONResponse(content=f"keyword_id {data.keyword_id} keyword is deleted successfully by user {data.deleted_by}", status_code=200)
        else:
            return JSONResponse(content=f"unable to dele keyword_id: {data.keyword_id} keyword",status_code=404)

    except Exception as e:
        return JSONResponse(content=f"failed in soft delete keyword: {e}", status_code=404)
    
app.include_router(router_v1)

import uvicorn
if __name__ == "__main__":
    uvicorn.run("app.microservices.keywords.keywords_routes:app", host="0.0.0.0", port=50008, reload=True)
