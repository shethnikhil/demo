'''
User related function logic
'''

from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import JSONResponse
from fastapi import BackgroundTasks, Depends, HTTPException
from app.core.db.db_session import get_async_session
from app.core.db.services.keywords_repository import company_keyword_db, create_keywords_db, get_all_keywords_db, update_keywords_db, soft_delete_keyword_db
from app.core.db.services.user_repository import object_to_dict

from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError

from app.utils.logging_utils import log_async


async def create_keywords_service(
        data, 
        user_id:int,
        background_tasks : BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        result = await create_keywords_db(
            session=session,
            keyword_name=data.keyword_name, 
            company_symbol = data.company_symbol,
            user_id=user_id,
            background_tasks=background_tasks,
            )
        
        if result:
            return {"status": "success", "details": result}
        else:
            return {"status": "error", "details": "DB insert failed"}
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][CREATE_KEYWORDS] Unexpected error: {str(e)}",
            "error"
        )
        return {"status": "error", "details": str(e)}

async def get_all_keywords_service(
        background_tasks: BackgroundTasks,
        session : AsyncSession,
        ):
    try:
        result = await get_all_keywords_db(
            background_tasks=background_tasks,
            session=session
            )
        if result:
            # keyword_result = [object_to_dict(result_data) for result_data in result]
            return {"status":"success" , "data":result}
        if not result:
            log_async(
                background_tasks,
                "[LOGIC][GET_ALL_KEYWORDS] No keywords found in DB.",
                "warning"
            )
            return {"status": "error", "data": []}
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[LOGIC][GET_ALL_KEYWORDS] Unexpected error: {str(e)}",
            "error"
        )
        return {"status": "error", "data": []}
    
        
async def update_keywords_logic(data, session : AsyncSession = Depends(get_async_session)):
    try:
        result = await update_keywords_db(
            keyword_id=data.keyword_id,
            keyword_name=data.keyword_name,
            updated_by=data.updated_by,
            session=session
            )
        print(result)
        return {"status":result}
    
    except Exception as e:
        return JSONResponse(content=f"update keywords data failed: {e}", status_code=404)
    
async def soft_delete_keyword_logic(data, session:AsyncSession = Depends(get_async_session)):
    try:
        result = await soft_delete_keyword_db(keyword_id=data.keyword_id, deleted_by=data.deleted_by, session=session)
        if result == 1:
            return{"status":"success","data":result}
        else:
            return{"status":"error","data":0}
        
    except Exception as e:
        return JSONResponse(content=f"soft-keyword-deletion failed: {e}", status_code=404)
    

async def company_keyword(
        company_symbol, 
        session:AsyncSession,
        background_tasks: BackgroundTasks,
        ):
    try:
        result = await company_keyword_db(
            company_symbol=company_symbol,
            session=session,
            background_tasks=background_tasks,
            )
        if result:
            return result
        if result is None:
            return None
        else:
            return{"status":"error","data":0}
        
    except SQLAlchemyError as db_err:
        log_async(
            background_tasks,
            f"[DB][MARK_JOB_AS_ARCHIVED] SQLAlchemy error: {str(db_err)}",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail="Database error while marking job as archived"
        )

    except ValidationError as val_err:
        log_async(
            background_tasks,
            f"[VALIDATION][MARK_JOB_AS_ARCHIVED] Validation error: {str(val_err)}",
            "error"
        )
        raise HTTPException(
            status_code=400,
            detail="Data validation error while archiving job"
        )

    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][MARK_JOB_AS_ARCHIVED] Unexpected error: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail="Unexpected server error during job archival"
        )
