from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import JSONResponse
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException
# import yt_dlp
from app.common_functions import identify_platform
from app.core.db.db_session import get_async_session
from app.core.db.services.shortlisted_repository import(
    # shortlist,
    s3_link_updation, 
    youtube_video_link,
    update_transcription,
    shortlist_video_details,
    video_details,
    get_all_shortlisted_videos,
    # failed_status_videos,
)
# from app.microservices.company.company_service import company_name

from app.core.db.services.user_repository import object_to_dict
from app.microservices.job.job_service import fetch_company_symbol

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# from app.microservices.youtube.youtube_service import yt_video_by_id
# from app.microservices.youtube.youtube_service import yt_video_by_id
from app.utils.logging_utils import log, log_async

from fastapi import Query
import httpx
from httpx import HTTPStatusError, ReadTimeout

from conf.config import settings


# from app.config import YOUTUBE_API_KEY # Assuming you have this file and key
YOUTUBE_API_KEY = settings.YOUTUBE_API_KEY   
DOWNLOAD_URL=settings.DOWNLOAD_URL
TRANSCRIBE_URL = settings.TRANSCRIBE_URL
cloudfront_domain = settings.cloudfront_domain
# Initialize the YouTube API client
# This 'youtube' variable is the 'Resource' object returned by build()
youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)



async def s3_to_cloudfront(raw_s3_url_private: str) -> str:

    parts = raw_s3_url_private.split('/', 3)
    if len(parts) < 4:
        raise ValueError("Invalid S3 URL format. Expected format: s3://bucket-name/path/to/file")

    path = parts[3]
    
    # Ensure cloudfront_domain doesn't end with a slash
    # cloudfront_domain = cloudfront_domain.rstrip('/')
    
    return f"{cloudfront_domain}/{path}"


async def get_download_link_service(
        shortlisted_videos_id, 
        job_id,
        url, 
        session: AsyncSession
        ):
    try:
        job_id = str(job_id)
        # log.info(f"job id {job_id} and type is {type(job_id)}")

        request_headers = {
            "Content-Type": "application/json",
            "x-api-key": YOUTUBE_API_KEY
        }

        # async with httpx.AsyncClient(timeout=30.0) as client:
        timeout = httpx.Timeout(30.0) 
        async with httpx.AsyncClient(timeout=timeout) as client:

            aws_response = await client.post(
                DOWNLOAD_URL,
                json={
                    "url": url,
                    "jobid" : job_id
                    },
                    headers=request_headers
            )
            aws_response.raise_for_status()
           # print(aws_response.json())
            log.info(aws_response.json())
            data = aws_response.json()
            #print(data)
            log.info(data)
            # data = await aws_response.json()

            s3_link = data.get("s3_url")
            s3_url_private = data.get("s3_url_private")


           # s3_url_private = data.get("s3_url")
           # raw_s3_url_private = data.get("s3_url_private")
           # s3_link = await s3_to_cloudfront(raw_s3_url_private = raw_s3_url_private)
            # response = {
            #     "message" : "Video downloaded",
            #     "s3_link" : "s3://yt-surv-poc/videos/tmpBakerhouseONGCyardvideo.mkv",
            #     "s3_url_private" : "s3://yt-surv-poc/videos/tmpBakerhouseONGCyardvideo.mkv"
            # }
            # s3_link = response["s3_link"]
            # s3_url_private = response["s3_url_private"]
            # Log and check if the links are valid
            if not s3_link or not s3_url_private:
                log.error(f"Invalid response from API. Missing s3_link or s3_url_private: {data}")
                raise HTTPException(status_code=500, detail="Invalid response from AWS API")


            if s3_link:
                result = await s3_link_updation(
                    s3_link=s3_link, 
                    s3_url_private = s3_url_private,
                    shortlisted_videos_id=shortlisted_videos_id, 
                    session=session
                    )
                if result == 1:    
                    return {"status":"success","download_link": s3_link}
                
                else:
                    return {"status":"error","download_link": s3_link}
                
    except httpx.HTTPStatusError as e:
        # This will capture any HTTP-related errors (like 403 or 500 errors)
        log.error(f"HTTP error occurred: {e.response.status_code} - {e.response.text}")
        raise HTTPException(status_code=e.response.status_code, detail=f"Error from AWS API: {e.response.text}")
    
    except httpx.RequestError as e:
        # This will capture network issues, timeouts, etc.
        log.error(f"Request error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Network error: {str(e)}")
    

    except Exception as e:
        # Catch any other unexpected errors
        log.error(f"Unexpected error in S3 download link service: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")
            
    # except Exception as e:
    #     log.error(f"Error in S3 download link: {e}")
    #     raise
    
async def fetch_youtube_video_link(
        shortlisted_videos_id:int , 
        session: AsyncSession):
    try:
        result = await youtube_video_link(shortlisted_videos_id=shortlisted_videos_id, session=session)
        if result:
            return{"status":1, "data":result}
        elif result == False:
            return{"status":0, "data":"Video Link Not Found"}
        else:
            return{"status":"need extra validation","data":result}
    except Exception as e:
        log.error("Error in fetch youtube video link logig.")
        raise



# data = {
#     "detected_language": "unknown",
#     "s3_url": "s3://yt-surv-poc/videos/tmpBakerhouseONGCyardvideo.mkv",
#     "symbol": "ONGC",
#     "transcription": "-"
# }

async def llm_call_service(
        job_id, 
        s3_url, 
        symbol, 
        shortlisted_video_id,
        s3_url_private, 
        session: AsyncSession):
    try:
        # async with httpx.AsyncClient(timeout=30.0) as client:
        #     aws_response = await client.post(
        #         "https://nfesbsjsj0.execute-api.ap-south-1.amazonaws.com/api/download",
        #         json={"url": url},
        #     )
        #     aws_response.raise_for_status()
        #     data = aws_response.json()
        #     s3_link = data.get("s3_url")

        request_headers = {
            "Content-Type": "application/json",
            "x-api-key": YOUTUBE_API_KEY
        }

        # async with httpx.AsyncClient(timeout=30) as client:
        async with httpx.AsyncClient(timeout=httpx.Timeout(300.0)) as client:


            llm_response = await client.post(
                TRANSCRIBE_URL,
                json={
                    "s3_url":s3_url_private,
                    "symbol":symbol
                },
                headers=request_headers
            )
            llm_response.raise_for_status()
            data = llm_response.json()
            # data = await llm_response.json()


        # language = data["detected_language"]
        # language = data["detected_language"]
        # model_transcription = data["transcription"]

        # Extracting language and transcription
        language = data.get("detected_language")
        model_transcription = data.get("transcription")

        if model_transcription:
            db_result = await update_transcription(
                model_transcription=model_transcription, 
                language=language, 
                shortlisted_video_id= shortlisted_video_id,
                job_id=job_id,
                session=session
                )
            if db_result == 1:
                return {
                    "status":"success",
                    "data":data
                    }

            else:
                return { "status": "failed", "data":data}
            

    except ReadTimeout:
        log.error("The request to the LLM service timed out after 300 seconds.")
        return {"status": "failed", "message": "Request timed out"}
    
    except HTTPStatusError as e:
        log.error(f"HTTP error occurred: {e}")
        return {"status": "failed", "message": str(e)}
    
    except Exception as e:
        log.exception(f"An unexpected error occurred during LLM call: {e}")
        # Re-raise the exception
        raise

async def fetch_shortlisted_videos(shortlisted_videos_id,session: AsyncSession= Depends(get_async_session)):
    try:
        result = await shortlist_video_details(shortlisted_video_id=shortlisted_videos_id, session=session)
        if result:
            if result.s3_link:
                return result
            else:
                raise HTTPException(detail="s3 link not found", status_code=404)
        elif not result:
            raise HTTPException(detail="s3 link not found", status_code=404)
        else:
            return{"status":"need extra validation","data":result}
    except Exception as e:
        log.exception(f"An unexpected error occurred in fetch_shortlisted_videos : {e}")
        # Re-raise the exception
        raise


# async def s3_download_link(url):
#     pass
#     try:
#         async with httpx.AsyncClient() as client:
#             response = await client.post(
#                 "https://your-aws-api-url/api/download",
#                 json={"url": url},
#                 timeout=30.0
#             )
                


### logic for search one by one iterate over through list.

# from sqlalchemy.ext
# .asyncio import AsyncSession
# from fastapi.responses import JSONResponse
# from fastapi import Depends
# from app.core.db.services.db_session import get_async_session
# from app.core.db.services.db_user_service import async_create_user, update_user, delete_user

# # from app.core.db.services.db_service import object_to_dict

# from googleapiclient.discovery import build
# from googleapiclient.errors import HttpError

# # from youtube_module import Youtube
# from app.utils.logging_utils import log
# from typing import List

# # from app.config import YOUTUBE_API_KEY # Assuming you have this file and key
# YOUTUBE_API_KEY = "AIzaSyAZPutKSww2eH4-wzjYrTkwLIEAa5XgBFs"

# # Initialize the YouTube API client
# # This 'youtube' variable is the 'Resource' object returned by build()
# youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)


# async def search_youtube_videos(company_name):
#     """
#     Searches YouTube for videos related to the given company name.
#     Returns the first matching video's details or None if no video is found.
#     """
#     try:
#         # CORRECT CALL: Youtube().list()
#         # 'youtube' is the service object.
#         # '.search()' gets the search collection.
#         # '.list()' is the method on the search collection.
#         result = []
#         for name in company_name:
#             search_response = (
#                 youtube.search() # Correct: Call the search() collection method
#                 .list(
#                     q=name,
#                     part="id,snippet",
#                     maxResults=10,
#                     type="video",
#                     order="date", # Most recent
#                     videoDuration="short", # Short videos (<4 minutes)
#                     relevanceLanguage="en", # English language
#                 )
#                 .execute()
#             )
#             log.debug("YouTube API Raw Response: %s", search_response)

#             videos = search_response.get("items", [])
#             if not videos:
#                 log.info(f"No videos found for company: '{name}'")
#                 return None # No videos found

#             video = videos[0]
#             video_id = video["id"]["videoId"]

#             # IMPORTANT: Use the standard YouTube embed/watch URL format.
#             # The URL 'https://www.youtube.com/watch?v={video_id}' is incorrect.
#             # For a standard YouTube video, it should be:
#             video_url = f"https://www.youtube.com/watch?v={video_id}"
#             # Or for embedding: f"https://www.youtube.com/embed/{video_id}"

#             video_title = video["snippet"]["title"]
#             video_date = video["snippet"]["publishedAt"]
#             video_thumbnail = video["snippet"]["thumbnails"]["default"]["url"]

#             log.info(f"Found video for '{name}': Title='{video_title}', URL='{video_url}'")
#             log.debug(f"Video Details: {{'video_url': '{video_url}', 'video_title': '{video_title}', 'company_name': '{company_name}', 'video_date': '{video_date}', 'video_thumbnail': '{video_thumbnail}'}}")

#             result.append({
#                 "video_url": video_url,
#                 "video_title": video_title,
#                 "company_name": name,
#                 "video_date": video_date,
#                 "video_thumbnail": video_thumbnail,
#             })

#         return result

#     except HttpError as e:
#         # Log the full exception traceback for debugging
#         log.exception(f"YouTube API error during search for '{name}': HTTP Status: {e.resp.status}, Content: {e.content.decode()}")
#         # Re-raise the exception so the FastAPI router can catch it and return an HTTPException
#         raise
#     except Exception as e:
#         # Log unexpected exceptions with traceback
#         log.exception(f"An unexpected error occurred during Youtube for '{name}': {e}")
#         # Re-raise the exception
#         raise



async def video_status_service(shortlisted_video_id: int , session: AsyncSession= Depends(get_async_session)):
    try:
        result = await video_details(shortlisted_video_id=shortlisted_video_id, session=session)
        if result:
            data = [object_to_dict(result_data) for result_data in result]
            return {"status":"success" , "data":data}
        if result == False:
            return{"status":"error","data":0}
        else:
            return JSONResponse(content="Extra validations",status_code=404)

    except Exception as e:
        # Log unexpected exceptions with traceback
        log.exception(f"An unexpected error occurred during Shortlisted video status logic: {e}")
        # Re-raise the exception
        raise

async def fetch_shortlisted_videos_service(
        job_id:int,
        background_tasks: BackgroundTasks,
        session: AsyncSession,
        ):
    try:
        result = await get_all_shortlisted_videos(
            job_id=job_id,
            background_tasks=background_tasks,
            session=session,
            )
        if result:
            data = [object_to_dict(result_data) for result_data in result]
            return {"status": "success", "data": data}

        else:
            log_async(
                background_tasks,
                f"[SERVICE][FETCH_SHORTLISTED_VIDEOS] No records found for job_id={job_id}",
                "info"
            )
            return {"status": "error", "data": 0}

    
    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][FETCH_SHORTLISTED_VIDEOS] Unexpected error: {str(e)}",
            "error"
        )
        raise


# import time
# import datetime

# async def job_listner(session:AsyncSession= Depends(get_async_session)):
#     while True:
#         result = await failed_status_videos(session=session)
#         if result:
#             data = [object_to_dict(result_data) for result_data in result]
#         if result == False:
#             data = []
#         else:
#             return JSONResponse(content="Extra validations",status_code=404)
#         now = datetime.utcnow()
        
# job_listner()





# so there is job associate with video so i create api that send req to llm model and get details(data) from that api and after receiving response it update status in db from false to true so i want to implement after hit the that async api it should check if status is 0 of any specific job then it should pick that id and retry after 3 tries it should retry after 1 2 hr like that.

# so there is two fields in table s3_link_status  and completion status so now i create llm model details retry mechanism. so now senario is if s3_link is not in table if its none then llm cant processd so there is already api that fetch s3_link and insert in db so what i think we can create two retry mechanism we creaeted already for llm call so just change and in where condition we can add if s3_link_status is true and onather retry mechinizm for s3 link what you think is this one is best way and follow standard practice ?







# from flask_cors import CORS
# import yt_dlp
# import boto3
# import os
# import re

# app = FastAPI()

# CORS(app,resources={r"/download":{"origins":"*","methods":["POST","OPTIONS"],"allow_headers":["Content-Type"]}})
# s3_client = boto3.client('s3')
# BUCKET_NAME = 'yt-surv-poc'
# COOKIES_PATH = '/tmp/cookies.txt'
# s3Region = 'ap-south-1'
# # Download cookies from S3 at startup
# try:
#     s3_client.download_file(BUCKET_NAME, 'youtube_cookies.txt', COOKIES_PATH)
# except Exception as e:
#     log.error(f"Failed to download cookies: {e}")
# @app.route('/download', methods=['POST'])

# def download_video():
#     try:
#         data = request.get_json()
#         video_url = data.get('url')
#         stockSymbol = data.get('symbol','').strip()
#         if not video_url:
#             return jsonify({'error': 'URL is required'}), 400
#         ydl_opts = {
#            # 'format': 'bestvideo+bestaudio/best',
#             'outtmpl': '/tmp/%(title)s.%(ext)s',
#             'user_agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
#             'cookiefile': COOKIES_PATH if os.path.exists(COOKIES_PATH) else None,
#             # 'proxy': 'http://your_proxy:port', # Uncomment if using proxy
#             'verbose': True,
#     }
#         with yt_dlp.YoutubeDL(ydl_opts) as ydl:
#             info = ydl.extract_info(video_url, download=True)
#             filename = ydl.prepare_filename(info)
#             #filenameS3 = filename.replace(' ','-')
#             filenameS3 = re.sub(r'[^a-zA-Z0-9.]','',filename)

#             #filename = sanitize_filename(filename)
#         if stockSymbol:
#             s3_key = f"videos/{stockSymbol}/{os.path.basename(filenameS3)}"
#         else:
#             s3_key = f"videos/{os.path.basename(filenameS3)}"
#         s3_client.upload_file(filename, BUCKET_NAME, s3_key)
#         # Clean up
#         if os.path.exists(filename):
#             os.remove(filename)
#         return jsonify({
#             'message': 'Video downloaded',
#             's3_url_private': f"s3://{BUCKET_NAME}/{s3_key}",
#             's3_url': f"https://{BUCKET_NAME}.s3.{s3Region}.amazonaws.com/{s3_key}"
#         }), 200
#     except yt_dlp.utils.DownloadError as e:
#         if "Sign in to confirm youâ€™re not a bot" in str(e):
#             return jsonify({'error': 'Bot detection triggered. Update cookies or use a proxy.'}), 403
#         return jsonify({'error': str(e)}), 500
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=8080)
