# # # from fastapi import FastAPI
# # # from sqlalchemy.ext.asyncio import AsyncSession
# # # from datetime import datetime, timedelta, timezone
# # # import asyncio

# # # app = FastAPI()

# # # # Constants
# # # MAX_RETRIES = 3
# # # SHORT_DELAY = 10
# # # LONG_DELAY = 3600  # 1 hour
# # # RETRY_TRACKER = {}

# # # # --- You must implement these ---
# # # from app.core.db.services.db_session import get_async_session
# # # from app.core.db.services.db_user_service import object_to_dict
# # # from app.core.db.services.db_shortlisted_service import failed_status_videos
# # # from app.microservices.shortlisted.shortlisted_main import llm_call

# # # # Run this only once
# # # # SessionLocal = get_async_session()

# # # RETRY_TRACKER = {
# # #     "job_id": {
# # #         "retries": 2,
# # #         "next_try": datetime
# # #     }
# # # }

# # # async def job_listener():
# # #     while True:
# # #         async with get_async_session() as session:
# # #             result = await failed_status_videos(session=session)
# # #             # result = RETRY_TRACKER
# # #             now = datetime.now(timezone.utc) 
# # #             if result:
# # #                 for job in result:
# # #                     job_dict = object_to_dict(job)
# # #                     job_id = job_dict["shortlisted_video_id"]

# # #                     retry_info = RETRY_TRACKER.get(job_id, {"retries": 0, "next_try": now})

# # #                     if retry_info["next_try"] <= now:
# # #                         print(f"Processing job {job_id}")
# # #                         success = await llm_call(job_dict, session)
# # #                         if success:
# # #                             RETRY_TRACKER.pop(job_id, None)
# # #                         else:
# # #                             retry_info["retries"] += 1
# # #                             if retry_info["retries"] > MAX_RETRIES:
# # #                                 retry_info["next_try"] = now + timedelta(seconds=LONG_DELAY)
# # #                             else:
# # #                                 retry_info["next_try"] = now + timedelta(seconds=SHORT_DELAY)

# # #                             RETRY_TRACKER[job_id] = retry_info
# # #             await asyncio.sleep(5)


# # import asyncio
# # from datetime import datetime, timedelta, timezone
# # from app.core.db.services.db_session import get_async_session_context
# # from app.core.db.services.user_repository import object_to_dict
# # from app.core.db.services.shortlisted_repository import failed_status_videos, failed_video_s3_link
# # from app.microservices.shortlisted.shortlisted_routes import llm_call, get_download_link

# # from sqlalchemy.ext.asyncio import AsyncSession
# # from fastapi.responses import JSONResponse
# # from fastapi import Depends, HTTPException
# # from app.utils.logging_utils import log


# # MAX_RETRIES = 3
# # SHORT_DELAY = 10  # TODO make 600 = 10 minutes
# # LONG_DELAY = 20  # 1 hour
# # RETRY_TRACKER = {}


# # async def job_listener():
# #     while True:
# #         async with get_async_session_context() as session:
# #             result = await failed_status_videos(session=session)
# #             now = datetime.now(timezone.utc)

# #             if result:
# #                 shortlisted_videos_id = result.shortlisted_videos_id
# #                 print(shortlisted_videos_id)
# #                 log.info(shortlisted_videos_id)
# #                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

# #                 if retry_info["next_try"] <= now:
# #                     print(f"Processing video for LLM:  {shortlisted_videos_id} at {now}")
# #                     success = await llm_call(
# #                         shortlisted_videos_id=shortlisted_videos_id, 
# #                         session=session
# #                         )

# #                     if success:
# #                         log.info(f"Processing completed successfully of shortlisted_video_id: {shortlisted_videos_id} at {now}")
# #                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
# #                     else:
# #                         retry_info["retries"] += 1
# #                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
# #                         retry_info["next_try"] = now + timedelta(seconds=delay)
# #                         RETRY_TRACKER[shortlisted_videos_id] = retry_info

# #                 # for job in result:
# #                 #     job_dict = object_to_dict(job)
# #                 #     shortlisted_videos_id = job_dict["shortlisted_videos_id"]

# #                 #     retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

# #                 #     if retry_info["next_try"] <= now:
# #                 #         print(f"Processing video for LLM:  {shortlisted_videos_id} at {now}")
# #                 #         success = await llm_call(shortlisted_videos_id=shortlisted_videos_id, session=session)

# #                 #         if success:
# #                 #             log.info(f"Processing completed successfully of shortlisted_video_id: {shortlisted_videos_id} at {now}")
# #                 #             RETRY_TRACKER.pop(shortlisted_videos_id, None)
# #                 #         else:
# #                 #             retry_info["retries"] += 1
# #                 #             delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
# #                 #             retry_info["next_try"] = now + timedelta(seconds=delay)
# #                 #             RETRY_TRACKER[shortlisted_videos_id] = retry_info
# #             else:
# #                 print("No eligible jobs found")
# #                 log.info("No eligible jobs found")

# #         await asyncio.sleep(60)  # ✅ Always sleep before retrying




# # async def s3_listener():
# #     while True:
# #         async with get_async_session_context() as session:
# #             result = await failed_video_s3_link(session=session)
# #             now = datetime.now(timezone.utc)

# #             if result:
# #                 shortlisted_videos_id = result.shortlisted_videos_id
# #                 print(shortlisted_videos_id)
# #                 log.info(shortlisted_videos_id)
# #                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})
# #                 if retry_info["next_try"] <= now:
# #                     # print(f"Processing job {shortlisted_videos_id} at {now}")
# #                     success = await get_download_link(
# #                         shortlisted_videos_id=shortlisted_videos_id,
# #                         session=session
# #                         )

# #                     if success:
# #                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
# #                     else:
# #                         retry_info["retries"] += 1
# #                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
# #                         retry_info["next_try"] = now + timedelta(seconds=delay)
# #                         RETRY_TRACKER[shortlisted_videos_id] = retry_info


# #                 # for job in result:
# #                 #     job_dict = object_to_dict(job)
# #                 #     shortlisted_videos_id = job_dict["shortlisted_videos_id"]

# #                 #     retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

# #                 #     if retry_info["next_try"] <= now:
# #                 #         print(f"Processing job {shortlisted_videos_id} at {now}")
# #                 #         success = await get_download_link(shortlisted_videos_id=shortlisted_videos_id, session=session)

# #                 #         if success:
# #                 #             RETRY_TRACKER.pop(shortlisted_videos_id, None)
# #                 #         else:
# #                 #             retry_info["retries"] += 1
# #                 #             delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
# #                 #             retry_info["next_try"] = now + timedelta(seconds=delay)
# #                 #             RETRY_TRACKER[shortlisted_videos_id] = retry_info

# #         await asyncio.sleep(60)  



# import asyncio
# from datetime import datetime, timedelta, timezone
# from app.core.db.services.db_session import get_async_session_context
# from app.core.db.services.user_repository import object_to_dict # Assuming this is for general object conversion
# from app.core.db.services.shortlisted_repository import failed_status_videos, failed_video_s3_link
# from app.microservices.shortlisted.shortlisted_routes import llm_call, get_download_link

# from sqlalchemy.ext.asyncio import AsyncSession
# from fastapi.responses import JSONResponse
# from fastapi import Depends, HTTPException
# from app.utils.logging_utils import log

# MAX_RETRIES = 3
# SHORT_DELAY = 10  # TODO make 600 = 10 minutes (This is for retry delay, not the immediate pause)
# LONG_DELAY = 20   # 1 hour (This is for retry delay)

# # Global tracker for retries (consider a persistent storage for production)
# RETRY_TRACKER = {} 


# async def job_listener():
#     while True:
#         async with get_async_session_context() as session:
#             # This line fetches only one record based on previous discussions.
#             # If you want to iterate over multiple failed jobs, failed_status_videos should return a list.
#             result = await failed_status_videos(session=session) 
#             now = datetime.now(timezone.utc)

#             if result: # If a job (single record) was found
#                 # Directly access the attribute since 'result' is an object here
#                 shortlisted_videos_id = result.shortlisted_videos_id 
#                 print(f"Checking shortlisted_video_id: {shortlisted_videos_id}")
#                 log.info(f"Checking shortlisted_video_id: {shortlisted_videos_id}")

#                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})

#                 if retry_info["next_try"] <= now:
#                     print(f"Processing video for LLM: {shortlisted_videos_id} at {now}")
#                     success = await llm_call(
#                         shortlisted_videos_id=shortlisted_videos_id, 
#                         session=session
#                     )

#                     if success:
#                         log.info(f"Processing completed successfully of shortlisted_video_id: {shortlisted_videos_id} at {now}")
#                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                     else:
#                         retry_info["retries"] += 1
#                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                         retry_info["next_try"] = now + timedelta(seconds=delay)
#                         log.warning(f"Processing failed for {shortlisted_videos_id}. Retries: {retry_info['retries']}. Next try: {retry_info['next_try']}")

#                     RETRY_TRACKER[shortlisted_videos_id] = retry_info
                    
#                     # --- ADD THIS LINE HERE ---
#                     await asyncio.sleep(10) # Pause for 10 seconds after processing a job
#                     # --- END ADDITION ---

#             else: # No eligible jobs found
#                 print("No eligible jobs found for LLM processing.")
#                 log.info("No eligible jobs found for LLM processing.")

#         await asyncio.sleep(60) # ✅ Always sleep before retrying the next full check


# async def s3_listener():
#     while True:
#         async with get_async_session_context() as session:
#             # Assuming failed_video_s3_link also returns a single record
#             result = await failed_video_s3_link(session=session)
#             now = datetime.now(timezone.utc)

#             if result: # If a job (single record) was found
#                 # Directly access the attribute since 'result' is an object here
#                 shortlisted_videos_id = result.shortlisted_videos_id 
#                 print(f"Checking S3 download for video: {shortlisted_videos_id}")
#                 log.info(f"Checking S3 download for video: {shortlisted_videos_id}")

#                 retry_info = RETRY_TRACKER.get(shortlisted_videos_id, {"retries": 0, "next_try": now})
#                 if retry_info["next_try"] <= now:
#                     print(f"Attempting S3 download for {shortlisted_videos_id} at {now}")
#                     success = await get_download_link(
#                         shortlisted_videos_id=shortlisted_videos_id,
#                         session=session
#                     )

#                     if success:
#                         log.info(f"S3 download completed successfully for {shortlisted_videos_id} at {now}")
#                         RETRY_TRACKER.pop(shortlisted_videos_id, None)
#                     else:
#                         retry_info["retries"] += 1
#                         delay = SHORT_DELAY if retry_info["retries"] <= MAX_RETRIES else LONG_DELAY
#                         retry_info["next_try"] = now + timedelta(seconds=delay)
#                         log.warning(f"S3 download failed for {shortlisted_videos_id}. Retries: {retry_info['retries']}. Next try: {retry_info['next_try']}")
                        
#                     RETRY_TRACKER[shortlisted_videos_id] = retry_info

#                     # --- ADD THIS LINE HERE ---
#                     await asyncio.sleep(10) # Pause for 10 seconds after processing a job
#                     # --- END ADDITION ---

#             else: # No eligible jobs found
#                 print("No eligible jobs found for S3 download.")
#                 log.info("No eligible jobs found for S3 download.")

#         await asyncio.sleep(60) # ✅ Always sleep before retrying the next full check