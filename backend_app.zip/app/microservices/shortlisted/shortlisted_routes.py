# import yt_dlp
from app.common_functions import get_current_user, shortlist_videos_service
from app.core.db.models.user_base import Users
from app.core.db.services.shortlisted_repository import retry_failed_llm, retry_failed_s3
from app.utils.logging_utils import log, log_async

from sqlalchemy.ext.asyncio import AsyncSession 
from app.core.db.db_session import get_async_session
import httpx


from fastapi import APIRouter, BackgroundTasks, HTTPException, status, FastAPI, Depends, Query, Form
from fastapi.responses import JSONResponse
from app.microservices.shortlisted.shortlisted_service import (
    get_download_link_service,
    fetch_youtube_video_link,
    llm_call_service,
    fetch_shortlisted_videos,
    video_status_service,
    fetch_shortlisted_videos_service,
)
from googleapiclient.errors import HttpError
from typing import List

from app.microservices.shortlisted.shortlisted_schema import (
    ShortlistVideos, 
    S3VideoRequest,
    LLMRequest
)
from app.microservices.job.job_service import get_job_by_id

app = FastAPI()
router_v1 = APIRouter(prefix="/yt-api/v1/shortlist")

from fastapi.middleware.cors import CORSMiddleware

from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For testing only; replace with your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (critical for domain access!)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["reg.nseindia.com", "ec2-3-111-213-245.ap-south-1.compute.amazonaws.com", "*"]  # Replace with your actual domain
)


@app.get("/health")
async def health():
    return JSONResponse(content="ok",status_code=200)

@router_v1.post("/shortlist_videos/{job_id}")
async def shortlist_videos_handler(
    job_id: int,
    data: List[ShortlistVideos], 
    background_tasks : BackgroundTasks,
    session: AsyncSession= Depends(get_async_session),
    user: Users = Depends(get_current_user),
    ):
    try:
        user_id = user.user_id
        # notes = data.notes
        result = await shortlist_videos_service(
            job_id=job_id,
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
            data = data,
            )
        # return JSONResponse({
        #     "total_select_videos":result["total_select_videos"],
        #     "success_count" : result["success_count"],
        #     "failed_items" : result["failed_items"]
        # })
        return JSONResponse(
            status_code=status.HTTP_207_MULTI_STATUS,
            content={
                "total_select_videos": result["total_select_videos"],
                "success_count": result["success_count"],
                "failed_items": result["failed_items"]
            }
        )
    
    except Exception as e:
        # log.error(f"An unexpected server error occurred during shortlist video:")
        log_async(
            background_tasks,
            f"[ROUTE][SHORTLIST_VIDEOS] Unexpected server error: {str(e)}",
            "error"
        )

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred. Please try again later."
        )
    

fake_return = {
    "message": "Video downloaded",
    "s3_url": "s3://yt-surv-poc/videos/tmpBakerhouseONGCyardvideo.mkv"
}

@router_v1.post("/get-download-link/{shortlisted_videos_id}/{job_id}")
async def get_download_link(
    shortlisted_videos_id: int, 
    job_id : int,
    session: AsyncSession= Depends(get_async_session)):

    try: 
        url = await fetch_youtube_video_link(shortlisted_videos_id=shortlisted_videos_id, session=session)
        if url == 0:
            return JSONResponse(content=url["data"], status_code=404)
        result = await get_download_link_service(
            shortlisted_videos_id=shortlisted_videos_id,
            job_id= job_id,
            url = url["data"] ,
            session=session,
        )
        if result["status"] == "success":
            return{"s3_url": result["download_link"]}
        else:
            raise HTTPException(detail=result["download_link"],status_code=404)

    except Exception as e:
        log.error(f"Error in S3 download link: {e}")
        raise

@router_v1.post("/LLM_call/{shortlisted_videos_id}")
async def llm_call(
    shortlisted_videos_id: int,
    session: AsyncSession= Depends(get_async_session)):
    try:
        video_details = await fetch_shortlisted_videos(shortlisted_videos_id=shortlisted_videos_id, session=session)
        if not video_details:
            return HTTPException(details="Not found", status_code=404)
        if video_details:
            s3_url = video_details.s3_link
            symbol = video_details.company_symbol
            s3_url_private = video_details.s3_url_private

        job_id = video_details.job_id

        result = await llm_call_service(
            s3_url=s3_url, 
            symbol=symbol,   
            job_id=job_id,   
            shortlisted_video_id=shortlisted_videos_id, 
            s3_url_private=s3_url_private,
            session=session
            )
        if result["status"] == "success":
            return JSONResponse(content=result["data"], status_code=200)
        elif result["status"] == "failed":
            raise HTTPException(detail=result["data"], status_code=404)
        else:
            raise HTTPException(detail="Need Extra Validations", status_code=404)
        
    except Exception as e:
        log.error(f"Error in LLM call: {e}")
        raise


    # use_aws_api = use_aws or USE_AWS_API
    # if use_aws_api:
    #     # Call AWS API endpoint
    #     try:
    #         result = await get_download_link_service(data, session=session)
    #         async with httpx.AsyncClient() as client:
    #             aws_response = await client.post(
    #                 "https://your-(aws)-api-endpoint/api/download",
    #                 json={"url": data.url},
    #                 timeout=30.0
    #             )
    #             aws_response.raise_for_status()
    #             data = aws_response.json()
    #             # Assume AWS returns {"s3_link": "..."}
    #             return {"download_link": data.get("s3_link")}
    #     except Exception as e:
    #         raise HTTPException(status_code=500, detail=f"AWS API error: {str(e)}")

    # else:
    #     # Use yt-dlp locally
    #     ydl_opts = {'quiet': True, 'skip_download': True}
    #     try:
    #         with yt_dlp.YoutubeDL(ydl_opts) as ydl:
    #             info = ydl.extract_info(data.url, download=False)
    #             return {"download_link": info.get("url")}
    #     except Exception as e:
    #         raise HTTPException(status_code=400, detail=f"yt-dlp error: {str(e)}")

    # except Exception as e:
    #     log.error(f"Error in Youtube video download: {e}")
    #     raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@router_v1.get("/shortlisted_video/{shortlisted_video_id}")
async def video_status(shortlisted_video_id: int , session: AsyncSession= Depends(get_async_session)):
    try:
        result = await video_status_service(
            shortlisted_video_id=shortlisted_video_id,
            session=session
            )
        if result["status"] == "success":
            return JSONResponse(content=result["data"], status_code=200)
        if result["status"] == "error":
            return JSONResponse(content=" something wrong in fetch shortlisted video details", status_code=404)
        else:
            return JSONResponse(content="Need to add extra validations", status_code=404)
    except Exception as e:
        log.error(f"Error in fetch shorlisted video status details: {e}")
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")



# @router_v1.get("/shortlisted_video")
# async def video_status(shortlisted_video_id: int , session: AsyncSession= Depends(get_async_session)):
#     try:
#         result = await video_status_service(
#             shortlisted_video_id=shortlisted_video_id,
#             session=session
#             )
#         if result["status"] == "success":
#             return JSONResponse(content=result["data"], status_code=200)
#         if result["status"] == "error":
#             return JSONResponse(content=" something wrong in fetch shortlisted video details", status_code=404)
#         else:
#             return JSONResponse(content="Need to add extra validations", status_code=404)
#     except Exception as e:
#         log.error(f"Error in fetch shorlisted video status details: {e}")
#         raise HTTPException(status_code=500, detail=f"Error: {str(e)}")


@router_v1.get("/shortlisted_videos/{job_id}")
async def get_shortlisted_videos_handler(
    job_id : int,
    background_tasks: BackgroundTasks,
    user:Users = Depends(get_current_user),
    session: AsyncSession= Depends(get_async_session),
    ):
    try:
        result = await fetch_shortlisted_videos_service(
            job_id=job_id,
            background_tasks=background_tasks,
            session=session,
            )
        if result["status"] == "success":
            return result["data"]
        
        elif result["status"] == "error":
            log_async(
                background_tasks,
                f"[API][GET_SHORTLISTED_VIDEOS] No data found for job_id={job_id}",
                "warning"
            )
            raise HTTPException(status_code=404, detail="No shortlisted videos found.")

        else:
            log_async(
                background_tasks,
                f"[API][GET_SHORTLISTED_VIDEOS] Unexpected service status for job_id={job_id}",
                "error"
            )
            raise HTTPException(status_code=400, detail="Invalid state from service layer.")
        
    except Exception as e:
        log_async(
            background_tasks,
            f"[API][GET_SHORTLISTED_VIDEOS] Unexpected error: {str(e)}",
            "error"
        )
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
    


@router_v1.post("/retry-download/{shortlisted_video_id}")
async def retry_s3_handler(
    shortlisted_video_id :int,
    background_tasks : BackgroundTasks,
    user : Users = Depends(get_current_user),
    session:AsyncSession = Depends(get_async_session),
):
    try:

        result = await retry_failed_s3(
            shortlisted_video_id = shortlisted_video_id,
            session = session, 
            background_tasks=background_tasks,
            )
        
        if result:
            log.info(f"shortlisted video {shortlisted_video_id} retry successfully for S3")
            return JSONResponse(
                content={
                    "message":"Successfully retry"
                },
                status_code= 200
            )

        else:
            log.error(f"unable to make S3 retry call for shortlisted video {shortlisted_video_id}")
            raise HTTPException(
                detail=f"unable to make S3 retry call for shortlisted video {shortlisted_video_id}",
                status_code=500
            )

    except Exception as e:
        log_async(
            background_tasks,
            f"[API][RETRY_S3] Unexpected error: {str(e)}",
            "error"
        )
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
    


@router_v1.post("/retry-llm/{shortlisted_video_id}")
async def retry_s3_handler(
    shortlisted_video_id :int,
    background_tasks : BackgroundTasks,
    user : Users = Depends(get_current_user),
    session:AsyncSession = Depends(get_async_session),
):
    try:

        result = await retry_failed_llm(
            shortlisted_video_id = shortlisted_video_id,
            session = session, 
            background_tasks=background_tasks,
            )
        
        if result:
            log.info(f"shortlisted video {shortlisted_video_id} retry successfully for S3")
            return JSONResponse(
                content={
                    "message":"Successfully retry"
                },
                status_code= 200
            )

        else:
            log.error(f"unable to make llm retry call for shortlisted video {shortlisted_video_id}")
            raise HTTPException(
                detail=f"unable to make llm retry call for shortlisted video {shortlisted_video_id}",
                status_code=500
            )

    except Exception as e:
        log_async(
            background_tasks,
            f"[API][RETRY_S3] Unexpected error: {str(e)}",
            "error"
        )
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
    





# @router_v1.post("retry_download/{shortlisted_video_id}")
# def retry 

# @app.post("/add-failed-job/")
# async def add_failed_job(session: AsyncSession = Depends(get_async_session)):
#     job = VideoJob(status=False)
#     session.add(job)
#     await session.commit()
#     return {"message": "Job added", "job_id": job.id}


# ==========================================================================

# from fastapi import FastAPI
# from contextlib import asynccontextmanager
# from app.microservices.shortlisted.retry import job_listener, s3_listener
# import asyncio

# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     print("App is starting up...")
#     asyncio.create_task(job_listener())   # LLM retry task
#     asyncio.create_task(s3_listener())    # S3 link retry task
#     yield
#     print("App is shutting down...")


# app = FastAPI(lifespan=lifespan)

# ===============================================================================






###########################----------------------------------------------------

# # import yt_dlp
# # import boto3
# # import os
# # import re

# from fastapi import FastAPI, HTTPException
# from pydantic import BaseModel
# import os
# import re
# import yt_dlp
# import boto3
# from fastapi.responses import JSONResponse
# from typing import Optional
# import asyncio

# app = FastAPI()



# class DownloadRequest(BaseModel):
#     url: str
#     symbol: Optional[str] = None

# #TODO Remove this once testing done on aws
# # class DummyS3Client:
# #     def download_file(self, Bucket, Key, Filename):
# #         print(f"[Mock S3] Pretending to download {Key} from bucket {Bucket} to {Filename}")
# #         open(Filename, 'w').write('fake-cookie-content')

# #     def upload_file(self, Filename, Bucket, Key):
# #         print(f"[Mock S3] Pretending to upload {Filename} to {Bucket}/{Key}")
# # s3_client = DummyS3Client()

# s3_client = boto3.client('s3')
# BUCKET_NAME = 'yt-surv-poc'
# COOKIES_PATH = '/tmp/cookies.txt'
# s3Region = 'ap-south-1'

# s3_client = boto3.client('s3', region_name=s3Region)

# # Download cookies from S3 at startup

# try:
#     s3_client.download_file(BUCKET_NAME, 'youtube_cookies.txt', COOKIES_PATH)
# except Exception as e:
#     log.error(f"Failed to download cookies: {e}")


# @app.post('/download')
# async def download_video(
#     data: DownloadRequest,
#     # user : Users = Depends(get_current_user),
# ):

#     if not data.url:
#         raise HTTPException(status_code=400, detail="URL is required")
    
#     url = data.url
#     stock_symbol = (data.symbol or '').strip()


#     ydl_opts = {
#     'outtmpl': '/tmp/%(title)s.%(ext)s',
#     'user_agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
#     'cookiefile': COOKIES_PATH if os.path.exists(COOKIES_PATH) else None,
#     'verbose': True,
#     }

#     try:
#         #TODO Remove this once testing done on aws
#         # Mock yt_dlp behavior
#         # print(f"[Mock yt_dlp] Pretending to download video from: {url}")
#         # title = "mock_video_title"
#         # filename = f"/tmp/{title}.mp4"
#         # open(filename, 'w').write('fake-video-data')  # Create fake file
#         # filename_s3 = re.sub(r'[^a-zA-Z0-9.]', '', os.path.basename(filename))

#         with yt_dlp.YoutubeDL(ydl_opts) as ydl:
#             info = ydl.extract_info(url, download=True)
#             filename = ydl.prepare_filename(info)
#             filename_s3 = re.sub(r'[^a-zA-Z0-9.]', '', os.path.basename(filename))

#         # Define S3 key
#         # if stock_symbol:
#         s3_key = f"videos/{stock_symbol}/{filename_s3}" if stock_symbol else f"videos/{filename_s3}"

#         #TODO Remove this once testing done on aws
#         # Upload to S3
#         # s3_client.upload_file(filename, BUCKET_NAME, s3_key)
#         # with open(filename, 'rb') as f:
#         #     s3_client.upload_fileobj(f, BUCKET_NAME, s3_key)

#         with open(filename, 'rb') as f:
#             await asyncio.to_thread(s3_client.upload_fileobj, f, BUCKET_NAME, s3_key)

#         # await asyncio.to_thread(s3_client.upload_fileobj, filename, BUCKET_NAME, s3_key)



#         # Clean up
#         if os.path.exists(filename):
#             os.remove(filename)

#         return {
#             'message': 'Video downloaded',
#             's3_url_private': f"s3://{BUCKET_NAME}/{s3_key}",
#             's3_url': f"https://{BUCKET_NAME}.s3.{s3Region}.amazonaws.com/{s3_key}"
#         }

#     except yt_dlp.utils.DownloadError as e:
#         if "Sign in to confirm you're not a bot" in str(e):
#             raise HTTPException(status_code=403, detail="Bot detection triggered. Update cookies or use a proxy.")
#         raise HTTPException(status_code=500, detail=str(e))

#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))



# # print(download_video(url="https://www.youtube.com/watch?v=NhsmHC83z6g"))

#####################################################--------------------

app.include_router(router_v1)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.microservices.shortlisted.shortlisted_routes:app", host="0.0.0.0", port=50020, reload=True)
