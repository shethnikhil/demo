
'''
Function logic.
'''
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi.responses import JSONResponse
from fastapi import Depends, BackgroundTasks, HTTPException
from app.core.db.db_session import get_async_session
from app.core.db.services.role_repository import (
    create_role_db,
    get_roles_db,
    )
from app.core.db.services.user_repository import object_to_dict
from app.utils.logging_utils import log, log_async

from sqlalchemy.exc import SQLAlchemyError
from pydantic import ValidationError




async def create_role_service(
    data,
    user_id,
    session: AsyncSession,
    background_tasks : BackgroundTasks,
):
    try:
        result = await create_role_db(
            role_name=data.role_name,
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
            )
        if result:
            return{"status":"success", "message":f"role: {data.role_name} is create successfully"}
        else:
            return{"status":"error", "message": f"Unable to create role: {data.role_name}"}
            # raise HTTPException(
            #     status_code=500,
            #     detail=f"Database error Create Role: f{data.role_name}"
            # )

    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][create_role_service] Unexpected error during Role Creation: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail="Error in Role Creation status: {e}"
        )
    
async def get_roles_service(
        background_tasks: BackgroundTasks,
        session : AsyncSession,
):
    try:
        result = await get_roles_db(
            session=session,
            background_tasks=background_tasks,
        )

        if result:
            return result
        
        else:
            None


    except Exception as e:
        log_async(
            background_tasks,
            f"[SERVICE][get_service] Unexpected error during fetch Role: {str(e)}",
            "error"
        )
        raise HTTPException(
            status_code=500,
            detail="Error in Fetch Role: {e}"
        )