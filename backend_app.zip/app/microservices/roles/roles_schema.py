'''
Data validation.
'''

from pydantic import BaseModel
from typing import Optional

class CreateRoll(BaseModel):
    role_name : str