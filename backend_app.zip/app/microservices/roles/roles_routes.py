'''
In this file, folder all action related endpoint should take place

'''

from typing import Optional
from fastapi import FastAPI, Depends
from fastapi.security import OAuth2PasswordRequestForm
from fastapi import HTTPException, APIRouter, Response, Query
from fastapi.responses import JSONResponse


from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db.services.role_repository import check_role_name_db
from app.core.db.db_session import get_async_session
from app.microservices.roles.roles_service import (
    create_role_service,
    get_roles_service,
)
from app.microservices.roles.roles_schema import CreateRoll

from app.utils.logging_utils import log, log_async
from fastapi import BackgroundTasks
from app.core.db.models.user_base import Users
from app.common_functions import get_current_user

app = FastAPI()
router_v1 = APIRouter(prefix="/yt-api/v1/roles")

from fastapi.middleware.cors import CORSMiddleware

from fastapi.middleware.trustedhost import TrustedHostMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For testing only; replace with your domain in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Trusted Host Middleware (critical for domain access!)
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["reg.nseindia.com", "ec2-3-111-213-245.ap-south-1.compute.amazonaws.com", "*"]  # Replace with your actual domain
)


@app.get("/health")
async def health():
    return JSONResponse(content="ok",status_code=200)

@router_v1.post("/roles")
async def create_role_handler(
    data : CreateRoll,
    background_tasks : BackgroundTasks,
    user : Users = Depends(get_current_user),
    session : AsyncSession = Depends(get_async_session),
):
    try:
        user_id=user.user_id
        role_name_result = await check_role_name_db(
            role_name = data.role_name,
            session=session,
            background_tasks=background_tasks,
        ) 
        if role_name_result:
            log.error("Role name is already exist")
            raise HTTPException(status_code=404, detail="Role is already present")
        
        result = await create_role_service(
            data=data,
            user_id=user_id,
            session=session,
            background_tasks=background_tasks,
        )

        if result["status"] == "success":
            return{"status":1, "message":f"role: {data.role_name} is create successfully"}
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Database error Create Role: f{data.role_name}"
            )
    except Exception as e:
        # log_async()
        raise

@router_v1.get("/roles")
async def get_roles_handler(
        background_tasks : BackgroundTasks,
        session: AsyncSession = Depends(get_async_session),
        user : Users = Depends(get_current_user),
):
    try:
        result = await get_roles_service(
            session=session,
            background_tasks=background_tasks,
        )

        if result:
            return result
        
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Logic Error fetch Roles"
            )


    except Exception as e:
        # log_async()
        raise
    


app.include_router(router_v1)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.microservices.roles.roles_routes:app", host="0.0.0.0", port=50024, reload=True)
