from asyncio import log
import configparser
import os
from urllib.parse import urlparse

from fastapi.responses import JSONResponse
from pydantic import BaseModel
from app.core.db.db_session import get_async_session 
from sqlalchemy.ext.asyncio import AsyncSession 

from app.core.db.models.user_base import Users
from app.core.db.services.shortlisted_repository import shortlist
from app.core.db.services.youtube_repository import fetch_yt_video_details
from app.utils.logging_utils import log_async


class Token(BaseModel):
    access_token: str
    token_type: str

class User(BaseModel):
    username: str
    user_id: int

config = configparser.ConfigParser()
# Get the absolute path to the config.ini file
config_file_path = os.path.join(os.path.dirname(__file__), 'config.ini')

# Read the config file
config.read(config_file_path)
# config.read("config.ini")

SECRET_KEY = config["auth_settings"]["SECRET_KEY"]
ALGORITHM = config["auth_settings"]["ALGORITHM"]
ACCESS_TOKEN_EXPIRE_MINUTES = int(config["auth_settings"]["ACCESS_TOKEN_EXPIRE_MINUTES"])

# print(SECRET_KEY)
# print(type(ACCESS_TOKEN_EXPIRE_MINUTES))






from fastapi import BackgroundTasks, Depends, HTTPException 
# Depends use for dependancy injection and HttpException for error response 

from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
# OAuth2PasswordBearer  is dependancy that handles the security scheme for password-base OAuth2
# Apydentic module that define the expected data for /token endpoint( username and password)

from datetime import datetime, timedelta, timezone
# datetime ........
# timedelta is used for define time intervals use in handle bearier token expiration

from typing import Annotated
# used for providing type hints to dependencies in FastAPI. 
# from jwt import exceptions
from app.core.db.services.common_repository import get_user_from_db
# jwt - function that responsible for encoding and decoding 
#  JWTError - Exception raise by jose.jwt if there is an issue with decoding or verification

# from common_schema import User, Token

from jose import ExpiredSignatureError, JWTError, jwt
# from jwt import exceptions
# print(jwt.encode({"test": "value"}, "secret", algorithm="HS256"))



oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")  # Note the leading slash
import os
# config_file_path = os.path.join(os.path.dirname(__file__), '..', 'config.py')
# from config import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES



# In a real application, this would involve database lookups and password verification
def fake_authenticate_user(form_data: OAuth2PasswordRequestForm):
    # ... (your actual authentication logic here - database interaction, password hashing, etc.)
    FAKE_USERS_DB = {"alice": {"username": "alice", "password": "password123"}}
    user_dict = FAKE_USERS_DB.get(form_data.username)
    if not user_dict:
        return None
    if user_dict["password"] != form_data.password:
        return None
    return user_dict

# def create_access_token(data: dict, expires_delta: timedelta | None = None):
#     to_encode = data.copy()
#     expire = None
#     if expires_delta:
#         expire = timezone.utc() + expires_delta
#         to_encode.update({"exp": expire})
#     encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
#     print(encoded_jwt)
#     return encoded_jwt

async def get_current_user(
        token: Annotated[str, Depends(oauth2_scheme)], 
        session: AsyncSession= Depends(get_async_session)) -> Users:
    credentials_exception = HTTPException(
        status_code=401,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms="HS256")
        username: str = payload.get("sub")
        # if username is None:
        #     raise credentials_exception
        # In a real application, you would fetch the user from the database based on the username
        user = await get_user_from_db(username=username, session=session)
        if user is None or user == False:
            raise credentials_exception
        
        # data = object_to_dict(user)
        return user
    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except JWTError:
        raise credentials_exception

# Optional: Dependency for checking if the current user has specific roles/permissions
# async def require_role(required_role: str):
#     async def get_user_with_role(current_user: Annotated[User, Depends(get_current_user)]):
#         if current_user.role != required_role:
#             raise HTTPException(status_code=403, detail="Insufficient privileges")
#         return current_user
#     return get_user_with_role

from app.core.db.services.user_repository import check_username
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db.db_session import get_async_session
from app.core.db.services.user_repository import object_to_dict


async def check_username_service(username, session:AsyncSession= Depends(get_async_session)):
    try:
        result = await check_username(username=username, session=session)
        # data = [object_to_dict(result_data) for result_data in result]

        # Convert each part of the tuple (Users, UserRoles, Roles) to dict
        data = [
            {
                "user": object_to_dict(row[0]),
                "user_role": object_to_dict(row[1]),
                "role": object_to_dict(row[2])
            }
            for row in result
        ]
        if not data or data[0]["user"].get("email") is None:
            raise HTTPException(status_code=404, detail="Invalid Username")
        # if data["email"] is None or data is None:
        #     raise JSONResponse(content="Invalide Username",status_code=404) 
        return data


    except Exception as e:
        raise 
    

async def identify_platform(url):
    """
    Identifies the video platform from a given URL.

    Args:
        url (str): The URL of the video.

    Returns:
        str or None: The name of the platform (e.g., 'YouTube', 'Instagram', 'Twitter')
                     or None if the platform is not recognized.
    """
    try:
        parsed_url = urlparse(url)
        hostname = parsed_url.hostname

        if not hostname:
            return None # No valid hostname found

        # Normalize hostname to lowercase and remove 'www.' for easier matching
        hostname = hostname.lower()
        if hostname.startswith('www.'):
            hostname = hostname[4:]

        if hostname == 'youtube.com' or hostname == 'youtu.be' or hostname == 'm.youtube.com':
            return 'YouTube'
        elif hostname == 'instagram.com':
            # For Instagram, you might want to further check the path
            # to distinguish between general posts and reels more specifically.
            # For this request, we'll assume any instagram.com video link is 'Instagram'.
            return 'Instagram'
        elif hostname == 'twitter.com' or hostname == 'x.com':
            # Twitter videos are usually embedded within tweet status pages.
            # We check for '/status/' in the path for stronger indication, though not strictly required
            # for just hostname identification.
            if '/status/' in parsed_url.path:
                return 'Twitter'
            return 'Twitter' # Also return Twitter if it's just the main domain for simplicity
        # Add more platforms here as needed
        # elif hostname == 'vimeo.com':
        #     return 'Vimeo'
        # elif hostname == 'tiktok.com':
        #     return 'TikTok'
        
        return None # Platform not recognized

    except Exception as e:
        print(f"An error occurred while parsing URL '{url}': {e}")
        return None



async def shortlist_videos_service(
        job_id,
        data,
        user_id,
        session: AsyncSession,
        background_tasks: BackgroundTasks,
        ):
    """
    Service to process shortlisted videos by validating and inserting into DB.
    Returns summary with counts and failure details.
    """
    success_count = 0
    failed_items = []
    # video_id = video_id
    total_select_videos = len(data)
    try:
        for video in data:
            try:
                yt_video_id = video.yt_videos_id
                notes = video.notes
                yt_video_data = await yt_video_by_id(
                    job_id=job_id,
                    yt_video_id=yt_video_id,
                    user_id=user_id,
                    background_tasks=background_tasks,
                    session=session,
                    )
                if yt_video_data is None:
                    log_async(
                        background_tasks,
                        f"[SERVICE][YT_VIDEO_BY_ID] Video ID {yt_video_id} not found.",
                        "warning"
                    )
                    failed_items.append({
                        "video_id": yt_video_id,
                        "error": "Video not found"
                    })
                    continue
                if yt_video_data:
                    video = yt_video_data
                    required_fields = ["youtube_videos_id", "job_id", "company_symbol", "video_url"]
                    
                    for idx, video_item in enumerate(video):
                        missing_fields = [field for field in required_fields if field not in video_item or video_item[field] is None]
                        if missing_fields:
                            log_async(
                                background_tasks,
                                f"[SERVICE][YT_VIDEO_VALIDATION] Missing fields {missing_fields} in video at index {idx}: {video_item}",
                                "error"
                            )
                            failed_items.append({
                                "video": video_item,
                                "error": f"Missing required fields: {missing_fields}"
                            })
                            continue

                    # get hostname 
                    # hostname_result = await identify_platform(url=video_item["video_url"])
                    # if hostname:
                    #     hostname = hostname_result
                    # else:
                    #     hostname = None 

                
                    # if not all(k in video for k in required_fields):
                    #         log.error("Missing required fields.")
                    #         raise ValueError("Missing required fields.")
                    for video_item in video:
                        video_url = video_item["video_url"]
                        platform_result = await identify_platform(url=video_url)
                        if platform_result:
                            platform = platform_result
                        else:
                            platform = None

                        result = await shortlist(
                            job_id=video_item["job_id"],
                            company_symbol=video_item["company_symbol"],
                            title=video_item["title"],
                            thumbnail=video_item["thumbnail"],
                            publish_date=video_item["publish_date"],
                            language=video_item["language"],
                            youtube_video_url=video_url,
                            notes = notes,
                            platform = platform,
                            session=session,
                            background_tasks=background_tasks,
                        )
                        if result == True:
                            success_count +=1
                        if not result:
                            failed_items.append({"video":video, "error":"Error in DB while data Insertion"})

            except Exception as ve:
                failed_items.append({
                    "video": video,
                    "error": str(ve)
                })
                
        
    except Exception as e:
        # Log unexpected exceptions with traceback
        log.error(f"An unexpected error occurred during shortlist video logic for ': {e}")
        # Re-raise the exception
        raise

    finally:
        return{
            "total_select_videos":total_select_videos,
            "success_count" : success_count,
            "failed_items" : failed_items
            }
    



async def yt_video_by_id(
        job_id:int, 
        yt_video_id:int, 
        user_id:int,
        session: AsyncSession,
        background_tasks: BackgroundTasks,
        ):
    """
    Fetch YouTube video data by ID and convert to dict.
    Returns list of dicts or None.
    """
    try:
        result = await fetch_yt_video_details(
            job_id=job_id,
            yt_video_id=yt_video_id,
            user_id=user_id,
            background_tasks=background_tasks,
            session=session,
            )
        if result:
            data = [object_to_dict(search_data) for search_data in result]
            # return{"status":1, "data":data}
            return data
        elif result == False:
            # return{"status":0, "data":"No Search Data Found"}
            log_async(
                background_tasks,
                f"[SERVICE][YT_VIDEO_BY_ID] No data found for yt_video_id={yt_video_id}",
                "warning"
            )
            return None
        else:
            # return{"status":"need extra validation","data":result}.
            log_async(
                background_tasks,
                f"[SERVICE][YT_VIDEO_BY_ID] No data found for yt_video_id={yt_video_id}",
                "warning"
            )
            return None
        
    except Exception as e:   
        # Log unexpected exceptions with traceback
        log.error(f"An unexpected error occurred during Youtube for ': {e}")
        # Re-raise the exception
        raise