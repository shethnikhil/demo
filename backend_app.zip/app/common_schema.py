from app.conf.config import *


from pydantic import BaseModel

class Token(BaseModel):
    access_token: str
    token_type: str

class User(BaseModel):
    username: str
    # In a real application, you'd have more user details